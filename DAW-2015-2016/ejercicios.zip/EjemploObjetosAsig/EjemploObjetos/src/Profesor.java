
public class Profesor {
	private int codigo;
	private String nombre;
	private Asignatura asignatura;
	
	public Profesor() {
		// TODO Auto-generated constructor stub
	}

	public Profesor(int codigo, String nombre, Asignatura asignatura) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.asignatura = asignatura;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Asignatura getAsignatura() {
		return asignatura;
	}

	public void setAsignatura(Asignatura asignatura) {
		this.asignatura = asignatura;
	}

	@Override
	public String toString() {
		return "Profesor [codigo=" + codigo + ", nombre=" + nombre
				+ ", asignatura=" + asignatura.getNombre() + "]";
	}
	
	
	
	
	
	
}
