
public class Asignatura {
	private int codAsig;
	public String nombre;
	protected int horas; 
	
	public Asignatura(){
		
	}
	
	public Asignatura(int codAsig, String nombre){
		this.codAsig =codAsig;
		this.nombre=nombre;
		//this.horas=0;
		
	}
	
	public Asignatura (  int codAsig, String nombre, int horas){
		/*this.codAsig=codAsig;
		this.nombre=nombre;*/
		this(codAsig, nombre); 
		this.horas=horas;
		
	}
	
	public void setCodigo(int codAsig){
		this.codAsig=codAsig;
				
	}
	
	public int getCodigo(){
		return this.codAsig;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getHoras() {
		return horas;
	}

	public void setHoras(int horas) {
		this.horas = horas;
	}
	
	public void aumentarHoras(int aumento){
		horas+=aumento;
	}
	
	public void modifHoras(int nuevasHoras){
		horas+=nuevasHoras;
	}
	

	@Override
	public String toString() {
		return "Asignatura [codAsig=" + codAsig + ", nombre=" + nombre
				+ ", horas=" + horas + "]";
	}
	
	
	
	

}
