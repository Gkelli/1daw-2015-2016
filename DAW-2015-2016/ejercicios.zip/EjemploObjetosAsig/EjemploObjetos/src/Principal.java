
public class Principal {

	public static void main(String[] args) {
		//creamos asignaturas
		
		Asignatura asig1=new Asignatura();
		Asignatura asig2=new Asignatura(1, "Matematicas");
		Asignatura asig3=new Asignatura(2, "Java", 8);
		
		System.out.println("La asignatura: "+asig1.nombre+" tiene "+asig1.horas);
		System.out.println("La asignatura: "+asig3.nombre+" tiene "+asig3.horas);
		System.out.println("La asignatura: "+asig2.nombre+" tiene "+asig2.horas);
		asig3.horas=10;
		System.out.println("La asignatura: "+asig3.nombre+" tiene "+asig3.horas);
		
		System.out.println("La asignatura: "+asig3.nombre+" tiene "+asig3.horas+" horas y su codigo es "+asig3.getCodigo());
		asig3.setCodigo(5);
		System.out.println("La asignatura: "+asig3.nombre+" tiene "+asig3.horas+" horas y su codigo es "+asig3.getCodigo());
		
		int horasAux=asig3.getHoras();
		horasAux+=2;
		asig3.setHoras(horasAux);
		
		asig3.setHoras(asig3.getHoras()+2);
		
		asig3.aumentarHoras(2);
		
		asig3.modifHoras(-3);
		
		//creamos un profesor
		
		Profesor prof1;
		prof1=new Profesor(1, "Almudena", asig3);
		System.out.println("Datos del profesor");
		System.out.println(prof1.getCodigo()+ " "+prof1.getNombre());
		System.out.println("Imparte");
		System.out.println(prof1.getAsignatura().getCodigo()+" "+prof1.getAsignatura().nombre);
	
		System.out.println("Datos de la asignatura");
		System.out.println(asig3.toString());
		System.out.println("Datos del profesor");
		System.out.println(prof1.toString());

}
}
