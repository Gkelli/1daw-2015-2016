
public class PrincipalEmpleado {

	public static void main(String[] args) {
		// 1.	A�adir Empleado: Se pedir� el tipo (Jefe u Obrero) y los datos del mismo: (nombre, edad y sueldo). El c�digo se generar� de forma autom�tica. Se debe introducir primero el nombre, controlar que no existe este nombre, pedir el resto de los datos y proceder al alta de la forma siguiente:
		//			Si el empleado es jefe, se le dar� de alta (el arrayList de sus obreros se iniciliazar� a null).
		//			Si el empleado es obrero, se pedir� tambi�n el c�digo de su jefe para buscarlo y almacenarlo en el atributo jefe del obrero a dar de alta. Se controlar� que dicho jefe exista y sea realmente un jefe. El obrero se almacenar� tambi�n en el arrayList del jefe asignado.


	Empresa empresa = new Empresa();
	int opcion;

	do {
		System.out.println ("MENU");
		System.out.println ("1 - A�adir Empleado");
		System.out.println ("2 - Subir Sueldo");
		System.out.println ("3 - Listar Obreros de un determinado Jefe");
		System.out.println ("4 - Mostrar el Jefe de un obrero");
		System.out.println ("5 - Listar todos los datos");
		System.out.println ("6 - Borrar un empleado");
			
		System.out.println ("7- Fin");

		do {
			System.out.println("Introduce opcion (1-7)");
			opcion = LeerTeclado.readInteger();
		} while (opcion < 1 || opcion > 7);

		switch (opcion){
		case 1: empresa.a�adirEmpleado();break;
		case 2: empresa.subirSueldo();break;
		case 3: empresa.listarObreros();break;
		case 4: empresa.mostrarJefeObrero();break;
		case 5: empresa.listarEmpleados();break;
		case 6: empresa.borrarEmpleado();break;
		
		case 7: System.out.println("Fin del programa");break;
		
		}	
	}
	while (opcion!=7);
	
}


}
