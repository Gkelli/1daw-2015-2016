import java.util.Vector;


public class Empresa {
	private Vector<Empleado> listaEmpleado;

	public Empresa() {
		listaEmpleado = new Vector<Empleado>();
	}

	public void verEmpleados() { 
		for (int i = 0; i < listaEmpleado.size(); i++) {
			System.out.println(listaEmpleado.get(i).toString());
		}
	}

	public void sueldoTotal() {

	}

	
	public void insertarEmpleado(Empleado empleado) {
		listaEmpleado.add(empleado);
	}

	
	public int cantidadEmpleado() {
		return listaEmpleado.size();
	}
	
	public Empleado buscarEmpleados(String codigo) {
		boolean encontrado=false;
		Empleado emp=null;
		for (int i = 0; i < listaEmpleado.size() && !encontrado; i++) {
			if (listaEmpleado.elementAt(i).getCodigo() == codigo ) {
				System.out.println(listaEmpleado.elementAt(i).toString());
				encontrado = true;
			}
		} 
		return emp;
	}
	
	public Empleado buscarEmpleadosNombre(String nombre) {
		boolean encontrado=false;
		Empleado emp=null;
		
		for (int i = 0; i < listaEmpleado.size() && !encontrado; i++) {
			if (listaEmpleado.elementAt(i).getNombre() == nombre ) {
				System.out.println(listaEmpleado.elementAt(i).toString());
				encontrado= true;
			}
		} 
		return emp; 
	}
	
	public void a�adirEmpleado(){
		
		System.out.println("Dar de alta nuevo empleado");
		System.out.println("A�ade nombre de empleado");
		String nombre = LeerTeclado.readString();
		
		Empleado emp =buscarEmpleadosNombre(nombre);
		
		String tipo;
		if (nombre!=null) {
			System.out.println("El empleado ya existe");
			System.out.println(emp.toString());
		} else { 
			
			System.out.println("A�ade edad y sueldo del empleado");
			int edad=LeerTeclado.readInteger();
			double sueldo=LeerTeclado.readDouble();
			
			do {
			System.out.println("Introduce el tipo de empleado que quieres a�adir(jefe/obrero)");
			tipo =LeerTeclado.readString(); 
			} while (!tipo.equalsIgnoreCase("jefe")&& !tipo.equalsIgnoreCase("obrero"));
			
			System.out.println("Se da de alta del empleado");
			if (tipo.equalsIgnoreCase("jefe")){ 
		    	
		    	Jefe jefe=new Jefe(nombre, edad, sueldo);
		    	listaEmpleado.add(jefe); 
		      	System.out.println(jefe.toString());
		    }
		    
		    else {
		    	
		    	System.out.println("Introduzca el c�digo de su jefe"); //busca el c�digo de su jefe
		    	String codJefe=LeerTeclado.readString();
		    	
		    	emp=buscarEmpleados(codJefe.toUpperCase());
		    	
		    	if (emp==null){
		    		System.out.println("Lo sentimos, el jefe no existe. Se a�ade al obrero sin jefe asignado");
		    		Obrero obrero=new Obrero(nombre, edad, sueldo, null);
		    		listaEmpleado.add(obrero); 
		    	}
		    		
		    		else {
		    			if (!(emp instanceof Jefe)){
		    				System.out.println("El c�digo que introdujo no corresponde a un Jefe");
		    				System.out.println("Lo sentimos, el jefe no existe. Se a�ade al obrero sin jefe asignado");
				    		Obrero obrero=new Obrero(nombre, edad, sueldo, null);
				    		listaEmpleado.add(obrero); 
		    			}
		    			
		    			else { 
		    				
		    				Jefe jefe=(Jefe)emp;
		    				System.out.println("Datos del jefe. C�digo:" + jefe.getCodigo()+" Nombre: "+jefe.getNombre());
		    				
		    				Obrero obrero=new Obrero(nombre, edad, sueldo, jefe);
		    				listaEmpleado.add(obrero); 			    			
		    				System.out.println(obrero.toString());
		    				
		    				
		    				jefe.anadirObrero(obrero);
		    			}
		    		}
		    	}
		}

	}
	
	
	public void borrarEmpleado(){

		 System.out.println("Baja de un empleado");
		 System.out.println("Introduzca c�digo del empleado");
		 String codigo=LeerTeclado.readString();
		 String resp;
		 
		 Empleado emp=buscarEmpleados(codigo.toUpperCase());//Busca el empleado a borrar

		 if (emp==null) //no existe el empleado
			 System.out.println("El empleado a dar de baja no existe");

		 else{ 

			 if (emp instanceof Jefe)//pregunto si es jefe 
			 {
				 Jefe jefe=(Jefe)emp;				 
				 System.out.println(jefe.toString());
				

				 do{
					 System.out.println("�Es este el jefe a dar de baja? (s/n)");
					 resp=LeerTeclado.readString();
				 }
				 while (!resp.equalsIgnoreCase("s") && !resp.equalsIgnoreCase("n"));


				 if (resp.equalsIgnoreCase("n")) 
					 System.out.println("Baja anulada");

				 else{
					 int numObreros=jefe.contarObreros();
				 
					 if (numObreros==0)
						 System.out.println("No tiene obreros asignados");
					 else{
						 System.out.println("El jefe tiene "+numObreros+ " que van a quedarse sin jefe directo");
						 jefe.marcarObrerosNull();
						 listaEmpleado.remove(jefe); 
						 System.out.println("Se ha borrado el jefe de forma correcta");
					 }

				 }
			 }

			 else {
				 Obrero ob=(Obrero)emp;
				 System.out.println(ob.toString());//se visualizan los datos del obrero
				 
				 do{
					 System.out.println("�Es este el obrero a dar de baja? (s/n)");
					 resp=LeerTeclado.readString();
				 }
				 while (!resp.equalsIgnoreCase("s") && !resp.equalsIgnoreCase("n"));
				 
				 if (resp.equalsIgnoreCase("n"))
					 System.out.println("Baja anulada");
				 
				 else{

					 Jefe jefe=ob.getJefe();//se obtiene el jefe del obrero

					 if (jefe!=null) 

						 if (!jefe.existeObrero(ob))
							 System.out.println("Debe haber un error porque el jefe no tiene asignado al obrero");

						 else
						 {
							 jefe.quitarObrero(ob); 
							 System.out.println("Su jefe ya no tiene asignado este obrero ");
						 } 
					 
					 listaEmpleado.remove(ob); 
					 System.out.println("Se ha borrado el obrero de forma correcta");

						 
				 }
			 }
		 }
	 }

	
	public  void subirSueldo() {
	    int porcentaje;
	   
	    System.out.println ("Dar porcentaje de subida (0..100)");
	    porcentaje= LeerTeclado.readInteger();
	    System.out.println("Se procede a subir el sueldo a todos los empleados");
	    for (int i=0; i<listaEmpleado.size();i++)
	    	listaEmpleado.elementAt(i).subirSueldo(porcentaje);
	  }

	
public  void listarObreros() {
		
		System.out.println ("Dar codigo Jefe ");
		String codJefe = LeerTeclado.readString();
		Empleado emp=buscarEmpleados(codJefe.toUpperCase());
		if (emp==null)
			System.out.println("Lo sentimos, el jefe no existe");
		else {
			if (!(emp instanceof Jefe))
				System.out.println("El c�digo que introdujo no corresponde a un Jefe");
			else {
				Jefe jefe=(Jefe)emp;
				jefe.contarObreros();
			}    
		}
	}

public  void mostrarJefeObrero() {

	System.out.println ("Dar codigo Obrero ");
	String codempleado = LeerTeclado.readString();
	Empleado emp= buscarEmpleados(codempleado.toUpperCase()); 
	if (emp == null)
		System.out.println ("Codigo de obrero no encontrado");
	else {
		if (!(emp instanceof Obrero))
			System.out.println("El c�digo que introdujo no corresponde a un Obrero");
		else   
		{
			System.out.println("Los datos del obrero son ");
			System.out.println(((Obrero)emp).toString());
			((Obrero)emp).mostrarJefe();
		}
	}
}

public  void listarEmpleados(){   
	  
	   for (int i=0; i<listaEmpleado.size();i++) {
	    	System.out.println(listaEmpleado.elementAt(i).toString());
	    
	  } 
		
		
	}





	
	
	
	
	
	
	
}
