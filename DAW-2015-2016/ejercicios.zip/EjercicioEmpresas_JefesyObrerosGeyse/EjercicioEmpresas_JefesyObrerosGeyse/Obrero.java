
public class Obrero extends Empleado {
	private static int contadorObreros;
	private Jefe jefe; // Un obrero, adem�s de sus datos, tiene un atributo jefe.
		
	public Obrero(){}
	
	public Obrero(String nombre, int edad, double sueldo, Jefe jefe){
		super(nombre,edad,sueldo);
		contadorObreros++;
		codigo="Obrero" + String.valueOf(contadorObreros);	
		jefe= new Jefe();
	}

	public int getContadorObreros() {
		return contadorObreros;
	}


	public Jefe getJefe() {
		return jefe;
	}

	public void setJefe(Jefe jefe) {
		this.jefe = jefe;
	}

	public void subirSueldo(int porcentaje) {
		sueldo=sueldo + sueldo*((double)porcentaje/100);
	}
	
	public void mostrarJefe() {
		System.out.println("Datos de su jefe");
		if (jefe!=null)
			System.out.println (jefe.toString());
		else
			System.out.println("No tiene Jefe asignado");
	} 

	@Override
	public String toString(){
		return "El empleado tiene categor�a de obrero con  "+super.toString()+ ((jefe != null)? " y su jefe es " +jefe.getCodigo()+ " de nombre "+jefe.getNombre():" sin jefe asignado");

	}

	
	
}
