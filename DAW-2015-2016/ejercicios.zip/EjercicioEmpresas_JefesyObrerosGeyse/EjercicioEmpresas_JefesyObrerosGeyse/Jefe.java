import java.util.ArrayList;


public class Jefe extends Empleado {
	private static int contadorJefes; //Creamos un contador de Jefes
	private ArrayList<Obrero> colaboradores; //Un jefe, adem�s de sus datos, tiene un conjunto de obreros a su cargo almacenados en un objeto de tipo ArrayList.
	
	public Jefe(){}
	
	public Jefe(String nombre, int edad, double sueldo){
		super(nombre,edad,sueldo);
		contadorJefes++; //contador de Jefes
		codigo="J" + String.valueOf(contadorJefes);//pone como c�digo J1, J2, etc.		
		colaboradores = new ArrayList<Obrero>();
	}
	
	public  void anadirObrero(Obrero ob) {	
		colaboradores.add(ob);
	}
	
	public boolean existeObrero(Obrero ob) {
		boolean encontrado=false;
		for (int i=0; (i<colaboradores.size()) && !encontrado; i++)
			if(colaboradores.get(i).equals(ob))
				encontrado=true;
		
		return encontrado;
	}
	
		public boolean existeObrero2 (Obrero ob){
			return colaboradores.contains(ob);
			
		}
		
		public int contarObreros(){
			return colaboradores.size();
		}
		
		public void quitarObrero(Obrero ob){
			if (!existeObrero(ob))
				System.out.println("El jefe no tiene este obrero asignado ");
			else{
				colaboradores.remove(ob);
				}	
		}

		
		public void subirSueldo(int porcentaje) {	
			sueldo=sueldo + sueldo*((double)porcentaje/120);
			
		}
		
		@Override
		public String toString(){
			return "El empleado tiene categor�a de Jefe con "+super.toString();
		}

		public void marcarObrerosNull(){
			System.out.println("Los obreros siguientes pierden la asignaci�n de jefe");
			for (int i=0; i<colaboradores.size(); i++){
				System.out.println ("C�digo:"+ colaboradores.get(i).getCodigo());
				colaboradores.get(i).setJefe(null);	

			}
		}
	
	
	
}
