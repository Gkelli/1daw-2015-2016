package ejerciciosArrays;
public class Ejercicio03 {

	public static void main(String[] args) {
		// 3.	Programa que lea por teclado una secuencia de notas desordenada 
		// 		(la secuencia termina cuando se introduce una mayor que 10 o menor que 0) 
		//		y visualiza las veces que se repite cada una.

		
		int arrays []= new int [11];
		System.out.println("\n----------------SECUENCIA DE NOTAS DESORDENADAS--------------");
		introArrays(arrays);
		System.out.println("\n--------VISUALIZA LAS VECES QUE SE REPITE CADA NOTA----------");
		cargarArrays(arrays);
		
	}

	public static void introArrays(int arrays[]){
		System.out.println("Introduce las notas ( 1 a 10 )");
		int n=LeerTeclado.readInteger();
		while (n>=0 && n<=10){
			arrays[n]++;
			n=LeerTeclado.readInteger();
			}
	}

	
	public static void cargarArrays(int contArray[]){
		int i;
		for(i=0; i < contArray.length; i++){
			System.out.println("La nota "+i+" aparece "+contArray[i]+(contArray[i]==1?" vez":" veces"));
			}
		
		
		}

}

