package ejerciciosArrays;

public class Ejercicio06 {

	public static void main(String[] args) {
		/*
		 * 6. Programa que genere un array aleatoriamente de 20 n�meros
		 * comprendidos entre 1 y 100 y los divida en dos arrays, uno con los
		 * n�meros pares y otro con los n�meros impares. Para generar un n�
		 * aleatorio se usa el m�todo random de la clase Math, se multiplica por
		 * el valor del rango deseado y se suma 1 (porque queremos a partir de
		 * 1) numero=(int)(Math.random * valor +1) (en nuestro caso valor=100)
		 */

		int[] arrayRandom = arrayRandom();
		System.out.println("\n--------Arrays aleatorio de 20 n�meros entre 1 y 100--------");
		verArray(arrayRandom);
		separarPares(arrayRandom);

	}

	public static int[] arrayRandom() {
		int[] arrayRandom = new int[20];
		for (int i = 0; i <= 19; i++)
			arrayRandom[i] = (int) (Math.random() * 100) + 1;
		return arrayRandom;
	}

	public static void verArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}

	public static void separarPares(int[] array) {
		int contPar = 0, contImpar = 0, i, j = 0, k = 0;

		for (i = 0; i < array.length; i++) {
			if (array[i] % 2 == 0) {
				contPar++;
			} else {
				contImpar++;
			}
		}
		int[] arrayPar = new int[contPar];
		int[] arrayImpar = new int[contImpar];

		for (i = 0; i < array.length; i++)
			if (array[i] % 2 == 0) {
				arrayPar[j] = array[i];
				j++;
			} else {
				arrayImpar[k] = array[i];
				k++;
			}
		System.out.println("\n----------------Arrays Par--------------");
		verArray(arrayPar);
		System.out.println("\n---------------Arrays Impar-------------");
		verArray(arrayImpar);

	}

}
