package ejerciciosArrays;
public class Ejercicio01 {

	public static void main(String[] args) {
		// 1.	Programa que declare 2 arrays  de 10 n�meros y llame a m�todos que hagan lo siguiente:
		//			Cargar ambos arrays RANDOM.
		//			Sumarlos obteniendo otro array de 10 n�meros de forma que cada componente sea la suma de las componentes de los dos primeros.
		//			Visualizar el array resultante.
		//			El main debe declarar dos arrays y llamar a estos m�todos.


		int arrays1 []= new int [10];
		int arrays2[] =new int [10];
		
		arrays1=cargarArray();
		System.out.println("El array uno es:");
		verArray(arrays1);
		arrays2=cargarArray();
		System.out.println("El array dos es:");
		verArray(arrays2);
		System.out.println("La suma de los arrays es:");
		verArray(sumar(arrays1, arrays2));
		
}
	
	public static int[] sumar (int[] arr1, int[]arr2){
		int [] suma =new int[arr1.length];
		for (int i = 0; i < arr1.length; i++) {
			suma[i]=arr1[i]+arr2[i];
			
		}
		return suma;
		
	}
	
	public static void verArray(int[] array){
		for (int i=0; i<array.length; i++){
			System.out.print(array[i]+" ");
		}
		System.out.println();
	}
		
	public static int[] cargarArray(){
		int [] array =new int[10];
		for (int i = 0; i < array.length; i++) {
			System.out.println("Introduce un numero");
			int n =LeerTeclado.readInteger();
			array[i]=n ;
		}
		return array;
	}
		
		
	

}
