package ejerciciosArrays;

public class Ejercicio08 {

	public static void main(String[] args) {

		// 8. Dadas dos fechas en formato dd mm, programa que escriba todos los d�as que han transcurrido entre las dos fechas:
		//		Ejemplo: dia1=10   mes1=2        dia2=20 mes2=4
		//		Visualice: 10 de febrero, 11 de febrero, �28 de febrero, 1 de marzo, �, 20 de abril

		int[] dias = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		String[] meses = { "Enero", "Febrero", "Marzo", "Abril", "Mayo",
				"Junio", "Julio", "Agosto", "Septiembre", "Octubre",
				"Noviembre", "Diciembre" };

		int diaI, diaF, mesI, mesF;

		// Pedir los datos por teclado y validarlos
		
		do {
			do {
				System.out.println("Introducir la primera fecha (dia y mes)");
				diaI = LeerTeclado.readInteger();
				mesI = LeerTeclado.readInteger();
			} while (!validarDias(diaI, mesI));
			do {
				System.out.println("Introducir la segunda fecha (dia y mes)");
				diaF = LeerTeclado.readInteger();
				mesF = LeerTeclado.readInteger();
			} while (!validarDias(diaF, mesF));
		} while (!validarDatos(diaI, diaF, mesI, mesF));

		mesI -= 1;
		mesF -= 1;

		int j = diaI;
		System.out.println("\n----------------LOS DIAS QUE HAN TRANSCURRIDO ENTRE LAS DOS FECHAS SON--------------");
		for (int i = mesI; i <= mesF; i++) {
			if (i == mesF) {
				while (j <= diaF) {
					System.out.println(j + " de " + meses[i]);
					j++;
				}
				j = 1;
			} else if (i < mesF) {
				while (j <= dias[i]) {
					System.out.println(j + " de " + meses[i]);
					j++;
				}
				j = 1;
			}
		}
	}


	public static boolean validarDatos(int diaI, int diaF, int mesI, int mesF) {
		if (mesI == mesF) {
			if (diaI < diaF) {
				return true;
			} else
				return false;
		} else if (mesI < mesF) {
			return true;
		} else
			return false;
	}

	public static boolean validarDias(int dia, int mes) {
		if (mes == 2) {
			if (dia <= 28 && dia > 0) {
				return true;
			} else
				return false;
		} else if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8	|| mes == 10 || mes == 12) {
			if (dia <= 31 && dia > 0) {
				return true;
			} else
				return false;
		} else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
			if (dia <= 30 && dia > 0) {
				return true;
			} else
				return false;
		} else
			return false;
	}

}