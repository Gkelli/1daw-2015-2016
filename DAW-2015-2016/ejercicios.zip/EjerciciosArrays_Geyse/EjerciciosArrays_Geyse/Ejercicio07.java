package ejerciciosArrays;

public class Ejercicio07 {

	public static void main(String[] args) {
		// 7. Programa que genere un array de 30 n�meros comprendidos entre 1 y
		// 50 aleatoriamente y los mueva una posici�n hacia la derecha, teniendo
		// en cuenta que el �ltimo pasa a ser el primero.

		int[] arrayRandom = arrayRandom();
		verArray(arrayRandom);
		int[] arrayMovido = moverArray(arrayRandom);
		verArray(arrayMovido);

	}

	public static void verArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}

	public static int[] arrayRandom() {
		int[] arrayRandom = new int[30];
		for (int i = 0; i < 30; i++)
			arrayRandom[i] = (int) (Math.random() * 50) + 1;
		return arrayRandom;
	}

	public static int[] moverArray(int[] array) {
		int[] arrayMov = new int[30];
		int i;

		for (i = 0; i < 29; i++) {
			arrayMov[i + 1] = array[i];
		}
		arrayMov[0] = array[29];
		return arrayMov;

	}

}
