package ejerciciosArrays;
public class Ejercicio02 {

	public static void main(String[] args) {
		// 2.	Hacer un programa que trabaje con un array de 10 elementos y llame a m�todos que hagan lo siguiente:
		//			Cargar el array desde teclado con enteros
		//			Visualizar las posiciones de los elementos con contenido menor de 17
		//			Calcular la suma de los elementos del array (el resultado se visualizar� en el programa principal).
		//			Visualizar el total de  ceros, positivos y negativos que hay en las posiciones pares del array
		//			Hallar el elemento mayor del array y cu�ntas veces se repite.

		int arrays1 []= new int [10];
		

		arrays1= cargarArrays();
		
		System.out.println("\n----------------LA LISTA DE ARRAYS ES--------------");
		System.out.println("El array es:");
		visualizarArrays(arrays1);	
		
		System.out.println("\n----------------LA LISTA DE ARRAYS MENOR DE 17 SON--------------");
		System.out.println("El array menor a 17 es:");
		posicionArrays(arrays1);		
		
		System.out.println("\n----------------LA SUMA DE ARRAYS ES--------------");
		System.out.println("La suma de los arrays es:");
		System.out.println(suma(arrays1));
		
		System.out.println("\n----------------EL TOTAL DE CEROS,POSITIVOS Y NEGATIVOS PARES SON--------------");
		totalArrays(arrays1);
		
		System.out.println("\n----------------EL ELEMNTO MAYOR DE ARRAYS Y LAS VECES QUE SE REPITEN SON--------------");
		mayorArray(arrays1);


		
		
		
	}
	
	
	//			Cargar y visualizar el array desde teclado con enteros, creo dos m�todos
	
	public static int[] cargarArrays(){
		int array []= new int [10];
		int i;
		for(i=0; i < array.length; i++){
			System.out.println("Introduce un numero entero");
			int n =LeerTeclado.readInteger();
			array[i]=n ;
		}
		return array;
	}
	
	public static void visualizarArrays(int[] array ){
		int i;
		for(i=0; i < array.length; i++){
			System.out.print(array[i]+" ");

		}
		System.out.println();
	}
	
	
	
	//			Visualizar las posiciones de los elementos con contenido menor de 17
	
	public static void posicionArrays (int[] array){
		int j;
		for(j=0; j<array.length; j++){			
			if(array[j]<=17){
			System.out.print(array[j]+" ");
			}
		}
		System.out.println();
	}
	
	
	//			Calcular la suma de los elementos del array (el resultado se visualizar� en el programa principal).
	
	public static double suma (int[] arrays1){
		int  suma = 0;
		for (int i = 0; i < arrays1.length; i++) {
			suma=suma+arrays1[i];
		}
		return suma;
		
	}

	//			Visualizar el total de  ceros, positivos y negativos que hay en las posiciones pares del array
	
	public static void totalArrays(int[] arrays1) {
		int pos = 0, neg = 0, cero = 0;
		int i;
		for (i = 0; i < arrays1.length; i += 2) {
			if (arrays1[i] > 0) {
				pos++;
			} else if (arrays1[i] < 0) {
				neg++;
			} else {
				cero++;
			}
		}
		System.out.println("El total de ceros de array es " + cero);
		System.out.println("El total de positivos de array es " + pos);
		System.out.println("El total de negativos de array es " + neg);
	}
	
	//			Hallar el elemento mayor del array y cu�ntas veces se repite.
		
	public static void mayorArray (int[] arrays1){
			int maximo=Integer.MIN_VALUE;
			int contador=0;
			for (int i = 0; i < arrays1.length; i++) {
				if (arrays1[i]>maximo)
					maximo=arrays1[i];
				}

			for(int i=0; i<arrays1.length; i++){
				if (arrays1[i] == maximo)
				contador++;
				}
			System.out.println("el elemento mayor es " +maximo+ " y el n�mero de veces que se repite es " +contador);
	}
	
	
	
	
	
	
	
}
