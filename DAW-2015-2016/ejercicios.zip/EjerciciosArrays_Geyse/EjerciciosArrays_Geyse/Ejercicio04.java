package ejerciciosArrays;

public class Ejercicio04 {

	public static void main(String[] args) {
		
		// 4. Programa que recibe una cantidad de dinero, y devuelve el mejor desglose de dinero en billetes y monedas de curso legal:
		//		Ejemplo: 129876,78 �
		//		Los billetes y monedas ser�n: 500, 100, 50, 20, 10, 5, 2, 1, 0.50, 0.20, 0.10, 0.05, 0.02, 0.01
		
		
		double[] billetesMonedas = {500, 100, 50, 20, 10, 5, 2, 1, 0.50, 0.20, 0.10, 0.05, 0.02, 0.01};
		int[] cantidadBilletesMonedas = new int[billetesMonedas.length];
		
		double cantidad;
		System.out.println("Introduce cantidad ");
		cantidad = LeerTeclado.readDouble();
		
		int i=0;
		int cociente=0;
		
		while(cantidad!=0){
			cociente=(int)(cantidad/billetesMonedas[i]);
			cantidadBilletesMonedas[i]=cociente;
			cantidad=cantidad-(cociente*billetesMonedas[i]);
			cantidad=redondear(cantidad, 2);
			i++;
		}
		
		for(int j=0;j<billetesMonedas.length;j++){
			if(cantidadBilletesMonedas[j]!=0)
				if(billetesMonedas[j]>=5)
					System.out.println("Hay " + cantidadBilletesMonedas[j] + " billetes de " +billetesMonedas[j]);
				else System.out.println("Hay " + cantidadBilletesMonedas[j] + " monedas de " +billetesMonedas[j]);
			
		}
		System.out.println();
	}
	
	// m�todo para redondear un n�mero a dos cifras decimales
	
	public static double redondear( double num, int dec ) {
	    return Math.round(num*Math.pow(10,dec))/Math.pow(10,dec);
	  }	
	
		
		

	

}
