package ejerciciosArrays;

public class Ejercicio05 {

	public static void main(String[] args) {
		/* 5. Dado un n�mero de 6 cifras y una cifra entre 0 y 9 decidir: Si
		 * dicha cifra est� en el n�mero. Las veces que se repite en caso
		 * afirmativo
		 */

		int cifra, numero, cifr;
		
		// comprobar que el numero de cifras es igual a 6
		do {
			System.out.println("Introduce numero de 6 cifras");
			numero = LeerTeclado.readInteger();
			cifr = calcularCifras(numero);
		} while (cifr != 6);

		// comprobar que solo se introduce una cifra
		do {
			System.out.println("Introduce una cifra");
			cifra = LeerTeclado.readInteger();
			cifr = calcularCifras(cifra);
		} while (cifr != 1);

		// bucle que almacena cifra de cada posicion
		int[] numeroArray = new int[calcularCifras(numero)];
		for (int i = 0; i < numeroArray.length; i++) {
			numeroArray[i] = numero % 10;
			numero /= 10;
		}

		// contar cuantas veces aparece cada numero 
		int contador = 0;
		for (int i = 0; i < numeroArray.length; i++) {
			if (cifra == numeroArray[i])
				contador++;
		}

		System.out.println((contador == 0) ? "La cifra " + cifra + " no aparece ninguna vez" : "La cifra " + cifra + " aparece " + contador + ((contador == 1) ? " vez" : " veces"));
	}

	// metodo que calcula el numero de cifras del numero
	public static int calcularCifras(int num) {
		int cifras = 0;
		while (num != 0) {
			num /= 10;
			cifras++;
		}
		return cifras;
	}

}
