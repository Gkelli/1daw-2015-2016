package subirNota;

public class Ejercicio01 {
	
	public static void main(String[] args) {		
		
		System.out.println("Introduce dos numeros");
		int n =LeerTeclado.readInteger();
		int m = LeerTeclado.readInteger();
		
		int array_n [] = new int[n];
		int array_m [] = new int[m];
		
		System.out.println("Cargar primer array");
		cargar_array(array_n);
		System.out.println("\nCargar segundo array");
		cargar_array(array_m);
		
		ver_array(array_n);
		ver_array(array_m);
		
		System.out.println("\n�Est�n contenidos?");
		esta_contenido(array_n, array_m);

	}
	

	public static void ver_array(int[] array){
		System.out.println("\nVer array :" );
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}
	
	public static void cargar_array(int[] array){
		int n;
		for (int i = 0; i < array.length; i++) {
			System.out.println("Introduce numero");
			n = LeerTeclado.readInteger();
			array[i]=n;
		}
	}
	
	public static void esta_contenido(int array1[], int array2[]){
		boolean contenido = true;
		
		for (int i = 0; i < array1.length && contenido ; i++) {			
				if(array1[i]!=array2[i]){
					contenido = false;				
			}
		}
		
		if (contenido) 
			System.out.println("Est�n contenidos los arrays");
		else
			System.out.println("No est�n contenidos los arrays");
	}
	
	
	

}
