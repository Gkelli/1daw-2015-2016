package subirNota;

public class EjercicioSubirNota {

	public static void main(String[] args) {
		
		System.out.println("Introduce dos numeros");
		int n =LeerTeclado.readInteger();
		int m = LeerTeclado.readInteger();
		
		int array_n [] = new int[n];
		int array_m [] = new int[m];
		
		System.out.println("Cargar primer array");
		cargar_array(array_n);
		ver_array(array_n);
		System.out.println("\nCargar segundo array");
		cargar_array(array_m);
		ver_array(array_m);
		System.out.println("\n�Est�n contenidos?");
		esta_contenido(array_n, array_m);
		System.out.println("\nOrdenar arrays y �est�n contenidos? :");
		ordenar_array(array_n);
		esta_contenido(array_n, array_m);
	}
	
	public static void ver_array(int[] array){
		System.out.println("Ver array :" );
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}
	
	public static void cargar_array(int[] array){
		int n;
		for (int i = 0; i < array.length; i++) {
			System.out.println("Introduce numero");
			n = LeerTeclado.readInteger();
			array[i]=n;
		}
	}
	
	public static void esta_contenido(int array1[], int array2[]){
		boolean contenido = false;
		
		for (int i = 0; i < array1.length ; i++) {
			contenido=false;
			for (int j = 0; j < array2.length; j++) {
				if(array1[i]==array2[j]){
					contenido = true;
				}
			}
		}
		
		if (contenido) 
			System.out.println("Est�n contenidos los arrays");
		else
			System.out.println("No est�n contenidos los arrays");
	}
	
	public static void ordenar_array(int[] array){
		for (int i = 0; i < array.length-1; i++) {
			if(array[i]>array[i+1]){
				int aux=array[i];
				array[i]=array[i+1];
				array[i+1]=aux;
			}
		}
		
	}

}
