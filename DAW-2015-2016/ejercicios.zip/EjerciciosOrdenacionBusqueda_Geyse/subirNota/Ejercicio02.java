package subirNota;

public class Ejercicio02 {

	public static void main(String[] args) {
		
		System.out.println("Introduce dos numeros");
		int n =LeerTeclado.readInteger();
		int m = LeerTeclado.readInteger();
		
		int array_n [] = new int[n];
		int array_m [] = new int[m];
		
		System.out.println("Cargar primer array");
		cargar_array(array_n);
		System.out.println("\nCargar segundo array");
		cargar_array(array_m);
		
		ver_array(array_n);
		ver_array(array_m);
		
		System.out.println("\n�Est�n contenidos?");
		esta_contenido(array_n, array_m);

	}
	

	public static void ver_array(int[] array){
		System.out.println("\nVer array :" );
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}
	
	public static void cargar_array(int[] array){
		int n;
		for (int i = 0; i < array.length; i++) {
			System.out.println("Introduce numero");
			n = LeerTeclado.readInteger();
			array[i]=n;
		}
	}
	
	public static void esta_contenido(int array_1[], int array_2[]){

		boolean contenido = false;
		int aux;
		for (int i = 0; i < array_2.length; i++) {
			if (array_1[0] == array_2[i]) {
				aux = 0;
				for (int j = i; j < (i + array_1.length); j++) {
					if (array_1[aux] == array_2[j]) {
						contenido = true;
					} else {
						contenido = false;
						break;
					}
					aux++;
				}
				if (contenido)
					break;
			}

		}
		if (contenido) 
			System.out.println("Est�n contenidos los arrays");
		else
			System.out.println("No est�n contenidos los arrays");
	}
	
	



	
}
