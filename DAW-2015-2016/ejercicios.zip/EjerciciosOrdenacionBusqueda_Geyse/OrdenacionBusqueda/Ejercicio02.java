
public class Ejercicio02 {
	    public static void main(String[] args) {
	    	 
			
	        String departamentos[]={"Informatica", "Contabilidad", "Recursos Humanos", "Administracion", "Compras", "Ventas", "Marketing", "Reparaciones"};
	        int presupuestos[]={80000, 50000, 40000, 12000, 30000, 60000, 55000, 85000};
	 
	        System.out.println("\n--------Departamentos:--------");
	        imprimirDepartamentos(departamentos);
	 
	        System.out.println("\n--------Presupuestos:--------");
	        imprimirPresupuestos(presupuestos);
	        
	        //ordenamos el array
	        burbujaPalabras (departamentos, presupuestos);
	 
			System.out.println("\n-----Ordenar los nombres de Deparamentos alfab�ticamente:-----");
			//buscPalabrasBinario(departamentos);
			verDepartamentos(departamentos);
			verPresupuestos(presupuestos);
			
			
			System.out.println("\n--------Busqueda Binaria o Dicot�mica (Optimizar): --------");
			//buscPalabrasBinario(departamentos);
	        buscPalabras(departamentos, presupuestos);
	        
	        
	        
	        mayorPalabras(departamentos, presupuestos);
	        
	        
	    }
	    
		public static void verDepartamentos (String array[]){
	        for(int i=0;i<array.length;i++){
	            System.out.print(array[i]+ " ");
			}
			System.out.println();
		}
	    
		public static void verPresupuestos(int[] array){
			for (int i=0; i<array.length; i++){
				System.out.print(array[i]+" ");
			}
			System.out.println();
		}
			
	    public static void imprimirDepartamentos (String array[]){
	        for(int i=0;i<array.length;i++){
	            System.out.print(array[i]+ " ");
	        }
	    }
	 
	    public static void imprimirPresupuestos (int array[]){
	        for(int i=0;i<array.length;i++){
	            System.out.print(array[i]+ " ");
	        }
	    }
	    
	    public static void burbujaPalabras (String lista_palabras[], int lista_numeros[] ){
	        boolean ordenado=false;
	        int cuentaIntercambios=0;
	        
	        //Usamos un bucle anidado, saldra cuando este ordenado el array
	        while(!ordenado){
	            for(int i=0;i<lista_palabras.length-1;i++){
	                if (lista_palabras[i].compareToIgnoreCase(lista_palabras[i+1])>0){
	                	
	                    //Intercambiamos valores de departamentos
	                    String aux=lista_palabras[i];
	                    lista_palabras[i]=lista_palabras[i+1];
	                    lista_palabras[i+1]=aux;
	                    //indicamos que hay un cambio
	                    cuentaIntercambios++;
	                    
	                    //Intercambiamos valores de presupuestos
	                    int aux2=lista_numeros[i];
	                    lista_numeros[i]=lista_numeros[i+1];
	                    lista_numeros[i+1]=aux2; 
	                    
	                }
	            }
	            //Si no hay intercambios, es que esta ordenado.
	            if (cuentaIntercambios==0){
	                ordenado=true;
	            }
	            //Inicializamos la variable de nuevo para que empiece a contar de nuevo
	            cuentaIntercambios=0;
	        }
        }
	    	public static void buscPalabras (String lista_palabras[], int lista_numeros[]){
	    		boolean encontrado=false;
	    		int posicion=0;

	    		System.out.println("Introduce el departamento a buscar");
	    		String elemento=LeerTeclado.readString();
	    	
	    		for (int i = 0; i < lista_palabras.length && !encontrado; i++) {
	    			for (int j = 0; j < lista_numeros.length && !encontrado; j++) {
		    			if(lista_palabras[i].equalsIgnoreCase(elemento)){
	    				encontrado=true;
	    				posicion=i+1;
	    				
		    				}	  		
	    				}
	    			}
	    		
	    		if (encontrado)
	    			System.out.println("El elemento est� en el array en la posici�n " +posicion+" y su presupuesto es " + lista_numeros[posicion-1]);
	    		else
	    			System.out.println("Lo sentimos, no hay ning�n departamento con ese nombre ");
	    	

	    }
	    	
	    public static void mayorPalabras (String lista_palabras[], int lista_numeros[]){
	    	int max=Integer.MIN_VALUE;
	    	String aux = null;
	    	
	  		for (int i = 0; i < lista_numeros.length; i++) {
	  				
	    			if(lista_numeros[i]>max){
	    				max=lista_numeros[i];
	    				aux=lista_palabras[i];
	    				}	
	    	}
	    	System.out.println("El nombre del departamento de mayor presupuesto es "+aux+ " con presupuesto : "+max);
		    
	    }
	    
}
