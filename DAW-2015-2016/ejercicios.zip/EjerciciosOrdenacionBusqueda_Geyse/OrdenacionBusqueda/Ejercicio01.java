
public class Ejercicio01 {

	public static void main(String[] args) {
		//  Crear un array de 30 posiciones cargado con n�meros generados aleatoriamente  entre 1 y 100. Se pide:
		//		a)	Introducir un n� comprendido entre 1 y 100 y buscarlo en el array con b�squeda secuencial. El proceso debe indicar 
		//			si se encuentra el elemento o no y, en caso afirmativo, en qu� posici�n.
		//		b)	Ordenar el array crecientemente.
		//		c)	Repetir el apartado a). La b�squeda secuencial se debe optimizar para deducir que el n�mero no est� en el array ordenado si se encuentra uno mayor que el buscado.
		//		d)	Repetir el apartado a) utilizando b�squeda binaria o dicot�mica.

		System.out.println("-------------------El array es: -----------------");
		int arrays [] = new int [30];
		arrays=cargarArray();
		verArray(arrays);
		System.out.println("\n----------------Posici�n del array: --------------");
		buscArray(arrays);
		System.out.println("\n--------El Array ordenado (crecientemente): --------");
		//imprime el array ordenado	
		ordenArray(arrays);
		verArray(arrays);
		
		System.out.println("\n--------Busqueda Secuencial (Optimizar): --------");
		buscArraySecuencial(arrays);
		verArray(arrays);
		
		
		System.out.println("\n--------Busqueda Binaria o Dicot�mica (Optimizar): --------");
		buscArrayBinaria(arrays);
		verArray(arrays);
		

	}
	

	public static void verArray(int[] array){
		for (int i=0; i<array.length; i++){
			System.out.print(array[i]+" ");
		}
		System.out.println();
	}

	public static int [] cargarArray(){
		int arrays [] = new int [30];
		for (int i = 0; i < arrays.length; i++) {
			arrays[i]= (int) (Math.random() *100) +1;
		
		}
	
	return arrays;
		}
	
	public static void buscArray (int[]array){
		boolean encontrado=false;
		int posicion=0;
		System.out.println("Introduce el elemento a buscar");
		int elemento=LeerTeclado.readInteger();
		
		for (int i = 0; i < array.length && !encontrado; i++) {
			if(array [i]==elemento){
				encontrado=true;
				posicion=i+1;
			}
	
		}
		if (encontrado)
			System.out.println("El elemento est� en el array en la posici�n " +posicion);
		else
			System.out.println("El elemento no est� en el array");
		
		
		
	}
		//ordenaci�n de array
	
	public static void ordenArray (int[]array){
		int aux;
		for (int i = array.length; i>0 ; i--) {
			for (int j = 0; j < i-1; j++) {
				if(array[j]>array[j+1]){
					aux=array[j];
					array[j]=array[j+1];
					array[j+1]=aux;
				}
					
			}
		
		}
	
	}
	
	//Busqueda secuencial
	
	public static void buscArraySecuencial (int[]array){
		boolean encontrado=false;
		int posicion=0;			
		System.out.println("Introduce el elemento a buscar");
			int elemento=LeerTeclado.readInteger();
			
			for (int i = 0; i < array.length && !encontrado; i++) {
				if(array[i]==elemento){
			 		encontrado=true;
			 		posicion=i+1;
				}
				
			}
			if (encontrado)
				System.out.println("El elemento est� en el array en la posici�n " +posicion);
			else
				System.out.println("El elemento no est� en el array");
			
	}
	
	//Busqueda Binaria o Dicot�mica
	
	public static void buscArrayBinaria (int[]array){
		boolean encontrado=false;
		int posicion=0;
		int medio,limInferior,limSuperior;
		System.out.println("Introduce un numero");
		int elemento=LeerTeclado.readInteger();
		
		limInferior=0;
		limSuperior=array.length-1;
		
		do{
		 medio=(limInferior+limSuperior)/2;
		 	if(array[medio]==elemento){
		 		encontrado=true;
		 		posicion=medio+1;
		 	}
		 	else
		 		if (array[medio]>elemento)
		 			limSuperior=medio-1;
		 		else
		 			limInferior=medio+1;
		}
		while (!encontrado && limInferior<=limSuperior);
			if (encontrado)
				System.out.println("El elemento est� en el array en la posici�n " +posicion);
			else
				System.out.println("El elemento no est� en el array");
	}
}