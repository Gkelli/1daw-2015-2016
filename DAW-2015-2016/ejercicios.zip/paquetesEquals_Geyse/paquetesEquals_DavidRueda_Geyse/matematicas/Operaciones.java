package matematicas;

public class Operaciones {

	public static int sumaNumeros(int n1, int n2) {
		int suma;
		suma = n1 + n2;
		return suma;
	}

	public static int restaNumeros(int n1, int n2) {
		int resta;
		resta = n1 - n2;
		return resta;
	}

	public static int productoNumeros(int n1, int n2) {
		int producto;
		producto = n1 * n2;
		return producto;
	}

	public static double divisionNumeros(int n1, int n2) {
		double cociente = 0;
		if (n2 == 0)
			System.out.println("No es posible dividir entre 0");
		else {
			cociente = (double) (n1 / n2);
		}
		return cociente;

	}

}
