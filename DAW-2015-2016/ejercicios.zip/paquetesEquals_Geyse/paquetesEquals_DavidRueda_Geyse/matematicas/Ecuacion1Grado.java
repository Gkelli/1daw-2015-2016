package matematicas;

public class Ecuacion1Grado {
	
	private int a, b, c;
	
	public Ecuacion1Grado (int a, int b, int c){
		this.a=a;
		this.b=b;
		this.c=c;
	}

	public int getA() {
		return a;
	}


	public int getB() {
		return b;
	}


	public int getC() {
		return c;
	}

	public double solucion (){
		return ((double)(this.c-this.b)/this.a);
	 
	}

	@Override
	public String toString() {
		return "La ecuaci�n 1 Grado (ax + b=c) es "+getA() +"x+"+getB()+"="+getC() + 
				" y su soluci�n es "+ solucion();
	}

	
	public boolean equals(Ecuacion1Grado e) {		
		return (this.solucion() == e.solucion() );
	}


	
	
	
	
	
	

}
