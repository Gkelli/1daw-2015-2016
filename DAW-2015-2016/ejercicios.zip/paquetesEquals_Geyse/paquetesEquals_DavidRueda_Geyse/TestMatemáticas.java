import matematicas.Ecuacion1Grado;
import matematicas.LeerTeclado;
import matematicas.Operaciones;
import matematicas.geometria.TrianguloRectangulo;


public class TestMatem�ticas {
	
	public static void main(String[] args) {
		
		System.out.println("-----CLASE-OPERACIONES-----");
		
		int n1, n2;
		System.out.println("Introduzca dos n�meros");
		n1=LeerTeclado.readInteger();
		n2=LeerTeclado.readInteger();
		System.out.println("La suma es " +Operaciones.sumaNumeros(n1, n2));
		System.out.println("La recta es "+Operaciones.restaNumeros(n1, n2));
		System.out.println("El producto es " +Operaciones.productoNumeros(n1, n2));
		System.out.println("La divisi�n es " +Operaciones.divisionNumeros(n1, n2));
		
	 
		
		System.out.println("\n-------CLASE-ECUACION1-GRADO----------");
		System.out.println("Introduce tres valores" );
		int a=LeerTeclado.readInteger();
		int b=LeerTeclado.readInteger();
		int c=LeerTeclado.readInteger();
		Ecuacion1Grado ecuacion=new Ecuacion1Grado(a,b,c);
		Ecuacion1Grado ecuacion2=ecuacion;
		System.out.println("Probando m�todo equals");
		System.out.println("La Ecuaci�n1Grado1 y la Ecuaci�n1Grado2 son iguales? "+ecuacion.equals(ecuacion2));
		System.out.println("La ecuaci�n de 1 grado es " +ecuacion.toString());
		
		
		
		
		System.out.println("\n-------TRIANGULO_RECTANGULO----------");
		System.out.println("Introduce dos valores para el triangulo");
		double cateto1=LeerTeclado.readDouble();
		double cateto2=LeerTeclado.readDouble();
		TrianguloRectangulo triangulo=new TrianguloRectangulo(cateto1, cateto2);
		TrianguloRectangulo triangulo2=triangulo;
		System.out.println("Probando m�todo equals");
		System.out.println("Tri�ngulo1 y el tri�ngulo2 son iguales? " + triangulo.equals(triangulo2) );
		
		System.out.println("Los catetos del Triangulo Rectangulo " +triangulo.toString());
	
				
		
	}
	
	
                                                                                                                                                  
}
