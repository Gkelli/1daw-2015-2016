package ejercicio;

public abstract class Empleado{
	private String nombre;
	private int edad;
	private double sueldo;
	private int codigo;
	private static int autoNum=0;
	
	public Empleado(){
		
	}
	public Empleado(String nombre, int edad, double sueldo) {
		this.autoNum++;
		this.nombre = nombre;
		this.edad = edad;
		this.sueldo = sueldo;
		this.codigo = autoNum;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public double getSueldo() {
		return sueldo;
	}
	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	public int getCodigoEmpleado(){
		return this.codigo;
	}

	
	@Override
	public String toString() {
		return "[nombre=" + nombre + ", edad=" + edad + ", sueldo="
				+ sueldo + ",";
	}
	
	public abstract void subirSueldo(double porcentaje);
	public abstract String getCodigo();

}
