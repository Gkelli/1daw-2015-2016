package ejercicio;

import java.util.Comparator;

public class OrdenSueldo implements Comparator<Empleado>{
	
	public int compare(Empleado arg0, Empleado arg1) {
		if(arg0.getSueldo()==arg1.getSueldo()){
			return (arg0.getCodigoEmpleado()-arg1.getCodigoEmpleado());
		}
		else{
			if(arg0.getSueldo()>arg1.getSueldo())
				return 1;
			else
				return -1;
		}
	}
}