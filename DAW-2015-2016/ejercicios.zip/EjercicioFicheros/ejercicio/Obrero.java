package ejercicio;

public class Obrero extends Empleado{
	private String codObrero="O";
	private String nombreJefe;
	
	public Obrero(){
		
	}
	public Obrero(String nombre, int edad, double sueldo ,String jefe) {
		super(nombre, edad, sueldo);
		this.codObrero+=super.getCodigoEmpleado();
		this.nombreJefe = jefe;
	}


	public String getNombreJefe() {
		return nombreJefe;
	}
	public void setNombreJefe(String nombreJefe) {
		this.nombreJefe = nombreJefe;
	}
	
	public String getCodigo() {
		return codObrero;
	}

	@Override
	public void subirSueldo(double porcentaje) {
		super.setSueldo(super.getSueldo()*porcentaje);
	}
	@Override
	public String toString() {
		return  super.toString() + "codObrero=" + codObrero + ", jefe=" + nombreJefe
				+"]";
	}

	
	

}
