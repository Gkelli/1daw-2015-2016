package ejercicio;

import java.util.Collections;
import java.util.Vector;
import java.util.ArrayList;

public class Empresa {
	private Vector <Empleado> vectorEmpleado;
	
	public Empresa(){
		vectorEmpleado=new Vector <Empleado> ();
	}
	
	public void altaEmpleadoJefe(String nombre, int edad, double sueldo){
		Jefe aux=new Jefe(nombre, edad, sueldo);
		vectorEmpleado.add(aux);
	}
	public void altaEmpleadoObrero(String nombre, int edad, double sueldo, String nombreJefe, int posJefe){
		Obrero aux=new Obrero(nombre, edad, sueldo, nombreJefe);
		vectorEmpleado.add(aux);
		((Jefe)vectorEmpleado.elementAt(posJefe)).getArrayObreros().add(aux);
	}
	
	public void subirSueldo(double porcentaje){
		for(int i=0; i<vectorEmpleado.size(); i++){
			vectorEmpleado.elementAt(i).subirSueldo(porcentaje);
		}
	}
	
	public void listarObrerosDeJefe(int posicionJefe){
		ArrayList <Obrero> aux=((Jefe)vectorEmpleado.elementAt(posicionJefe)).getArrayObreros();
		for(int i=0; i<aux.size(); i++){
			System.out.println(aux.get(i).getNombre());
		}
	}
	
	public void listarJefeDeObrero(int posicionObrero){
		System.out.println(vectorEmpleado.elementAt(posicionObrero).getCodigo());
		System.out.println(((Obrero)vectorEmpleado.elementAt(posicionObrero)).getNombreJefe());
	}
	
	public void datosEmpleado(int posicionEmpleado, boolean jefe){
		if(jefe)
			System.out.println(((Jefe)vectorEmpleado.elementAt(posicionEmpleado)).toString());
		else
			System.out.println(((Obrero)vectorEmpleado.elementAt(posicionEmpleado)).toString());
	}
	
	public void listarEmpleados(){
		System.out.println(vectorEmpleado);
	}
	
	public void bajaEmpleado(int posicion){
		//		BAJA OBRERO 	//	
		if(vectorEmpleado.elementAt(posicion) instanceof Obrero){
			if(((Obrero)vectorEmpleado.elementAt(posicion)).getNombreJefe()!=null){
				int posicionJefe=check(((Obrero)vectorEmpleado.elementAt(posicion)).getNombreJefe());
				int posicionObrero=-1;
				ArrayList <Obrero> aux=((Jefe)vectorEmpleado.elementAt(posicionJefe)).getArrayObreros();
				String nombreObrero=((Obrero)vectorEmpleado.elementAt(posicion)).getNombre();
				for(int i=0; i<aux.size() && posicionObrero==-1; i++){
					if(aux.get(i).getNombre().equalsIgnoreCase(nombreObrero))
						posicionObrero=i;
				}
				((Jefe)vectorEmpleado.elementAt(posicionJefe)).getArrayObreros().remove(posicionObrero);
			}
			vectorEmpleado.removeElementAt(posicion);
		}
		//		BAJA JEFE 		//	
		else{
			String nombreJefe=((Jefe)vectorEmpleado.elementAt(posicion)).getNombre();
			for(int i=0; i<vectorEmpleado.size(); i++){
				if(vectorEmpleado.elementAt(i) instanceof Obrero){
					if(((Obrero)vectorEmpleado.elementAt(i)).getNombreJefe().equals(nombreJefe))
						((Obrero)vectorEmpleado.elementAt(i)).setNombreJefe(null);
				}
			}
			vectorEmpleado.removeElementAt(posicion);
		}
	}
	
	public int check(String nombre){
		int posicion=-1;
		for(int i=0; i<vectorEmpleado.size() && posicion==-1; i++){
			if((vectorEmpleado.elementAt(i).getNombre()).equalsIgnoreCase(nombre))
				return posicion=i;
		}
		return posicion;
	}
	
	public int checkCodigo(String codigo){
		int posicion=-1;
		for(int i=0; i<vectorEmpleado.size() && posicion==-1; i++){
			if((vectorEmpleado.elementAt(i).getCodigo()).equalsIgnoreCase(codigo))
				return posicion=i;
		}
		return posicion;
	}
	
	public boolean isJefe(int posicion){
		return vectorEmpleado.elementAt(posicion) instanceof Jefe;
	}
	
	
	public void ordenPorSueldo(){
		Collections.sort(vectorEmpleado, new OrdenSueldo());
		for(int i=0; i<vectorEmpleado.size(); i++)
			System.out.println(vectorEmpleado.get(i).toString());
	}

}
