package ejercicio;

import java.util.ArrayList;

public class Jefe extends Empleado{
	private String codJefe="J";
	private ArrayList <Obrero> arrayListObreros;
	
	public Jefe(){
		
	}
	public Jefe(String nombre, int edad, double sueldo) {
		super(nombre, edad, sueldo);
		this.codJefe+=super.getCodigoEmpleado();
		this.arrayListObreros = new ArrayList <Obrero>();
	}

	public ArrayList<Obrero> getArrayObreros() {
		return arrayListObreros;
	}
	public void setArrayObreros(ArrayList<Obrero> arrayObreros) {
		this.arrayListObreros = arrayObreros;
	}
	
	public String getCodigo() {
		return codJefe;
	}

	@Override
	public void subirSueldo(double porcentaje) {
		super.setSueldo((super.getSueldo()*porcentaje)+120);
	}
	@Override
	public String toString() {
		return super.toString() + "codJefe=" + codJefe + "]" ;
	}

	
}
