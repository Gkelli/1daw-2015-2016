package primeros_metodos;
import java.io.*;
import java.util.*;
                   /*  Ejemplo de programa para tratar ficheros  */
public class Ficheros_lectura_escritura {          // s�lo tiene el m�todo main
	
	public static void main (String [] args) throws IOException{
		String nombre = " ";
		Boolean sigue = true;

		System.out.print("nombre del fichero?");  
		  // Por ejemplo, Ficheros_lectura_escritura.java o cualquier otro fichero que est� dentro del folder src donde se ha puesto �ste
		String nomFichero= LeerTeclado.readString();
		System.out.print("nombre del directorio?");
		  // el directorio donde est� el fichero copiado empezando por src (en Eclipse): toda la ruta
		String nomDirectorio= LeerTeclado.readString();
		  // creo el objeto con estos datos:
		File fichero_1 = new File(nomDirectorio, nomFichero);
		if (fichero_1.isFile()) System.out.println(nomDirectorio+"/"+nomFichero+" es un fichero.\n");
		else  if (fichero_1.exists()) System.out.println(nomFichero+" es una carpeta v�lida.");
		else System.out.println(nomDirectorio+"/"+nomFichero+" no se encuentra.");

		System.out.print("nombre del directorio?");
		  // Si se utiliza una variable String para designar la ruta, �sta debe ir con separadores'\'
		  // porque los '/' se interpretan con "escapes" dentro de un string
		  // Por ejemplo:   "src\primeros_metodos"
		nomDirectorio= LeerTeclado.readString();
		 // creo el objeto con estos datos:
		File fichero_2 = new File(nomDirectorio);
		if (fichero_2.exists()) System.out.println(nomDirectorio+" es una carpeta v�lida.");
		else System.out.println(nomDirectorio+" no existe.");
		if (!fichero_2.isFile()) System.out.println(nomDirectorio+" es un directorio.");
			else System.out.println(nomDirectorio+" es un fichero.");
		
		System.out.println("La ruta de "+ fichero_1.toString()+" es "+fichero_1.getPath());
		  // el toString de fichero_1 es la concatenaci�n de los 2 string que se usaron para construirlo 
		System.out.println("La ruta absoluta de "+ fichero_1.toString()+" es "+fichero_1.getAbsolutePath());
  
				/*   Vamos a leer un fichero  que ya existe en nuestro PC    *
				 *   utilizando la clase Scanner que recoge l�neas (strings) *
				 *   de una entrada (ficheros o stream) y es f�cil de usar 	 */
		
		String fichero = "nombres.txt";    // este fichero se utilizar� m�s abajo para escribir en �l
		
	       /* aqu� hay que poner el path del fichero nombres.txt: */
		File fichero_3 = new File ("D:/Angel/Documents/IES", fichero);  // creo el objeto de tipo File
		if (fichero_3.exists()) {
			System.out.print(fichero + " ha sido localizado");
			if (fichero_3.isFile()) System.out.println(" y es un fichero");
			System.out.println("Su ruta de acceso es " + fichero_3.getAbsolutePath());
		}
		// bucle para leer los datos del fichero:
		Scanner entrada = new Scanner (fichero_3);   // creo el objeto tipo Scanner
		System.out.println("Contiene los siguientes datos:");
		while (entrada.hasNext()){                   // hago bucle mientras queden datos en el fichero 
			nombre = entrada.nextLine();             // cargo los datos le�dos en la variable nombre
			System.out.println("Nombre: " + nombre);
		}
		entrada.close();     	 // se cierra el fichero despu�s de haberlo le�do
		
	/*   Vamos a escribir en un fichero  que ya existe en nuestro PC. Para ello    *
	 *   1� hacemos que el fichero sea escritor: le asociamos un objeto FileWriter *
	 *   2� este objeto lo adaptamos para poder "printar" en �l (como en pantalla) *
	 *   Por ejemplo:  salida = new PrintWriter (objeto FileWriter)                *
	 *   3� utilizamos el m�todo println sobre los strings que queremos escribir   *
	 *   como hacemos al sacarlos por pantalla (por el stream System.out)          */
		
		FileWriter fWriter = new FileWriter(fichero_3, true);  
		// true si queremos A�ADIR y false si queremos "machacar" el contenido previo del fichero
		PrintWriter escritura = new PrintWriter(fWriter);
		System.out.println("A�ado cosas en " + fichero_3);
		Scanner salida = new Scanner (System.in);
		nombre = ""; sigue = true;
		while (sigue){
			nombre = salida.nextLine();
			// System.out.println("a�adir� " + nombre);
			if (!nombre.equalsIgnoreCase("FIN")) escritura.println(nombre);
			else sigue = false;
		}
		escritura.flush(); escritura.close(); // salida.close();
		
	/* Si queremos escribir en un fichero que a�n no existe, lo creamos */
		
		fWriter = new FileWriter("D:/Angel/Documents/IES/datos.dat"); // no pongo TRUE porque No voy a a�adir nada (el fichero es nuevo)
		escritura = new PrintWriter(fWriter);
	/* antes deber�amos habernos asegurado de que existe D:/Angel/Documents/IES/"            *
	 * y de que es un directorio (como ve�amos al comienzo). Y, si no quer�amos              *
	 * "machacar" nada en un fichero existente, tambi�n deber�amos asegurarno de que         *
	 * datos.dat no existe. Asimismo las sentencias siguientes deber�an ir entre try - catch */
		
		System.out.println("Empezar a escribir en D:/Angel/Documents/IES/datos.dat");
		String linea = ""; sigue = true;
		while (sigue){
			linea = salida.nextLine();
			//System.out.println("escribir� " + linea);
			if (!linea.equalsIgnoreCase("FIN")) escritura.println(linea);
			else sigue = false;
		}
	/* para cerciorarnos de que se ha creado datos.dat con las l�neas que hemos introducido,    *
	 * vamos al directorio D:/Angel/Documents/IES (o el que hayas puesto en tu PC y lo abrimos  *
	 * como �ste no es tipo txt sino .dat (m�s gen�rico), habr� que indicar al sistema que use  * 
	 * 'bloc de notas' o WordPad para abrirlo (igualmente podr�amos haber metido una imagen).   */
	 
		escritura.flush(); escritura.close(); salida.close();
	}
}
