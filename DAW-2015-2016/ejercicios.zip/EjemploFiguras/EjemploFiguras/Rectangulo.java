
public class Rectangulo {
	private int base;
	private int altura;
	public static String color; 
	/*variable compartida por toda la clase
	 * si cambia en alg�n objeto cambia para todos 
	 */
	
	public Rectangulo(){
		base=1;
		altura=1;
		color="blanco";
	}
	
	public Rectangulo(int base){
		this.base=base;
		this.altura=this.base*2;
	}
	
	public Rectangulo(int base, int altura){
		this.base=base;
		this.altura=altura;
	}
	
	public Rectangulo (int base, int altura, String color){
		this();
		this.color=color;
		/*ser�a m�s correcto: 
		Rectangulo.color=color;
		ya que es variable de la clase y no del objeto
		*/ 
	}
	
	public int getBase(){
		return base;
	}
	public void setBase(int base){
		this.base=base;
	}
	
	public void divideBase(){
		this.base/=2;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}
	
	public double area(){
		return base*altura;
	}
	
	public double perimetro(){
		return 2*base+2*altura;
	}
	
	public boolean areaMayor(Rectangulo r){
		/*if (this.area()>=r.area())
			return true;
		else
			return false;*/
		
		return (this.area()>=r.area());
		
	}
	
	

	@Override
	public String toString() {
		return "Rectangulo [base=" + base + ", altura=" + altura + ", area="
				+ area() + ", perimetro=" + perimetro() + "]";
		
	}
	
	
	

}
