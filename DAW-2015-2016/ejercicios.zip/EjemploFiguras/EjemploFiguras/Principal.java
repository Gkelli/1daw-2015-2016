
public class Principal {

	public static void main(String[] args) {
		Rectangulo r1=new Rectangulo();
		Rectangulo r2=new Rectangulo(2);
		Rectangulo r3=new Rectangulo(3, 5);
		
		//Hasta ahora todos los rectangulo tienen color "blanco"
		
		System.out.println(r1.toString());
		System.out.println(r2.toString());
		System.out.println(r3.toString());
		
		System.out.println("Imprimimos el color de los rectangulos");
		System.out.println("Color de r1 "+r1.color);
		System.out.println("Color de r2 "+r2.color);
		System.out.println("Color de r3 "+r3.color);
		
		//creamos otro rectangulo con el color verde
		
	
		Rectangulo r4=new Rectangulo(6, 2, "verde");
		
		System.out.println(r1.toString());
		System.out.println(r2.toString());
		System.out.println(r3.toString());
		System.out.println("Imprimimos el color de los rectangulos");
		System.out.println("Color de r1 "+r1.color);
		System.out.println("Color de r2 "+r2.color);
		System.out.println("Color de r3 "+r3.color);
		System.out.println("Color de r4 "+r4.color);
		
		//Deber�amos haber escrito:
		System.out.println("Color de los rectangulos "+Rectangulo.color);
		
		if(r1.area()>r2.area())
			System.out.println("El area del rect r1 es mayor que la del r2");
		else
			System.out.println("El area del rect r2 es mayor que la del r1");
		
		if (r1.areaMayor(r2))
			System.out.println("El area del rect r1 es mayor que la del r2");
		else
			System.out.println("El area del rect r2 es mayor que la del r1");
			
		
	}
	
	public static void compararAreas(Rectangulo r1, Rectangulo r2){
		if (r1.area()>=r2.area())
			System.out.println("El area del rect r1 es mayor que la del r2");
		else
			System.out.println("El area del rect r2 es mayor que la del r1");
		
		if (r1.areaMayor(r2))
			System.out.println("El area del rect r1 es mayor que la del r2");
		else
			System.out.println("El area del rect r2 es mayor que la del r1");
			
	}

}
