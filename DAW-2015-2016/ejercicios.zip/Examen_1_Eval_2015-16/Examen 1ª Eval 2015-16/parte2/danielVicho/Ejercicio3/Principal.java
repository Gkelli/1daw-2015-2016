package parte2.danielVicho.Ejercicio3;

import parte1_JashmineAlmanza.LeerTeclado;

public class Principal {

	public static void main(String[] args) {
		int numero, suma, sumaRec;
		
			
		System.out.println("introduzca una serie de n�meros positivos. 0=FIN:");
		numero=introdNumero();
		
		while(numero!=0){
			
			suma=cifras(numero);

			if(suma%3==0)
				System.out.println(numero+" es divisible por 3 porque la suma de sus cifras es "+suma+" que es m�ltiplo de 3.");
			else
				System.out.println(numero+" no es divisible por 3 porque la suma de sus cifras es "+suma+" que no es m�ltiplo de 3.");
			
			//para probar la recursividad
		
			sumaRec=cifrasRec(numero);
			
			System.out.println("Ejecutamos de forma recursiva");
			
			if(sumaRec%3==0)
				System.out.println(numero+" es divisible por 3 porque la suma de sus cifras es "+sumaRec+" que es m�ltiplo de 3.");
			else
				System.out.println(numero+" no es divisible por 3 porque la suma de sus cifras es "+sumaRec+" que no es m�ltiplo de 3.");
			
			
			System.out.println("introduzca una serie de n�meros positivos. 0=FIN:");			
			numero=introdNumero();
		}
		
		System.out.println("Adi�s.");
		
	}
	
	public static int introdNumero(){
		
		int num;
		do{
			num=LeerTeclado.readInteger();
			
			if (num<0)
				System.out.println("el n�mero no puede ser negativo");
		}

		while (num<0);
		return num;
		
	}
	
	public static int cifras(int numero){
		int sumaCifra=0;
		while (numero>=10){
			sumaCifra+=(numero%10);
			numero/=10;
		}
		return sumaCifra+numero;
	}
	
	public static int cifrasRec(int numero){ //Ejercicio 4
		if(numero<10)
			return numero;
		else 
			return numero%10+cifrasRec(numero/10);
	}

}
