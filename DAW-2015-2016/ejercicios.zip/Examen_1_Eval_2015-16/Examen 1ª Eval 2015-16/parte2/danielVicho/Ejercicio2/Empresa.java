package parte2.danielVicho.Ejercicio2;

import parte1_JashmineAlmanza.LeerTeclado;

public class Empresa {

	public static void main(String[] args) {
		String ans="", nombre, nombreMinimo="";
		int puntuacion, ranking, rankingMinimo=Integer.MAX_VALUE;
		
		do{
			System.out.println("introduzca el nombre del atleta:");
			nombre=LeerTeclado.readString();
			System.out.println("Introduzca su puntuaci�n:");
			puntuacion=LeerTeclado.readInteger();
			Atleta atleta=new Atleta(nombre, puntuacion);
			System.out.println(atleta.toString());
			
			ranking=atleta.calcularPosicionRanking();
			
			if(ranking<rankingMinimo){
				nombreMinimo=atleta.getNombre();
				rankingMinimo=ranking;
			}
							
			System.out.println("�Repetir operaci�n? S/N");
			ans=LeerTeclado.readString();
		
			
		}while(ans.equalsIgnoreCase("s"));
		
		System.out.println("El atleta con la menor posici�n en el ranking es: "+nombreMinimo);

	}

}
