package parte2.danielVicho.Ejercicio2;

public class Atleta {
	private static int contAtleta;
	private String nombre;
	private int puntuacion;
	
	
	public Atleta(String nombre, int puntuacion) {
		contAtleta++;
		this.nombre = nombre;
		this.puntuacion = puntuacion;
	}


	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPuntuacion() {
		return puntuacion;
	}

	public void setPuntuacion(int puntuacion) {
		this.puntuacion = puntuacion;
	}

	public static int getContAtleta() {
		return contAtleta;
	}
	
	
	public int calcularPosicionRanking(){
		return puntuacion/contAtleta;
	}


	public String toString() {
		return "Atleta [nombre=" + nombre + ", puntuacion=" + puntuacion
				+ ", calcularPosicionRanking()=" + calcularPosicionRanking()
				+ "]";
	}

}
