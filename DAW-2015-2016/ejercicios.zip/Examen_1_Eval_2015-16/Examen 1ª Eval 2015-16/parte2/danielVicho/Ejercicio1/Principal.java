package parte2.danielVicho.Ejercicio1;

import parte1_JashmineAlmanza.LeerTeclado;

public class Principal {

	public static void main(String[] args) {
		int record, puntuacion, pAnterior=0, contAtleta=0, puntMaxima=Integer.MIN_VALUE;
		String nombre, nombreMaximo="";
			
		
		do{
			System.out.println("Introduce la puntuaci�n r�cord:(entre 0 y 10):");
			record=LeerTeclado.readInteger();
		}while(record <0 || record >10);
		
		
		for(int i=1; i<=15; i++){
			
			System.out.println("Introduce el nombre del atleta:");
			nombre=LeerTeclado.readString();
			
			do{
				System.out.println("Introduce su puntuaci�n (entre 0 y 10):");
				puntuacion=LeerTeclado.readInteger();
			}while(puntuacion<0 || puntuacion>10);
			
			if(puntuacion>record){
				contAtleta++;
			}	
			else {
				if(puntuacion>puntMaxima){
					nombreMaximo=nombre;
					puntMaxima=puntuacion;
				}
				
			}
					
		}
		
		if (puntMaxima!=Integer.MIN_VALUE)
			System.out.println("El atleta con mayor puntuaci�n pero que no ha superado el r�cord ha sido: "+nombreMaximo);
		
		System.out.println("El porcentaje de atletas cuya puntuaci�n ha superado el r�cord ha sido: "+((double)contAtleta/15*100)+"%");
	}

}
