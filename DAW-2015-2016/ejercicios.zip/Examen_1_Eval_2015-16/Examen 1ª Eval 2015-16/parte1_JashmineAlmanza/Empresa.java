package parte1_JashmineAlmanza;

public class Empresa {

	public static void main(String[] args) {
		String nombre, turno;
		int horas;
		double totalPagar=0;
		for(int i=1; i<=15; i++){
			
			do{
				System.out.println("Introduce el nombre nombre ");
				nombre=LeerTeclado.readString();
				if(nombre.isEmpty())
					System.out.println("el nombre no puede estar en blanco");
			}while(nombre.isEmpty());

			do{
				System.out.println("introduce las horas trabajadas");
				horas=LeerTeclado.readInteger();
				if(horas<0)
					System.out.println("las horas deben ser mayores a cero");
			}while(horas<=0);

			do{
				System.out.println("introduce el turno del trabajador");
				turno=LeerTeclado.readString();

				if( (!"ma�ana".equalsIgnoreCase(turno)) &&(!"tarde".equalsIgnoreCase(turno))&&( !"noche".equalsIgnoreCase(turno))&&( !"festivo".equalsIgnoreCase(turno)) )
					System.out.println("turnos v�lidos: ma�ana-tarde-noche-festivo");

			}while( (!"ma�ana".equalsIgnoreCase(turno)) &&(!"tarde".equalsIgnoreCase(turno))&&( !"noche".equalsIgnoreCase(turno))&&( !"festivo".equalsIgnoreCase(turno)) );

		
			Empleado emp=new Empleado(nombre, horas, turno);
			emp.calcularSueldo();
			System.out.println("datos del empleado "+i+" :");
			System.out.println(emp.toString());
			
			totalPagar+=emp.calcularSueldo(); //variable que acumula todos los sueldos de los trabajadores
		}
		
		System.out.println("la empresa tiene que pagar "+totalPagar);
		
		



	}

}
