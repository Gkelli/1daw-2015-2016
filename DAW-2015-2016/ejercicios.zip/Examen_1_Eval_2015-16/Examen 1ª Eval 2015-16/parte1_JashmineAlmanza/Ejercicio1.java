package parte1_JashmineAlmanza;


public class Ejercicio1 {

	public static void main(String[] args) {
		int horas, contNoche=0, sumaNoche=0;
		String nombre, turno;
		double sueldo=0,tarifaOrdinaria, sueldoMinFestivo=Integer.MAX_VALUE;
		
		do{	//introduce y valida la tarifa ordinaria	
			System.out.println("Introducir la tarifa ordinaria");
			tarifaOrdinaria=LeerTeclado.readInteger();

			if(tarifaOrdinaria<=0)
				System.out.println("la tarifa debe ser mayor que cero");
		}while(tarifaOrdinaria<=0);	
		
		for(int i=1; i<=15; i++){
							
				do{ //valida que no se quede vac�o el nombre 
					System.out.println("Introduce el  nombre ");
					nombre=LeerTeclado.readString();
					if(nombre.isEmpty())
						System.out.println("el nombre no puede estar en blanco");
				}while(nombre.isEmpty());
				
				do{ //valida que las horas sean mayores que 0
					System.out.println("introduce las horas trabajadas");
					horas=LeerTeclado.readInteger();
					if(horas<=0)
						System.out.println("las horas deben ser mayores a cero");
				}while(horas<=0);
			
			do{ //�dem el turno
				System.out.println("introduce el turno del trabajador");
				turno=LeerTeclado.readString();
					
				if( (!"ma�ana".equalsIgnoreCase(turno)) &&(!"tarde".equalsIgnoreCase(turno))&&( !"noche".equalsIgnoreCase(turno))&&( !"festivo".equalsIgnoreCase(turno)) )
					System.out.println("turnos v�lidos: ma�ana-tarde-noche-festivo");
					
			}while( (!"ma�ana".equalsIgnoreCase(turno)) &&(!"tarde".equalsIgnoreCase(turno))&&( !"noche".equalsIgnoreCase(turno))&&( !"festivo".equalsIgnoreCase(turno)) );
			
			
			//tambi�n podr�a hacerse con switch..case			
			
			if(turno.equals("ma�ana"))
				sueldo=horas*tarifaOrdinaria;				
			
			else
				if(turno.equals("tarde"))
					sueldo=horas*tarifaOrdinaria*1.2;
				
				else
					if(turno.equals("noche")){
				    sueldo=horas*tarifaOrdinaria*1.5;
					contNoche++;
					sumaNoche+=sueldo;					
					}
					else{
						sueldo=horas*tarifaOrdinaria*2;						
						if(sueldo<sueldoMinFestivo)
							sueldoMinFestivo=sueldo;
						}						
				
			System.out.println("sueldo: "+sueldo);
			
			}
				
		//valida que haya cambiado el m�nimo desde que se inicializ�
		if(sueldoMinFestivo!=Integer.MAX_VALUE)
		System.out.println("el sueldo m�nimo del turno festivo es "+sueldoMinFestivo);
		else
			System.out.println("no hay trabajdores en el turno festivo");
		
		//valida que haya alg�n trabajador de noche para hacer la media
		
		if(contNoche==0)
			System.out.println("no se ha introducido ning�n trabajador de turno de noche");
		else
		System.out.println("el salario medio de los trabajadores del turno de noche es "+(double)sumaNoche/contNoche);
			

	}

}
