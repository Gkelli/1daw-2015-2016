package parte1_JashmineAlmanza;

public class Empleado {
	private static final double tarifaOrdinaria=30;
	private String nombreEmpleado;
	private int horasTrabajadas;
	private String turno;
	
	
	public Empleado(String nombreEmpleado, int horasTrabajadoas, String turno) {
		this.nombreEmpleado = nombreEmpleado;
		this.horasTrabajadas = horasTrabajadoas;
		this.turno = turno;
	}


	public String getNombreEmpleado() {
		return nombreEmpleado;
	}


	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}


	public int getHorasTrabajadoas() {
		return horasTrabajadas;
	}


	public void setHorasTrabajadoas(int horasTrabajadoas) {
		this.horasTrabajadas = horasTrabajadoas;
	}


	public String getTurno() {
		return turno;
	}


	public void setTurno(String turno) {
		this.turno = turno;
	}


	public static double getTarifaordinaria() {
		return tarifaOrdinaria; //tambi�n Empleado.tarifaOrdinaria porque es variable est�tica
	}
	
	
	public double calcularSueldo(){ //no se deben pasar como par�metros las horas ni el turno porque son atributos de la clase 
		if(turno.equalsIgnoreCase("ma�ana"))
			return horasTrabajadas*tarifaOrdinaria;
		else{
			if(turno.equals("tarde"))
				return horasTrabajadas*tarifaOrdinaria*1.2;
			else{
				if(turno.equals("noche"))
					return horasTrabajadas*tarifaOrdinaria*1.5;
				else{
					if(turno.equals("festivo"))
						return  horasTrabajadas*tarifaOrdinaria*2;
					else
						return 0;
				}
			}
		}
	}


	@Override
	public String toString() {
		return "Empleado [nombreEmpleado=" + nombreEmpleado
				+ ", horasTrabajadas=" + horasTrabajadas + ", turno=" + turno
				+", sueldo=" + calcularSueldo() + "]";
	}



	
	
	
	

}
