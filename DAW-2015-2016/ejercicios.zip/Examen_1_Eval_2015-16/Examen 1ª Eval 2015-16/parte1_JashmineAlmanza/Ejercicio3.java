package parte1_JashmineAlmanza;

public class Ejercicio3 {

	public static void main(String[] args) {
		int cifra,num;
		
		do{
			System.out.println("Introduce una cifra");
			cifra=LeerTeclado.readInteger();
		
		}while (cifra<0 || cifra>10);
		
		
		for(int i=1;i<=10; i++){
			do{
				System.out.println("Introduce un n�mero  i="+i);
				num=LeerTeclado.readInteger();

			}while (num<0);

			if(producto(num)==cifra)
				System.out.println("el prod de las cifras de "+num+" es igual a la cifra "+cifra);
			else
				System.out.println("el prod de las cifras de "+num+" no es igual a la cifra "+cifra);

			//Para probar la recursividad del ejercicio 4
			if(productoRecursivo(num)==cifra)
				System.out.println("el prod de las cifras de "+num+" es igual a la cifra "+cifra);
			else
				System.out.println("el prod de las cifras de "+num+" no es igual a la cifra "+cifra);
		}

	}
	
	public static int producto(int n){
		int cifras, producto=1;
		while (n!=0){ 
			cifras=n%10; 
			producto*=cifras; 
			n/=10; 
		}
		return producto;
	}
	
	public static int productoRecursivo (int n){ //Ejercicio 4
		if (n<10)
			return n;
		else 
			return n%10*productoRecursivo(n/10);		
	}	

}
