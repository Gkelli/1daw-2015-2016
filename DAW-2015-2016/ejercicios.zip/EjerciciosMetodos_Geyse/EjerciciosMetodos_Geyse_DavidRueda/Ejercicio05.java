package EjerciciosMetodos;

public class Ejercicio05 {

	public static void main(String[] args) {
		// 5.Usando el m�todo del apartado 4, obtener todos los primos de 2 a N introducido por teclado.
	
		int num=Ejercicio01.introducirNumero();
		
		for (int i = 2; i <= num; i++) {				
		if (Ejercicio04.numeroPrimo(i))
			System.out.println("El numero "+i+ " es primo");
		}
		
	}
}
