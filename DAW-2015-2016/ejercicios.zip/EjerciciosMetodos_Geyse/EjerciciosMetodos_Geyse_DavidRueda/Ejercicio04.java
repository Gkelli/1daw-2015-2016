package EjerciciosMetodos;

public class Ejercicio04 {

	public static void main(String[] args) {
		// 4. Escribir un m�todo que reciba como par�metro un n� y devuelva si es o no primo. 
		//	Escribir un main que pida un n� por teclado mayor que 1 y determine si es o no primo invocando a dicho m�todo.
		
		int num;
		num=Ejercicio01.introducirNumero();
		
		if (numeroPrimo(num))
			System.out.println ("El "+num+" es primo");
		else 
			System.out.println ("El "+num+" no es primo");
	}
	

	public static boolean numeroPrimo (int num) { 
		boolean primo = true;
		for (int div=2; div<=num/2; div++) {
			if (num%div==0)	{
				primo=false;
				//break;
				}
		}
		return primo;
	}

}
