package EjerciciosMetodos;

import pseudocodigo.LeerTeclado;

public class Ejercicio01 {
	
	public static void main(String[] args) {
		/*1.	Escribir un m�todo que reciba como par�metro dos n�meros y devuelva su  suma. 
		 * An�logamente, crear varios m�todos para  la resta, el producto y la divisi�n. 
		 * Escribir un main que pida dos n�meros y una opci�n entre 1 y 4 y
		 *  seg�n dicha opci�n invoque al m�todo de suma, resta, producto o divisi�n.
		*/
		int n1=introducirNumero();
		int n2=introducirNumero();
		int opcion;
		do {
	
			System.out.println();
			System.out.println("Elige la operaci�n");
			System.out.println("1: Suma");
			System.out.println("2: Resta");
			System.out.println("3: Producto");
			System.out.println("4: Divisi�n");
			
			System.out.println("\nIntroduce opci�n (1-4)");
			opcion=LeerTeclado.readInteger();
			
			switch (opcion) {
			case 1:
				System.out.println("La suma es "+sumaNumeros (n1,n2));
				break;
				
			case 2:
				System.out.println("La resta es "+restaNumeros (n1,n2));
				break;
				
			case 3:
				System.out.println("El producto es "+productoNumeros (n1,n2));
				break;
				
			case 4:
				System.out.println("El cociente es "+divisionNumeros (n1,n2));
				break;
				
			default:
				System.out.println("Error en opci�n (1-4)");
				break;
			}
			
		}while (opcion!=4);
	
	}
	
	public static int introducirNumero(){
		int num;
		do{
			System.out.println("Introduce un numero positivo");
			num=LeerTeclado.readInteger();
		}
		while(num<=0);
		return num;
		
	}
	public static int sumaNumeros (int n1, int n2){
		int suma;
		suma= n1+n2;
		return suma;
	}
	public static int restaNumeros (int n1, int n2){
		int resta;
		resta= n1-n2;
		return resta;
	}		
	public static int productoNumeros (int n1, int n2){
		int producto;
		producto= n1*n2;
		return producto;
	}
	public static double divisionNumeros (int n1, int n2){
		double cociente = 0;
		if (n2 == 0)
			System.out.println("No es posible dividir entre 0");
		else {
			cociente = (double) n1 / n2;
		}
		return cociente;
	}
}
