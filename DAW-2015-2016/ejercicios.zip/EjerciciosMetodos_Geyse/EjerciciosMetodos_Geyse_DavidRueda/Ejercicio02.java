package EjerciciosMetodos;

public class Ejercicio02 {

	public static void main(String[] args) {
		// 2.Escribir un m�todo que reciba como par�metros dos n�meros y devuelva 
		// el menor de los dos. Si son iguales, devolver� uno de ellos.

		int n1=Ejercicio01.introducirNumero();
		int n2=Ejercicio01.introducirNumero();
		System.out.println("El menor es " + menorNumero(n1,n2));
		
		
		
	}
	public static int menorNumero (int n1, int n2) {
		if (n1 < n2)
			return n1;
		else
			return n2;
	}
	
	
}
