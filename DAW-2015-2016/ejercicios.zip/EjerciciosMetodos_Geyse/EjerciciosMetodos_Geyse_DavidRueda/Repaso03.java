package EjerciciosMetodos;



public class Repaso03 {

    public static void main(String[] args) {
    	 
        
        double operando1;
        double operando2;
        double resultado=0;
 

        System.out.println("Escribe el operando 1");
        operando1=LeerTeclado.readDouble();
 
       
 
        System.out.println("Escribe el operando 2");
        operando2=LeerTeclado.readDouble();
        System.out.println("Escribe el codigo de operacion");
        String operacion = LeerTeclado.readString();

        switch (operacion){
            case "+":
                resultado=operando1+operando2;
                break;
            case "-":
                resultado=operando1-operando2;
                break;
            case "*":
                resultado=operando1*operando2;
                break;
            case "/":
                resultado=operando1/operando2;
                break;
            case "^":
                resultado=(int)Math.pow(operando1, operando2);
                break;
            case "%":
                resultado=operando1%operando2;
                break;
        }
 
        System.out.println(operando1+" "+operacion+" "+operando2+" = "+resultado);
 
    }
}