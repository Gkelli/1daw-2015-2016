package EjerciciosMetodos;


public class Repaso04 {

	public static void main(String[] args) {
		/* 4. Escribe un programa que convierta un n�mero en base 10 a binario (base 2). Para ello se invocar� 
		 * a un m�todo al que le pasaremos el n�mero entero como par�metro y devolver� un String con el n�mero 
		 * convertido a binario. Para convertir un n�mero decimal a binario, debemos dividir entre 2 el n�mero 
		 * y el resultado de esa divisi�n se divide entre 2 de nuevo hasta que no se pueda dividir m�s, el resto 
		 * que obtengamos de cada divisi�n formar� el n�mero binario, de abajo a arriba. */

        int numero=Ejercicio01.introducirNumero();
        System.out.println("El numero "+numero+ " en binario es "+decimalBinario(numero));
    }
	
	
   public static String decimalBinario (int numero){
        String binario ="";
       // String digito;
        for(int i=numero;i>0;i/=2){
        	
        	binario=(i%2)+binario;
         /*   if(i%2==1){
                digito="1";
            }else{
                digito="0";
            }
            binario=digito+binario;*/
        }
        return binario;
    }
}