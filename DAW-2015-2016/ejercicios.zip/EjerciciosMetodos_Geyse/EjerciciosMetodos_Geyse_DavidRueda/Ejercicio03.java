package EjerciciosMetodos;

public class Ejercicio03 {

	public static void main(String[] args) {
		// 3.Escribir un m�todo que reciba dos par�metros y decida si uno es
		// divisor del otro.
		// Escribir un main que introduzca dichos n�meros e invoque al m�todo.

		int a = Ejercicio01.introducirNumero();
		int b = Ejercicio01.introducirNumero();

		if (numerosDivisores(a, b))
			System.out.println(a + " es divisible entre " + b);
		else {
			// si a no es divisible por b eval�o si b es divisible por a
			System.out.println(a + " no es divisible entre " + b);
			if (numerosDivisores(b, a))
				System.out.println(b + " es divisible entre " + a);
			else {
				System.out.println(b + " no es divisible entre " + a);
			}
		}

	}

	public static boolean numerosDivisores(int a, int b) {
		return (b!=0 && a%b==0);
	}
}
