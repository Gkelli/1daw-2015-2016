package EjerciciosMetodos;

public class Ejercicio06 {

	public static void main(String[] args) {
		// 6. Usando el m�todo del apartado 4, obtener los N primeros 
		// n�meros primos siendo N un n� introducido por teclado.
		
		int num=Ejercicio01.introducirNumero();
		int cont=0, i=2;
		

		while (cont<num) {			
				if (Ejercicio04.numeroPrimo(i)){					
					System.out.println("El numero "+i+ " es primo");
					cont++;
				}
			i++;
			}

	}

}
