package EjerciciosMetodos;

public class Ejercicio07 {

	public static void main(String[] args) {
		// 7.Escribir un m�todo que reciba por par�metro un n� y devuelva la
		// suma de sus divisores,
		// salvo �l mismo. Utilizando este m�todo, escribir un main para obtener
		// todos los n�meros
		// perfectos menores que un N introducido por teclado.

		int num, i;
		num = Ejercicio01.introducirNumero();

		System.out.println("\nLa suma de los divisores de "+ num+" es " + sumaDivisores(num));
		System.out.println("\nLos numeros perfectos hasta " + num + " son: ");
		for (i = 1; i < num; i++)
			if (sumaDivisores(i) == i)
				System.out.println(i);
	}

	public static int sumaDivisores(int num) {
		int i, suma = 0;
		for (i = 1; i < num ; i++)
			if (num % i == 0)
				suma += i;
		return suma;
	}

}
