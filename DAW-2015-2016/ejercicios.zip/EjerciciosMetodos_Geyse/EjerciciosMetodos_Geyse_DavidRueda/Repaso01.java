package EjerciciosMetodos;

import pseudocodigo.LeerTeclado;

public class Repaso01 {

	public static void main(String[] args) {
		// 1.-Escribe un programa que calcule el �rea de una figura que se pide por teclado que puede ser un c�rculo, 
		//cuadrado o tri�ngulo; seg�n el tipo de figura se pedir�n unos datos u otros. Se crear� un m�todo para calcular 
		//el �rea seg�n la figura y en cada caso se pasar�n como par�metros los datos que necesitemos. Todos los m�todos devolver�n un double. 
		// En el main se invocar� al m�todo correspondiente seg�n el tipo de figura y se  mostrar� el resultado por pantalla:
		// �rea de cada figura:
		//	�	Circulo: (radio^2)*PI 
		//	�	Triangulo: (base * altura) / 2 
		//	�	Cuadrado: lado * lado 

		
		int opcion;
		//do {
			
			System.out.println();
			System.out.println("Elige la operaci�n");
			System.out.println("1: C�rculo");
			System.out.println("2: Tri�ngulo");
			System.out.println("3: cuadrado");
			
			System.out.println("\nIntroduce opci�n (1-3)");
			opcion=LeerTeclado.readInteger();
			
			switch (opcion) {
			case 1:
				System.out.println("El �rea del c�rculo es " + areacirculo());
				break;
				
			case 2:
				System.out.println("El �rea del tri�ngulo es "  + areatriangulo());
				break;
				
			case 3:
				System.out.println("El �rea del cuadrado es "  + areacirculo());
				break;
				
				
			default:
				System.out.println("Error en opci�n (1-3)");
				break;
			}
		//}while (opcion!=3);
	}
	public static int introducirNumero(){
		int num;
		do{
			System.out.println("Introduce un numero positivo");
			num=LeerTeclado.readInteger();
		}
		while(num<=0);
		return num;
		
	}
	public static double areacirculo ( ) {
		double area, radio;
		System.out.println("Introduce radio");
		 radio=EjerciciosMetodos.LeerTeclado.readDouble();
		 area=Math.pow(radio, 2)*Math.PI;

		 return area;

	}
	
	public static double areatriangulo () {
		double base, altura, area;
		System.out.println("Introduce base y altura");
		base=EjerciciosMetodos.LeerTeclado.readDouble();
		altura=EjerciciosMetodos.LeerTeclado.readDouble();
		area= (base * altura) / 2 ;
		
		return area;
	}
	
	public static double areacuadrado (){
		double lado, area;
		System.out.println("Introduce lado ");
		lado=EjerciciosMetodos.LeerTeclado.readDouble();
		area=lado * lado ;
		
		return area;
	}

}
