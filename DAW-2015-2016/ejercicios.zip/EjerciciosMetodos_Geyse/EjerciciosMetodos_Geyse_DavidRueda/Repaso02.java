package EjerciciosMetodos;

public class Repaso02 {


	public static void main(String[] args) {
		/* 2.- Escribe un programa que pida por teclado una cantidad de euros  y una moneda que  
		 *  puede ser  d�lar, yen o libras y convierta la cantidad de euros  a la otra moneda. 
		 *  Para ello se invocar� a un m�todo que tendr� como par�metros la cantidad de euros y la moneda a pasar;  
		 *  este m�todo no devolver� ning�n valor y mostrar� un mensaje indicando el cambio.
			El cambio de divisas es:
			�	1 EUR = 0,79550 Libras esterlinas
			�	1 EUR = 1,24650 d�lar americano
			�	1 EUR = 144,959 JPY                      */
		 				
		System.out.println("Escribe una cantidad en euros");
		double cantidad = LeerTeclado.readDouble();
		convierte(cantidad);		


		
	}
	public static void convierte (double cantidad) { 
	 double res=0;
	 boolean correcto = true;
	 System.out.println("Escribe la moneda a la que quieres convertir");
	 String moneda = LeerTeclado.readString();
	 
	switch (moneda.toLowerCase()){	
     case "libras":
         res=cantidad*0.79550;
         break;
     case "dolares":
         res=cantidad*1.24650;
         break;
     case "yenes":
         res=cantidad*144.959;
         break;
     default:
         System.out.println("No has introducido una moneda correcta");
         correcto=false;
	 	}
	
     if (correcto){
         System.out.println(cantidad+ " euros en " +moneda+ " son " +res);
     	}
	}
}