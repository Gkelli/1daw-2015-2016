package EjerciciosMetodos;

public class Ejercicio08 {

	public static void main(String[] args) {
		// 8.Escribir un m�todo que recibe como par�metro un n� y devuelva su factorial. 
		//Escribir un main que pida por teclado un N>=0 e invoque a dicho m�todo.
		
		int num=Ejercicio01.introducirNumero();
		System.out.println("El factorial de un n�mero es " +numFactorial(num));

		
	}

	public static double numFactorial (int num) {
		double factorial=1;
	while (num!=0) {
		factorial=factorial*num;
		num=num-1;
		}
	return num;
	}
}
