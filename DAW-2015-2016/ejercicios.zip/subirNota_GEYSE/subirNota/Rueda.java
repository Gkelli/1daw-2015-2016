package subirNota;

public class Rueda {
	
	/*�	Rueda: 
 	Atributos: Nombre (String) y pinchada (boolean)
 	M�todos: los habituales.
*/
	private String nombre;
	private boolean pinchada=false;
	
	public Rueda(){}
	
	public Rueda(String nombre){
		this.nombre=nombre;
		pinchada=false;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public boolean isPinchada() {
		return pinchada;
	}

	public void setPinchada(boolean pinchada) {
		this.pinchada = pinchada;
	}

	@Override
	public String toString() {
		return "Rueda [Nombre()=" + getNombre() + ", �est� pinchada?=" + isPinchada() + "]";
	}
	
	

}
