package subirNota;

import java.util.Arrays;

public class Array {

	private int tamanno;
	private int array[];
	private int cont;

	public Array(int tamanno) {
		this.tamanno = tamanno;
		array = new int[this.tamanno];
	}

	public void ver_array() {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}

	public void insertar(int num) {
		if (cont < tamanno) {
			array[cont] = num;
			cont++;
		} else
			System.out.println("No se puede insertar");

	}

	public void borrar(int num) {
		boolean enco = false;

		for (int i = 0; i < array.length && !enco; i++) {
			if (array[i] == num) {
				enco = true;
				array[i] = 0;
			}

		}
		cont--;

		if (!enco) {
			System.out.println("No se ha encontrado el n�mero a borrar");
		}

	}

	public int[] insertar_ordenado(int num) {

		for (int i = 1; i < array.length; i++) {
			num = array[i];
			for (int j = i - 1; j >= 0 && array[j] > num; j--) {
				array[j + 1] = array[j];
				array[j] = num;
			}
		}
		return array;
	}

	public int getTamanno() {
		return tamanno;
	}

	public void setTamanno(int tamanno) {
		this.tamanno = tamanno;
	}

	public String toString() {
		return "Array [tama�o=" + tamanno + ", array=" + Arrays.toString(array) + "]";
	}

}
