package subirNota;

import java.util.Arrays;

public class Garaje {
	/*
	 * � Garaje: Atributos: direcci�n (String), capacidad (int) y un array de
	 * coches. M�todos: adem�s de los habituales tendr�:
	 * 
	 */

	private String direccion;
	private int capacidad;
	private Vehiculo lista_vehiculos[];

	public Garaje(String direccion, int capacidad) {
		this.direccion = direccion;
		this.capacidad = capacidad;
		lista_vehiculos = new Vehiculo[capacidad];
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	public Vehiculo[] getLista_vehiculos() {
		return lista_vehiculos;
	}

	public void setLista_vehiculos(Vehiculo[] lista_vehiculos) {
		this.lista_vehiculos = lista_vehiculos;
	}

	@Override
	public String toString() {
		return "Garaje [direcci�n=" + getDireccion() + ", capacidad=" + getCapacidad() + ", vehiculos del garaje"
				+ Arrays.toString(getLista_vehiculos()) + "]";
	}

	public int plazas_libres() {
		int libre = 0;
		for (int i = 0; i < lista_vehiculos.length; i++) {
			if (lista_vehiculos[i] == null) {
				libre++;
			}
		}
		return libre;
	}

	public boolean garaje_lleno() {
		boolean vacio = true;
		for (int i = 0; i < lista_vehiculos.length; i++) {
			vacio = true;
			if (lista_vehiculos[i] != null) {
				vacio = false;
			}
		}
		if (!vacio)
			System.out.println("ERROR. El garaje est� lleno, no se puede aparcar m�s vehiculos");
		return true;

	}

	public Vehiculo crear_vehiculo() {

		Vehiculo vehiculo_aux = null;

		do {

			System.out.println("Introduzca la matricula, marca, modelo y el numero de ruedas del vehiculo a aparcar");
			String matricula = LeerTeclado.readString();
			String marca = LeerTeclado.readString();
			String modelo = LeerTeclado.readString();
			int ruedas = LeerTeclado.readInteger();
			vehiculo_aux = new Vehiculo(matricula, marca, modelo, ruedas);

			boolean encontrado = false;

			for (int i = 0; i < lista_vehiculos.length && !encontrado; i++) {
				if (lista_vehiculos[i] != null && lista_vehiculos[i].getMatricula().equalsIgnoreCase(matricula)) {
					vehiculo_aux = lista_vehiculos[i];
					encontrado = true;
					System.out.println("ERROR. El vehiculo ya est� aparcado");
				}
			}

		} while (!garaje_lleno());

		return vehiculo_aux;

	}

	public void aparcar(Vehiculo vehiculo) {
		int posicion = 0;

		for (int i = 0; i < lista_vehiculos.length; i++) {
			if (lista_vehiculos[i] == null) {
				lista_vehiculos[i] = vehiculo;
				posicion = i;
				break;
			}
		}

		System.out.println("En el garaje hay " + plazas_libres()
				+ " plazas libres y se ha aparcado el vehiculo en la plaza " + posicion);

	}

	public void salir(Vehiculo vehiculo) {
		for (int i = 0; i < lista_vehiculos.length; i++) {
			if (lista_vehiculos[i] == vehiculo) {
				lista_vehiculos[i] = null;
			}
		}
		System.out.println("El vehiculo " + vehiculo.getModelo() + " ha salido del garaje y ahora hay "
				+ plazas_libres() + " plazas libres");

	}

	public Vehiculo buscar(String matricula) {
		Vehiculo vehiculo_aux = null;
		boolean encontrado = false;

		for (int i = 0; i < lista_vehiculos.length && !encontrado; i++) {
			if (lista_vehiculos[i] != null && lista_vehiculos[i].getMatricula().equalsIgnoreCase(matricula)) {
				vehiculo_aux = lista_vehiculos[i];
				encontrado = true;
				System.out.println(vehiculo_aux.toString() + " est� en la plaza " + i);
			}
		}
		if (!encontrado) {
			System.out.println("NO se ha encontrado el vehiculo");
		}

		return vehiculo_aux;
	}

}
