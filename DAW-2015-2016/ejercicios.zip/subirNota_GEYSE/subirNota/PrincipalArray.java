package subirNota;

public class PrincipalArray {

	public static void main(String[] args) {
		
		System.out.println("Introduce el tama�o del array");
		Array array = new Array(LeerTeclado.readInteger());
		boolean repetir=true;
		int opcion;
		do{
			System.out.println("Elige opci�n");
			System.out.println("1. Insertar n�mero en el array");
			System.out.println("2. Borrar n�mero del array");
			System.out.println("3. Insertar un n�mero en el array ordenado");
			System.out.println("4. Ver array");
			opcion=LeerTeclado.readInteger();
			switch(opcion){
			
			case 1:
				System.out.println("Introduce un n�mero a introducir en el array");
				array.insertar(LeerTeclado.readInteger());
				break;
			case 2:
				System.out.println("Introduce un n�mero a borrar");
				array.borrar(LeerTeclado.readInteger());
			case 3:
				System.out.println("Introduce un n�mero a introducir en el array");
				array.insertar_ordenado(LeerTeclado.readInteger());
				break;
			case 4:
				array.ver_array();
				break;
			default:
				System.out.println("No existe la opci�n");
			}
			
			repetir=false;
			System.out.println();
			System.out.println("�Desea repetir? Introduzca 'si/s'");
			String respuesta = LeerTeclado.readString();
			if(respuesta.equalsIgnoreCase("si") || respuesta.equalsIgnoreCase("s"))
				repetir=true;
				else 
					System.out.println("Fin del programa");
				
		} while(repetir);

	}

}
