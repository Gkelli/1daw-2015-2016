package subirNota;

public class Vehiculo {
	
	/*�	Veh�culo:
 	Atributos: matr�cula, marca y modelo (String), numRuedas (int) y un array de ruedas de tama�o numRuedas.
  	M�todos: adem�s de los habituales tendr�:
 	
*/
	
	private String matricula;
	private String marca;
	private String modelo;
	private int n_ruedas;
	private Rueda lista_ruedas[];
	
	public Vehiculo(){}
	
	public Vehiculo(String matricula, String marca, String modelo, int n_ruedas){
		this.matricula=matricula;
		this.marca=marca;
		this.modelo=modelo;
		this.n_ruedas=n_ruedas;
		lista_ruedas= new Rueda[n_ruedas];
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getN_ruedas() {
		return n_ruedas;
	}

	public void setN_ruedas(int n_ruedas) {
		this.n_ruedas = n_ruedas;
	}
	
	
	// cambiarRuedas: revisar� el estado de todas las ruedas cambiando las que est�n pinchadas. Los datos de las nuevas ruedas se pedir�n por teclado.
	
	@Override
	public String toString() {
		return "Vehiculo [matricula=" + getMatricula() + ", marca=" + getMarca() + ", modelo="
				+ getModelo() + ", n�mero de ruedas=" + getN_ruedas() + "]";
	}

	public void cambiar_ruedas(){
		Rueda rueda_aux;
		for (int i = 0; i < lista_ruedas.length; i++) {
			if (lista_ruedas[i].isPinchada()==true) {
				System.out.println("La rueda " + i + " est� pinchada");
				System.out.println("Introduzca nombre de la nueva rueda");
				rueda_aux = new Rueda(LeerTeclado.readString());
				lista_ruedas[i]=rueda_aux;
			}
		}
	}
	

}
