package subirNota;

public class PrincipalAparcamiento {

	public static void main(String[] args) {
		//Se pide crear un main que genere un garaje y un men� para gestionar el aparcamiento,
		//la salida de veh�culos y el cambio de ruedas de un veh�culo aparcado en el mismo que 
		
		System.out.println("Introduzca la direcci�n y la capacidad del gareja a crear");		
		Garaje garaje = new Garaje(LeerTeclado.readString(), LeerTeclado.readInteger());
		
		boolean repetir=true;
		int opcion;

		do{
			System.out.println("--------------Elige opci�n-----------------");
			System.out.println("1. Aparcar vehiculo");
			System.out.println("2. Salir vehiculo");
			System.out.println("3. Buscar vehiculo ");
			System.out.println("4. Ver plazas del garaje");
			opcion=LeerTeclado.readInteger();
			switch(opcion){
			
			case 1:
				garaje.aparcar(garaje.crear_vehiculo());
				break;
			case 2:
				System.out.println("Introduzca la matricula a sacar el vehiculo");
				String matricula = LeerTeclado.readString();
				garaje.salir(garaje.buscar(matricula));
				break;
			case 3:
				System.out.println("Introduzca la matricula del vehiculo a buscar");
				matricula=LeerTeclado.readString();
				garaje.buscar(matricula);
				break;
			case 4:
				System.out.println(garaje.toString());;
				break;
			default:
				System.out.println("No existe la opci�n");
			}
			
			repetir=false;
			System.out.println();
			System.out.println("�Desea repetir? Introduzca 's/si'");
			String respuesta = LeerTeclado.readString();
			if(respuesta.equalsIgnoreCase("si") || respuesta.equalsIgnoreCase("s"))
				repetir=true;
				else 
					System.out.println("Fin del programa");
				
		} while(repetir);

	}

}
