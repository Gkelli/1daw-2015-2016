
public class Ejercicio5 {

	public static void main(String[] args) {
		
		int notas[][]=new int [30][5];
		
		//cargando las notas
		System.out.println("Tabla con notas de 30 alumnos y 5 asignaturas");
		for (int i = 0; i < notas.length; i++) {
			for (int j = 0; j < notas[i].length; j++) {
				notas[i][j]=(int)(Math.random() * 11);
				System.out.print(notas[i][j] + " ");
			}
			System.out.println();
		}
		
		int max=Integer.MIN_VALUE ;
		float nota_media = 0, media_alumno = 0, media_asignatura=0, suma=0;
		//calcula la nota media y la maxima
		for (int i = 0; i < notas.length; i++) {
			for (int j = 0; j < notas[i].length; j++) {
				if(notas[i][j]>max){
					max=notas[i][j];					
				}
				suma+=notas[i][j];				
			}
		}
		nota_media=(float)((suma)/150);
		System.out.println("\nLa nota m�xima es " + max);
		System.out.println("\nLa media es " + nota_media + " \n");
		
		//calcula media alumno
		suma=0;
		for (int i = 0; i < notas.length; i++) {
			suma=0;
			for (int j = 0; j < notas[i].length; j++) {
				suma+=notas[i][j];
			}
			media_alumno=(float)(suma/notas[i].length);
			System.out.println("La media del alumno " + (i+1) + " es " + media_alumno);
		}
		System.out.println();
		//calcula media asignatura
		suma=0;
		for (int i = 0; i < notas[i].length; i++) {
			suma=0;
			for (int j = 0; j < notas.length; j++) {
				suma+=notas[j][i];
			}
			media_asignatura=(float)(suma/notas.length);
			System.out.println("La media de la asignatura es " + (i+1) + " es " + media_asignatura);
		}
		System.out.println();
	}

}
