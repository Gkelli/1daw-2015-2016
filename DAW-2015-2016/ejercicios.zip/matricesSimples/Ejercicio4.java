
public class Ejercicio4 {

	public static void main(String[] args) {
		
		int matriz[][]= new int [5][3];
		
		
		System.out.println("Matriz de 5 x 3 ");
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j]=(int)(Math.random() * 10)+1;
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}
		
		System.out.println("Matriz traspuesta");
		for (int i = 0; i < matriz[i].length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print(matriz[j][i]+ " ");
			}
			System.out.println();
		}

	}

}
