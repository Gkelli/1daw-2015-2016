
public class Ejercicio3 {

	public static void main(String[] args) {

		int matriz[][]= new int [10][10];
		
		//cargar matriz
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j]= (int)(Math.random() *9 ) +1;
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}
		
		//sumar filas
		int suma=0;
		
		for (int i = 0; i < matriz.length; i++) {
			suma=0;
			for (int j = 0; j < matriz[0].length; j++) {
				suma+=matriz[i][j];
			}
			System.out.println("La suma de la fila " + (i+1) + " es " + suma); 
		}
		System.out.println();
		
		//sumar columnas
		for (int i = 0; i < matriz[0].length; i++) {
			suma=0;
			for (int j = 0; j < matriz.length; j++) {
				suma+=matriz[j][i];
			}
			System.out.println("La suma de la columna " + (i+1) + " es " + suma); 
		}

	}

}
