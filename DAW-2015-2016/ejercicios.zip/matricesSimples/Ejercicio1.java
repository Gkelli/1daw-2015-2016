
public class Ejercicio1 {

	public static void main(String[] args) {
		
		// cargar matriz
		int matriz[][] = new int [5][5];
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j]=i+j;
			}
		}
		
		System.out.println("Matriz con la suma de fila y columna");
		// imprimir matriz
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print(matriz[i][j]+ " ");
			}
			System.out.println();
		}

	}

}
