
public class StringBuffer01 {

	public static void main(String[] args) {
		/*7.	Realizar el ejercicio 4 con una cadena StringBuffer
		 *  (si us�is el m�todo indexOf hay que tener en cuenta que en caso de StringBuffer 
		 *  el m�todo necesita un argumento de tipo String, no de tipo char).*/
		
		
		System.out.println("Introduzca una cadena");
		StringBuffer sb = new StringBuffer(LeerTeclado.readString());
		
		System.out.println("Introduzca un car�cter que deseas buscar");
		String cad = LeerTeclado.readString();
		
		System.out.println("---Primera ocurrencia--");
		primera_ocurrencia(sb, cad);
		System.out.println("---Todas ocurrencias---");
		todas_ocurrencias(sb, cad);
		System.out.println("---Ultima ocurrencia---");
		primera_ocurrencia_final(sb, cad);

	}
	
	//buscar la primera ocurrencia de un String determinado en la cadena SStringBuffer
	public static void primera_ocurrencia(StringBuffer cad, String ch){
		
		if (cad.indexOf(ch) == -1) {
			System.out.println("No se ha encontrado el caracter : '" + ch + "' en la cadena : '" + cad + "'");
		} else {
			System.out.println("Se ha encontrado el caracter : '" + ch + "' en la posici�n : " + cad.indexOf(ch));
		}		
	}
	
	//buscar todas las ocurrencias de un String determinado en la cadena SStringBuffer
	
	public static void todas_ocurrencias(StringBuffer cad, String ch) {

		if (cad.indexOf(ch) == -1) {
			System.out.println("No se ha encontrado el caracter : '" + ch + "' en la cadena : '" + cad + "'");
		} else {
			System.out.println("Se ha encontrado el caracter : '" + ch + "' en las posiciones :");
			for (int i = 0; i < cad.length(); i++) {
				if (cad.charAt(i) == ch.charAt(0)) {
					System.out.println(i);
				}
			}
		}

	}
	
	//buscar las primera ocurrencia de un String determinado en la cadena SStringBuffer desde el final
	
	public static void primera_ocurrencia_final(StringBuffer cad, String ch){
		
		boolean encontrado=false;
		
		if (cad.indexOf(ch) == -1) {
			System.out.println("No se ha encontrado el caracter : '" + ch + "' en la cadena : '" + cad + "'");
		} else {
			for (int i = cad.length()-1; i >= 0 && !encontrado ; i--) {
				if (cad.charAt(i) == ch.charAt(0)) {
					System.out.println("Se ha encontrado el caracter : '" + ch + "' en la posici�n : " + i);
					encontrado=true;
					break;
				}
			}
		}
	}
}
