
public class StringBuffer03 {

	public static void main(String[] args) {
		// 9.	Idem el ejercicio 6 con una cadena StringBuffer.
		
		System.out.println("Introduzca una cadena");
		StringBuffer cadena = new StringBuffer(LeerTeclado.readString());

		// compruebo si hay espacios o no

		// suponiendo que hay espacios en la cadena

		if (es_palindroma_blancos(cadena)) {
			System.out.println("La cadena : '" + cadena + "' es palindroma");
		} else {
			System.out.println("La cadena : '" + cadena + "' no es palindroma");
		}

	}

	// metodo que borra los espacios de la cadena

	public static String eliminar_blancos(StringBuffer cad) {
		String cad_aux = new String();
		char c;
		for (int i = 0; i < cad.length(); i++) {
			if (cad.charAt(i) != ' ') {
				c = cad.charAt(i);
				// concatena pasando a String
				cad_aux = cad_aux.concat(String.valueOf(c));
			}

		}
		return cad_aux;
	}

	// metodo que decide si es palindroma o no, para las cadenas que no tienen espacios

	public static boolean es_palindroma(StringBuffer cad) {
		boolean palindroma = true;
		int i = 0, j = cad.length() - 1;
		while (i <= (cad.length() / 2) && palindroma) {
			// primero paso a minusculas para evitar equivocaciones
			if (Character.toLowerCase(cad.charAt(i)) != Character.toLowerCase(cad.charAt(j)))
				palindroma = false;
			else {
				i++;
				j--;
			}
		}
		return palindroma;
	}

	// metodo que decide si es palindroma o no, y que primero elimina los
	// espacios de la cadena

	public static boolean es_palindroma_blancos(StringBuffer cad) {

		String cad_aux = eliminar_blancos(cad);

		System.out.println("Una vez de eliminado los espacios, la cadena se queda: " + cad_aux);

		boolean palindroma = true;

		int i = 0, j = cad_aux.length() - 1;
		while (i <= cad_aux.length() / 2 && palindroma) {
			// primero paso a minusculas para evitar equivocaciones
			if (Character.toLowerCase(cad_aux.charAt(i)) != Character.toLowerCase(cad_aux.charAt(j)))
				palindroma = false;
			else {
				i++;
				j--;
			}
		}

		return palindroma;
	}

}
