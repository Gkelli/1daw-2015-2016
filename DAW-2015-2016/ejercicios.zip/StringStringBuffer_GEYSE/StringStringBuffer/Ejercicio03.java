
public class Ejercicio03 {

	public static void main(String[] args) {
		
		/* 3.	Dadas dos cadenas introducidas por teclado escribir un m�todo que, si las cadenas son de la misma longitud, eval�e si son iguales y, 
		si son de distinta longitud, eval�e si la menor est� contenida dentro de la cadena mayor.*/
		
		// se introduce por teclado las cadenas y las lee
			System.out.println("Introduzca una cadena de caracteres");
			String cadena1 = LeerTeclado.readString();
			System.out.println("Introduzca otra cadena de caracteres");
			String cadena2 = LeerTeclado.readString();
			
			// probando el metodo de evaluar cadenas
			evaluar_cadenas(cadena1, cadena2);
			
	}
	
	// metodo que evaluan si dos cadenas son iguales , de la misma longitud o si una est� contenida en otra
	
	public static void evaluar_cadenas(String cad1, String cad2) {

		if (cad1.length() == cad2.length()) {
			if (cad1.equalsIgnoreCase(cad2)) {
				System.out.println("La cadena : '" + cad1 + "' es de la misma logintud que la cadena: '" + cad2 + "'");
			}
		} else {
			if (cad1.length() < cad2.length()) {
				if (cad2.indexOf(cad1) == 0) {
					System.out.println("La cadena ': " + cad1 + "' est� contenida en la cadena: '" + cad2 + "'");
				} else {
					System.out.println("La cadena : '" + cad1 + "' no est� contenida en la cadena: '" + cad2 + "'");
				}
			} else {
				if (cad1.length() > cad2.length()) {
					if (cad1.indexOf(cad2) == 0) {
						System.out.println("La cadena : '" + cad2 + "' est� contenida en la cadena: '" + cad1 + "'");
					} else {
						System.out.println("La cadena : '" + cad2 + "' no est� contenida en la cadena: '" + cad1 + "'");
					}
				}
			}
		}

	}
	

}
