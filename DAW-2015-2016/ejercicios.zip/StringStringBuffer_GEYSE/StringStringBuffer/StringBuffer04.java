
public class StringBuffer04 {

	public static void main(String[] args) {
		/*10.	Dada una cadena StringBuffer que contiene n�meros, escribir un m�todo para a�adir puntos  cada 3 d�gitos empezando por la derecha.
Ejemplo: 1234567      =>  1.234.567
*/
		
        System.out.println("Introduce una cadena de n�meros");
        long n= LeerTeclado.readLong();
         //una vez introducido los numeros los convierto a String
        StringBuffer cadena=new StringBuffer(String.valueOf(n));
        cadena.insert(cadena.length(), n); 
        System.out.println(annadir_puntos(cadena));
         
    }
     
    public static StringBuffer annadir_puntos(StringBuffer bf){
    	
		for (int i = bf.length() - 3; i > 0; i -= 3) {

			bf.insert(i, '.');
		}

		return bf;
    }
 
	

}
