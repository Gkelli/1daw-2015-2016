
public class Ejercicio05 {

	public static void main(String[] args) {
		//	Dada una cadena por teclado, escribir un m�todo que obtenga otra cadena eliminando las vocales.
		
		System.out.println("Introduzca una cadena");
		String cadena = LeerTeclado.readString();
		
		System.out.println("Eliminando las vocales de la cadena:");
		eliminar_vocales(cadena);		

	}
	
	public static void eliminar_vocales(String cad){
		String cadena_aux="";
		for (int i = 0; i < cad.length(); i++) {
			if (cad.toLowerCase().charAt(i)!='a' && cad.toLowerCase().charAt(i)!='�' && cad.toLowerCase().charAt(i)!='e' && cad.toLowerCase().charAt(i)!='�' 
					&& cad.toLowerCase().charAt(i)!='i'	&& cad.toLowerCase().charAt(i)!='�' && cad.toLowerCase().charAt(i)!='o' && cad.toLowerCase().charAt(i)!='�' 
					&& cad.toLowerCase().charAt(i)!='u') { // se pasa a minuscula antes que cogerla, para no evitar las mayusculas
				cadena_aux+=cad.charAt(i);
			}
		}
		
		System.out.println("La cadena resultante de la eliminaci�n de vocales es: "+cadena_aux);
		
	}
}
