
public class Ejercicio04 {

	public static void main(String[] args) {
		/*4.	Dadas por teclado una cadena y una variable car�cter, se pide:*/
		
		System.out.println("Introduzca una cadena");
		String cadena = LeerTeclado.readString();
		System.out.println("Introduzca un car�cter");
		char c= LeerTeclado.readCharacter();
		
		System.out.println("---Primera ocurencia:---");
		primera_ocurrencia(cadena, c);
		System.out.println("---Todas ocurencias:---");
		todas_ocurrencias(cadena, c);
		System.out.println("---Ocurrecia del final:---");
		primera_ocurrencia_final(cadena, c);

	}
	
	/*a.	Escribir un m�todo que busque dentro de la cadena la primera ocurrencia del car�cter introducido 
	 * empezando por el principio, indicando la posici�n que ocupa dentro de la cadena en caso de encontrarse en ella, 
	 * o indicando mediante un mensaje que dicho car�cter no se encuentra dentro de la cadena:
 	Ejemplo: �hola ana belen�    car�cter: a  => se encuentra en la posici�n 3   
*/
	
	public static void primera_ocurrencia(String cad, char ch){
		
		if (cad.indexOf(ch)==-1) {
			System.out.println("No se ha encontrado el caracter : '" + ch + "' en la cadena : '" + cad + "'");
		} else {
			System.out.println("Se ha encontrado el caracter : '" + ch + "' en la posici�n :" + cad.indexOf(ch) );
		}
		
	}
	
	
	
/*b.	Escribir un m�todo que busque todas las ocurrencias del car�cter en la cadena en caso de encontrarse en ella, 
 * o indicando mediante un mensaje que dicho car�cter no se encuentra dentro de la cadena.
 	Ejemplo: �hola ana belen�    car�cter: a  => se encuentra en la posici�n 3, 5, 7
*/
	
	
	public static void todas_ocurrencias(String cad, char ch) {

		if (cad.indexOf(ch) == -1) {
			System.out.println("No se ha encontrado el caracter : '" + ch + "' en la cadena : '" + cad + "'");
		} else {
			System.out.println("Se ha encontrado el caracter : '" + ch + "' en las posiciones :");
			for (int i = 0; i < cad.length(); i++) {
				if (cad.charAt(i) == ch) {
					System.out.println(i);
				}
			}
		}

	}	
	
	/*c.	Escribir un m�todo que busque dentro de la cadena la primera ocurrencia del car�cter introducido empezando por el final, 
	 * indicando la posici�n que ocupa dentro de la cadena en caso de encontrarse en ella, 
	 * o indicando mediante un mensaje que dicho car�cter no se encuentra dentro de la cadena:
 	Ejemplo: �hola ana belen�    car�cter: a  => se encuentra en la posici�n  7*/
	
	public static void primera_ocurrencia_final(String cad, char ch){
		
		if (cad.indexOf(ch) == -1) {
			System.out.println("No se ha encontrado el caracter : '" + ch + "' en la cadena : '" + cad + "'");
		} else {
			for (int i = cad.length()-1; i >= 0 ; i--) {
				if (cad.charAt(i) == ch) {
					System.out.println("Se ha encontrado el caracter : '" + ch + "' en la posici�n : " + i);
					break;
				}
			}
		}
		
	}
	
	
	
	
	
	
	
}
