
public class StringBuffer02 {

	public static void main(String[] args) {
//		8.	Realizar el ejercicio 5 con una cadena StringBuffer.
		
			System.out.println("Introduzca una cadena");
			StringBuffer cadena = new StringBuffer( LeerTeclado.readString().toLowerCase() ); // la paso a minuscula para evitar errores
			
			System.out.println("Eliminando las vocales de la cadena:");
			eliminar_vocales(cadena);		

		}
		
		public static void eliminar_vocales(StringBuffer cadena){
			String cadena_aux="";
			for (int i = 0; i < cadena.length(); i++) {
				if (cadena.charAt(i)!='a' && cadena.charAt(i)!='�' && cadena.charAt(i)!='e' && cadena.charAt(i)!='�' 
						&& cadena.charAt(i)!='i'	&& cadena.charAt(i)!='�' && cadena.charAt(i)!='o' && cadena.charAt(i)!='�' 
						&& cadena.charAt(i)!='u') { 
					cadena_aux+=cadena.charAt(i);
				}
			}
			
			System.out.println("La cadena resultante de la eliminaci�n de vocales es: "+cadena_aux);
			
		}

}
