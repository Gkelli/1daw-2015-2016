
public class Ejercicio01 {

	public static void main(String[] args) {
		/*1.	Dada una cadena introducida por teclado, obtener su longitud, el car�cter que ocupa  
		 * el centro de la  cadena y visualizar la mitad derecha
		 *  y la mitad izquierda de la misma.*/
		
		System.out.println("Introduzca una cadena de texto");
		String cadena = LeerTeclado.readString();
		
		System.out.println("La longitud de la cadena es : " + cadena.length());
		System.out.println("El caracter que ocupa el centro de la cadena es: " + cadena.charAt(cadena.length()/2));
		char[] c = new char [cadena.length()];
		// se coge desde la posicion 0 de la cadena hasta la mitad de ella, la guarda en el array de caracteres c desde la posicion 0
		cadena.getChars(0, cadena.length()/2, c, 0);
		// recorre el array de caracteres para imprimir su mitad derecha 
		System.out.println("La mitad derecha de la cadena es: ");
		for (int i = 0; i < c.length; i++) {
			System.out.print(c[i]);
		}
		// se coge desde la mitad de la cade  hasta el final de ella, la guarda en el array de caracteres c desde la posicion 0
		cadena.getChars(cadena.length()/2,cadena.length(), c, 0);
		// recorre el array de caracteres para imprimir su mitad izquierda 
		System.out.println("\nLa mitad izquierda de la cadena es: ");
		for (int i = 0; i < c.length; i++) {
			System.out.print(c[i]);
		}
	}

}
