
public class StringBuffer05 {

	public static void main(String[] args) {
		/*11.	Modificar el ejercicio anterior para pedir por teclado el n� de d�gitos a partir del cual se realiza la separaci�n y el car�cter separador
Ejemplo 1234567   n�:2  car�cter: ,  =>  1,23,45,67
*/
		System.out.println("Introduce una cadena de n�meros");
		long n = LeerTeclado.readInteger();
		//una vez introducido los numeros, convierto en String
		StringBuffer cadena = new StringBuffer(String.valueOf(n));
		cadena.insert(cadena.length(), n);

		System.out.println("Introduce el n�mero de digitos para la separaci�n");
		int num = LeerTeclado.readInteger();
		System.out.println("Introduzca el car�cter para separar la cadena");
		char caracter = LeerTeclado.readCharacter();

		cadena = annadir_caracter(cadena, num, caracter);
		System.out.println(cadena);

	}

	public static StringBuffer annadir_caracter(StringBuffer bf, int n, char ch) {
		
		for (int i = bf.length() - n; i > 0; i -= n) {
			bf.insert(i, ch);
		}

		return bf;

	}

}
