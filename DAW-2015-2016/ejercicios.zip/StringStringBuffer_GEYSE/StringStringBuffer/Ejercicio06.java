public class Ejercicio06 {

	public static void main(String[] args) {
		/*
		 * 6. Dada una cadena por teclado, decidir si es pal�ndroma, es decir si
		 * se lee igual de izquierda a derecha que de derecha a izquierda. a.
		 * Suponiendo que no tiene blancos: Ejemplo: �dabalearrozalazorraelabad�
		 * b. Suponiendo que tiene blancos: Ejemplo: �dabale arroz a la zorra el
		 * abad� ( eliminarlos primero antes de hacer la evaluaci�n).
		 */

		System.out.println("Introduzca una cadena");
		String cadena = LeerTeclado.readString();

		// compruebo si hay espacios o no

		if (cadena.indexOf(' ') == -1) {// suponiendo que no hay espacios en la
										// cadena
			if (es_palindroma(cadena)) {
				System.out.println("La cadena : '" + cadena + "' es palindroma");
			} else {
				System.out.println("La cadena : '" + cadena	+ "' no es palindroma");
			}
		} else {// suponiendo que hay espacios en la cadena

			if (es_palindroma_blancos(cadena)) {
				System.out.println("La cadena : '" + cadena + "' es palindroma");
			} else {
				System.out.println("La cadena : '" + cadena	+ "' no es palindroma");
			}
		}

	}

	// metodo que borra los espacios de la cadena

	public static String eliminar_blancos(String cad) {
		String cad2 = new String();
		char c;
		for (int i = 0; i < cad.length(); i++) {
			if (cad.charAt(i) != ' ') {
				c = cad.charAt(i);
				// concatena pasando a String
				cad2 = cad2.concat(String.valueOf(c));
			}

		}
		return cad2;
	}

	// metodo que decide si es palindroma o no, para las cadenas que no tienen espacios

	public static boolean es_palindroma(String cad) {
		boolean esPalindromo = true;
		int i = 0, j = cad.length() - 1;
		while (i <= (cad.length() / 2) && esPalindromo) {
			// primero paso a minusculas para evitar equivocaciones
			if (Character.toLowerCase(cad.charAt(i)) != Character.toLowerCase(cad.charAt(j)))
				esPalindromo = false;
			else {
				i++;
				j--;
			}
		}
		return esPalindromo;
	}

	// metodo que decide si es palindroma o no, y que primero elimina los
	// espacios de la cadena

	public static boolean es_palindroma_blancos(String cad) {

		String s2 = eliminar_blancos(cad);

		System.out.println("Una vez de eliminado los espacios, la cadena se queda: "+ s2);

		boolean palindroma = true;

		int i = 0, j = s2.length() - 1;
		while (i <= s2.length() / 2 && palindroma) {
			// primero paso a minusculas para evitar equivocaciones
			if (Character.toLowerCase(s2.charAt(i)) != Character.toLowerCase(s2.charAt(j)))
				palindroma = false;
			else {
				i++;
				j--;
			}
		}

		return palindroma;
	}

}
