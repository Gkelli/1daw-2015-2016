
public class Ejercicio02 {

	public static void main(String[] args) {
		
		// 2.	Dadas dos cadenas introducidas por teclado, escribir un m�todo que devuelva la cadena resultante de la concatenaci�n en may�sculas.
		
		System.out.println("Introduzca una cadena de caracteres");
		String cadena1 = LeerTeclado.readString();
		

		System.out.println("Introduzca otra cadena de caracteres");
		String cadena2 = LeerTeclado.readString();
		
		// probando la primera opcion
		char [] result = new char[cadena1.length()+cadena2.length()];		
		
		result= concatenacion(cadena1.toUpperCase(), cadena2.toUpperCase());
		
		System.out.println("OPCI�N 1: La cadena resultante es :");
		for (int i = 0; i < result.length; i++) {
			System.out.print(result[i]);
		}
		
		// probando la segunda opcion
		String resultado =  concatenacion2(cadena1, cadena2);
		System.out.println("\nOPCI�N 2: La cadena resultante es :\n" + resultado.toUpperCase());
		
		

	}
	//OPCI�N 1: dado dos cadenas recojo cada una, y guardo las posiciones en un array de caracteres con la longitud resultante de la suma de las dos cadenas
	public static char [] concatenacion(String cad1, String cad2){
		char [] c = new char[cad1.length()+cad2.length()];
		
		for (int i = 0; i < cad1.length(); i++) {
			c[i]+=cad1.charAt(i);
		}
		
		for (int i =cad1.length(); i < cad1.length() + cad2.length(); i++) {
			c[i]+=cad2.charAt(i - cad1.length());
		}
		
		return c;
	}

	//OPCI�N 2: dado dos cadenas recojo cada una, y guardo las posiciones en una nueva cadena
	public static String concatenacion2(String cad1, String cad2){
		String c = new String();
		
		for (int i = 0; i < cad1.length(); i++) {
			c+=cad1.charAt(i);
		}
		for (int i = 0; i < cad2.length(); i++) {
			c+=cad2.charAt(i);
		}
		
		return c;
	}
	
	
}
