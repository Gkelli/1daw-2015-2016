public class Ejercicio01 {

	public static void main(String[] args) {
		// Algoritmo que dado dos n�meros calcule su suma. resta, producto y
		// divisi�n e imprima
		// el resultado.

		System.out.println("Introduzca dos numeros");
		int a = LeerTeclado.readInteger();
		int b = LeerTeclado.readInteger();
		int suma, resta, producto, resto;
		double cociente;
		suma = a + b;
		producto = a * b;
		resta = a - b;
		resto = a % b;
		cociente = (double) a / b;
		System.out.println("suma=" + suma);
		System.out.println("resta=" + resta);
		System.out.println("producto=" + producto);
		if (b == 0)
			System.out.println("No es posible dividir entre 0");
		else {
			cociente = (double) a / b;
			System.out.println("El cociente es " + cociente);
			resto = a % b;
			System.out.println("resto=" + resto);
		}
	}
}
