
public class Ejercicio38 {

	public static void main(String[] args) {
		// 38. Algoritmo que determine cu�ntas cifras posee un n�mero
		// entero positivo introducido por teclado.

		int num, i=1;
		System.out.println("Introduce un n�mero");
		num= LeerTeclado.readInteger();
				
		while (num>=10) {
			num=num/10;
			i++;
		}
		System.out.println("El n�mero tiene " +i+ " cifra");
	}

}
