
public class Ejercicio20opcion1 {

	public static void main(String[] args) {
		// 20.	Imprimir la suma de los m�ltiplos de 2 desde el 8 al 400. 
		// Opcion1
		
		int i;
		for (i=8; i<=400; i+=2) {
			System.out.println(i);
		}
			

	}

}
