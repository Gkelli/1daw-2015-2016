
public class Ejercicio22opcion1 {

	public static void main(String[] args) {
		// 22. Aceptar n�meros por teclado hasta que la suma de todos 
		// ellos sea superior a 1000.
		// Opci�n 1
		
		int suma=0, n;
		n= LeerTeclado.readInteger();
		
		while (suma <= 1000) {
			suma = suma + n;
			n= LeerTeclado.readInteger();
			}
		System.out.println("La suma de todos los numeros hasta 1000 es" +suma);
		
	}

}
