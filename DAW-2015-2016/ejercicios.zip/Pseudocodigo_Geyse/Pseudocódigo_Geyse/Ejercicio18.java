
public class Ejercicio18 {

	public static void main(String[] args) {
		// 18.Algoritmo que calcule la suma de todos los n�meros comprendidos entre dos dados 
		
		int n,m, i, suma=0, aux;
		System.out.println("Introducir un numero");
		n= LeerTeclado.readInteger();
		m= LeerTeclado.readInteger();
		
		
		if (n > m) {
			aux = n;
			n = m;
			m = aux;
		}
		
		for (i = n; i <= m; i++)
			suma = suma + i;

		System.out.println("La suma de los numeros " + suma);
	}

}
