
public class Ejercicio23 {

	public static void main(String[] args) {
		
		// 23. Dada la ecuaci�n y =x^3+5*x^2-2*x visualizar el valor de y para los valores 
		// de x multiplos de 5 desde el 10 al 75
		
		double y;
		for(int i=10; i<=75; i=i+5)
		{
			y=Math.pow(i, 3)+5*Math.pow(i, 2)-2*i;
			System.out.println("Para x = " +i+ " y= " +y );
		}
	}

}
