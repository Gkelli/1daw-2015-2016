
public class Ejercicio29 {

	public static void main(String[] args) {
		// 29. Obtener las tablas de multiplicar de los n�meros del 1 al 10.
		
		int  prod=1;

		for (int i = 1; i <= 10; i++) {
			System.out.println("\nLa tabla de multiplicar de " + i + " es:\n");
			for (int j = 1; j <= 10; j++) {
				prod = i*j;
				System.out.println("La tabla de multiplicar de " +i+" x "+j+" = " +prod);
			}
		}
	}

}
