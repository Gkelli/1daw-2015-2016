
public class Ejercicio21 {

	public static void main(String[] args) {
		// 21.Pedir al usuario 10 n�meros enteros y decidir cu�ntos son pares y cu�ntos impares, 
		// obtener la suma de los pares y la media aritm�tica de los impares.
		
		int n;
		System.out.println("Introduce numeros 0 fin");
		n= LeerTeclado.readInteger();
		while (n!=0) {
			if (n%2==0)
			System.out.println("Es par");
			else 
			System.out.println("Es impar");
			n= LeerTeclado.readInteger();
		}
		
	}

}
