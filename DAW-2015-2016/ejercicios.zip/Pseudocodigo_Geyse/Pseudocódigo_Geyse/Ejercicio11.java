public class Ejercicio11 {

	public static void main(String[] args) {
		// 11.Calcular la suma de los n�meros del 1 al 100
		
		int i, suma=0;
		for (i = 1; i <= 100; i++) {
			suma+=i;
		
		}
		System.out.println(suma);
	}

}
