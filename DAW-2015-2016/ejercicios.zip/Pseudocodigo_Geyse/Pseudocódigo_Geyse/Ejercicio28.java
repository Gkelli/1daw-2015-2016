
public class Ejercicio28 {

	public static void main(String[] args) {
		// 28. Algoritmo que dada una serie de n� terminada en 0 indique si ha habido alg�n negativo
		
		int num;
		boolean encontrado=false;
		
			System.out.println("Introduce un numero, 0 fin");
			num= LeerTeclado.readInteger();
				while (num!=0) {
					if (num<0) {
						encontrado=true;
						num= LeerTeclado.readInteger();
					}
				}
				if (encontrado=true) {
				System.out.println("ha habido alg�n n�mero negativo" +encontrado);
				System.out.println("Negativo");
				} else
					System.out.println("no ha habido mimg�n n�mero negativo");
					
				}
	}

