
public class Ejercicio27 {

	public static void main(String[] args) {
		// 27. Dados dos n�meros x, y  calcular por sumas sucesivas x * y.
		
		int x, y, suma=0;
		System.out.println("Introduce numero x, y");
		x= LeerTeclado.readInteger();
		y= LeerTeclado.readInteger();

		if (x>y) {
			for (int i = 1; i <= y; i++) {
				suma = suma + x;
		}
		} else {
			for (int i = 1; i <= x; i++) {
				suma = suma + y;
			}
		}
		System.out.println("La suma es " +suma);
	}
	

}
