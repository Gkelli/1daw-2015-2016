
public class Ejercicio17 {

	public static void main(String[] args) {
		// 17.Calcular el factorial de un n�mero
		
		int num;
		double factorial=1;
		System.out.println("Introducir un numero");
		num= LeerTeclado.readInteger();
		
			while (num!=0) {
				factorial=factorial*num;
				num=num-1;
			}
		System.out.println("El factorial de un numero leido es"  +factorial);
	
	}
	
	
	

}
