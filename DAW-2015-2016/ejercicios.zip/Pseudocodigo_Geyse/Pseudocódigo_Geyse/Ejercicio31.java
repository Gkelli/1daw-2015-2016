
public class Ejercicio31 {

	public static void main(String[] args) {
		// 31.	Algoritmo que dado un n� N y una serie de n�meros terminada en 0 
		// indique si el n�mero N se encuentra en la serie.
		
		int n, num;
		boolean encontrado=false;

		System.out.println ("Introduce el n� a buscar");
		n=LeerTeclado.readInteger();
		System.out.println ("Introduce un n� de la serie. 0 :fin");
		num=LeerTeclado.readInteger();

		while (num!=0){	
			if (num==n)
				encontrado=true;
			System.out.println ("Introduce otro numero");
			num=LeerTeclado.readInteger();

		}
		if (encontrado)
			System.out.println("El n� "+n+ " estaba en la serie");
		else 
			System.out.println("El n� "+n+ " no estaba en la serie");
		
	}
}
