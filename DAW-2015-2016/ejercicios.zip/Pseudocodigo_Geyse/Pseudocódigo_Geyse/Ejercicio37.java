
public class Ejercicio37 {

	public static void main(String[] args) {
		// 37.Algoritmo que lee tres n�meros, los visualiza en orden 
		// creciente e indica si fueron introducidos en ese orden.

		int a, b, c, aux;
		System.out.println("Introducir n�meros A, B, C");
		a= LeerTeclado.readInteger();
		b= LeerTeclado.readInteger();
		c= LeerTeclado.readInteger();
			if ((a<b) && (b<c)) {
				System.out.println("La serie esta ordenada");
			} else {
				if (a>c) {
					aux=a;
					a=c;
					c=aux;
				}
				if (b>c) {
					aux=b;
					b=c;
					c=aux;
				}
				if (a>b) {
					aux=a;
					a=b;
					b=aux;
				}
				System.out.println("La serie no esta ordenada, la serie ordenada es " +a+" - "+b+" - "+c);
			}
	}

}
