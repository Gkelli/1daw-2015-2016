
public class Ejercicio25 {

	public static void main(String[] args) {
		// 25. Algoritmo que, dado un a�o, decida si es bisiesto o no: Es m�ltiplo de 4 Y o 
		// bien es m�ltiplo de 400 o no es m�ltiplo de 100.
		
		int year;
		System.out.println("Introduce a�o");
		year= LeerTeclado.readInteger();
			if ((year%4 == 0) && (year%100!= 0 || year%400 == 0)) {		
				System.out.println("El a�o " +year+ " es bisiesto");
			} else {
				System.out.println("El a�o " +year+ " no es bisiesto");
			}
	}

}
