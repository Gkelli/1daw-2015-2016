
public class Ejercicio14 {

	public static void main(String[] args) {
		// 14.Idem la media
		
		int num, suma=0, cont=0;
		double media=0;
		System.out.println("Introduce un numero");
		num= LeerTeclado.readInteger();
	while (num!=0) {
			
			suma=suma+num;
			cont ++;
			System.out.println("Introduce otro numero, 0 fin");
			num=LeerTeclado.readInteger();
			}
		if (cont!=0) {
			media=suma/cont;
			System.out.println("La media de los numeros" + media);
		} else 
			System.out.println("No se ha introducido numero");
		
	}

}
