
public class Ejercicio30 {

	public static void main(String[] args) {
		//30. Se introducen edades de 25 alumnos de una clase, imprimir la
		// edad del m�s joven, la del mayor y la media de la clase. 
		
		int i, num, mayor=Integer.MIN_VALUE, menor=Integer.MAX_VALUE,suma=0, cont=0, media=0;
			
		
		for (i = 0; i < 5; i++) {
			System.out.println("Introduce edad ");
			num= LeerTeclado.readInteger();
			
			
			if (num<menor) {
				menor= num;
			} else
				if (num>mayor) {
				mayor= num;					
			}
			 suma+= num;
			 cont++;
		
	}
		media= suma/cont;
		System.out.println("El m�s joven es " +menor);
		System.out.println("El mayor es " +mayor);
		System.out.println("La media de la clase es " + media);
	}
}
