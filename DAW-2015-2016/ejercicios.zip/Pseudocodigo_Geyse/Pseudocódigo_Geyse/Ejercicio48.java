
public class Ejercicio48 {

	public static void main(String[] args) {
		// 48. Algoritmo que calcule los numeros amigos de 1 al 1000
		
		int n, m, suma_n=0, suma_m=0, cont_amigos=0;

			for (n = 1; n <= 999; n++) {
				suma_n=0;
				for (int i = 1; i <= n/2; i++) {
					if (n%i==0) 
						suma_n=suma_n+i;
					
				}
				
				for (m = n+1; m <= 1000; m++) {
					suma_m=0;
					for (int j = 1; j <= m/2; j++) 
						if (m%j==0) 
							suma_m=suma_m+j;

					if (suma_n==m && suma_m==n) {
						System.out.println(n+" "+m+ " amigos");
						cont_amigos=cont_amigos+1;
					}

				}
			
			}
			System.out.println("hay " +cont_amigos+ " numeros amigos");

	}

}
