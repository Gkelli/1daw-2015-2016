
public class Ejercicio40 {

	public static void main(String[] args) {
		// 40.Algoritmo que calcule todos los n�meros perfectos de 1 a 1000

		int acum=0;
		for (int i = 1; i < 1000; i++) {			
			acum=0;			
			for (int j = 1; j < i; j++) {
				if (i%j==0) {
					acum+=j;
				}
			}
			
			if (i==acum) {
				System.out.println( +i+ " es perfecto");
				}
			
		}
		
	}

}
