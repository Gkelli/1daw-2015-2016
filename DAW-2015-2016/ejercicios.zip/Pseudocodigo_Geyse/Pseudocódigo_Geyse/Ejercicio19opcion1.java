
public class Ejercicio19opcion1 {

	public static void main(String[] args) {
		// 19.	Algoritmo que calcule el valor m�nimo, m�ximo y medio de una serie de n�meros 
		// introducidos por teclado (la serie termina cuando se introduce un 0).
		// Opci�n 1

		int m, max=Integer.MIN_VALUE, min=Integer.MAX_VALUE,suma=0, cont=0, media=0;
		
		System.out.println("Introduce un numero 0 fin");
		m= LeerTeclado.readInteger();
			
			while (m!=0) {
				if (m<min) {
					min = m;
				}
				if (m>max) {
					max = m;
					}
			suma= suma + m;
			cont= cont + 1;
			
			System.out.println("otro numero");
			m= LeerTeclado.readInteger();
			
			}
			
			if (cont==0)
				System.out.println("Escribir no hay valores");
			else
				media= suma/cont;
			
			System.out.println("La media es " +media);
			System.out.println("El valor maximo es " +max);
			System.out.println("El valor minimo es " +min);
		
	}

}
