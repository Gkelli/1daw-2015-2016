
public class Ejercicio10 {

	public static void main(String[] args) {
		// 10.	Obtener la tabla de multiplicar de un n�mero entre 1 y 10 
		// introducido por teclado
		
		int N;
		
		do {				
		System.out.println("Introducir n�mero 1 al 10");
		N=LeerTeclado.readInteger();
		} while (N<0 || N>10);			
		
		for (int i=0; i<=10; i++) {
			System.out.println(N+ "x" +i+ "=" +(N*i));
		}
		
		
		
	}

}
