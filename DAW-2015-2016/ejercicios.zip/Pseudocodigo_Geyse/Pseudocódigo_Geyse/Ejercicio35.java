
public class Ejercicio35 {

	public static void main(String[] args) {
		// 35.Visualizar los n�meros primos hasta el N.

		int num;
		boolean primo= true;
		
		System.out.println("Introduce un n�mero");
		num= LeerTeclado.readInteger();
			for (int i = 2; i < num; i++) {
				primo= true;
				for (int j = 2; j < i/2; j++) {
					if (i%j==0) {
						primo= false;
					}
				}
				if (primo==true) {
					System.out.println("el numero " +i+ " es primo");
				}
			}
	}

}
