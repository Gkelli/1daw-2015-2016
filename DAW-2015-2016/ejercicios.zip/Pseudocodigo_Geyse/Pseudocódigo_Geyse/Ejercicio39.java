
public class Ejercicio39 {

	public static void main(String[] args) {
		// 39.Algoritmo que dado un n�mero diga si es perfecto 
		// (cuando la suma de sus divisores excluido �l es igual 
		//  a dicho n�mero) 

		int suma=0, num;
		
			do {
				System.out.println("Introduce un n�mero");
				num= LeerTeclado.readInteger();
			} while (num<=0);

			for (int i = 1; i <= num/2; i++) {
				if (num%i==0) 
					suma=suma+i;
				
			}
			
			if (num==suma) 
				System.out.println("N�mero es perfecto");
			else 
				System.out.println("N�mero no es perfecto");
			
		
	}

}
