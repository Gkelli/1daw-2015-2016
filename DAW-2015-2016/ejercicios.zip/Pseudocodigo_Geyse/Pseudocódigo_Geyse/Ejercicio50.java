public class Ejercicio50 {

	public static void main(String[] args) {
		// A. Cuantos pares e impares se han generado.
		// B. Calcule la suma de todos los pares e impares introducidos.
		// C. Si ha habido alg�n par o impar

		int n, contpar=0, sumapar=0, contimpar=0, sumaimpar=0, contotal=0;
		boolean par=false, impar=false;
		
		System.out.println("Introduce n�meros 0 :fin");
		n= LeerTeclado.readInteger();
			while (n!=0) {
				if (n%2==0) {
					System.out.println("es par " +n);
					contpar++;
					sumapar+=n;
					par= true;
				} else {
					System.out.println("es impar " +n);
					contimpar++;
					sumaimpar+=n;
					impar= true;
				}
			contotal++;
			n= LeerTeclado.readInteger();
			}
			System.out.println("Hay " +contpar+ " numeros par " +contimpar+ " numeros impar");
			System.out.println("La suma de los numeros pares " +sumapar);
			System.out.println("La suma de los numeros impares " +sumaimpar);
			System.out.println("�Hay pares? " +par);
			System.out.println("�Hay impares? " +impar);
			contotal=contpar+contimpar;
			System.out.println("Total: " + contotal);
			
	}

}

