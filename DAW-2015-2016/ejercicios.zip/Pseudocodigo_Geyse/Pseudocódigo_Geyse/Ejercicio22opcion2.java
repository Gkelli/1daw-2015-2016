
public class Ejercicio22opcion2 {

	public static void main(String[] args) {
		// 22.	Aceptar n�meros por teclado hasta que la suma de todos 
		// ellos sea superior a 1000. 
		// Opci�n 2
		
		int num, acum=0;
		do {
			System.out.println("Introduzca un numero");
			num= LeerTeclado.readInteger();
			acum= acum + num;
		} while (acum<= 1000);
		System.out.println("La suma es" +acum);
	}

}
