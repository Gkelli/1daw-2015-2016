

public class Ejercicio42 {

	public static void main(String[] args) {
		// 42. Algoritmo que determina si dos n�meros enteros positivos son 
		// amigos (Dos n�meros son amigos si la suma de los divisores
		// del primero, excepto �l mismo, es igual al segundo y 
		// viceversa)

		int i, suma_n=0, suma_m=0, n, m;
		do {
			System.out.println("Introduce dos n�meros positivos");
			n= LeerTeclado.readInteger();
			m= LeerTeclado.readInteger();
			
		} while ((n<=0) || (m<=0));
		
		for (i = 1; i <= n/2; i++) {
			if(n%i==0)
			suma_n=suma_n+i;
		}
		
		for (i = 1; i <= m/2; i++) {
			if(m%i==0)
			suma_m=suma_m+i;
		}
		
	if (suma_n==m && suma_m==n) 
		System.out.println("Los n�meros son amigos");
	 else 
		System.out.println("Los n�meros no son amigos");
		
	}

}
