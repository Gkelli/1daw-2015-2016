public class Ejercicio20opcion2 {

	public static void main(String[] args) {
		// 20.	Imprimir la suma de los m�ltiplos de 2 desde el 8 al 400. 
		// Opcion 2
		
		int num;
		for (num=8; num<=400; num+=2) {
			if (num%2==0)
			System.out.println(num);
		}
			

	}

}