
public class Ejercicio03 {
	
	public static void main(String[] args) {
		// 3.Algoritmo que calcule el valor de Y en la ecuaci�n de 1� grado y=A * X +b (pidiendo
		// primero A y B y luego dos valores de X)
		
		System.out.println("Introducir valores para A y B");
		double a, b, x, y;
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();
		System.out.println("Introduce un valor para X");
		x=LeerTeclado.readInteger();
		y=a*x*b;
		System.out.println("Y = "+y);
		System.out.println("Introduce otro valor para X");
		x=LeerTeclado.readInteger();
		y=a*x*b;
		System.out.println("Y = "+y);

	}
}
