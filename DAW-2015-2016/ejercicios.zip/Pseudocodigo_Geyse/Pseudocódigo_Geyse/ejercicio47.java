
public class ejercicio47 {
	public static void main(String[] args) {
		// 47.Algoritmo que calcule el valor m�nimo, m�ximo y medio de una serie de n�meros introducidos por teclado
		// 	acabando la serie con tres cincos consecutivos (5,5,5) (considerar qui�n es el n� introducido n y qui�n 
		//	es el �ltimo y el pen�ltimo).
		
		int n, suma, max, min, cont,ultimo=0, penultimo=0;
		double media;
		suma=0;cont=0;
		max=Integer.MIN_VALUE;
		min=Integer.MAX_VALUE;
		System.out.println ("Introduce un n�, despu�s de tres 5 seguidos se termina");
		n=LeerTeclado.readInteger();

		while (ultimo!=5||penultimo!=5||n!=5) {
			suma+=n;
			cont++;
				if (n>max)
					max=n;
				if (n<min)
					min=n;
					penultimo=ultimo;
					ultimo=n;
					System.out.println ("Introduce un n�,despu�s de tres 5 seguidos se termina");
					n=LeerTeclado.readInteger();
				}

		System.out.println ("la suma total es "+suma);	
		System.out.println("se han introducido "+cont+" numeros");
			if (cont>0) {
			media=((double)suma/cont);
			System.out.println("la media es "+media);
			System.out.println("Maximo= "+max);
			System.out.println("Minimo= "+min);}
			else
			System.out.println ("El maximo y minimo son 0");
	}
}
