
public class Ejercicio13 {

	public static void main(String[] args) {
		// 13.Calcular la suma de n�meros hasta que se teclee un 0
		
		int N, suma = 0;
		
		System.out.println("Introduce n�mero, 0 fin");
		N= LeerTeclado.readInteger();		
		
		while (N!=0) {
			
			suma=suma+N;
			System.out.println("Introduce otro numero, 0 fin");
			N=LeerTeclado.readInteger();
			
		}
		System.out.println("La suma es " + suma);
	}

}
