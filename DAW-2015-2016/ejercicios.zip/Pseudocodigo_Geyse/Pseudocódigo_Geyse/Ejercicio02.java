
public class Ejercicio02 {
	
	public static void main(String[] args) {
		// 3.Algoritmo que dado un radio calcule la longitud de su circunferencia 
		// y el area del c�rculo.
		
		double radio=5;
		double longitud, area;
		final double PI=3.14;
		
		longitud=2* PI * radio;
		area=PI * Math.pow(radio, 2);

		System.out.println("La longitud de la circunferencia es " + longitud);
		System.out.println("El area del circulo es " + area);
	}

}
