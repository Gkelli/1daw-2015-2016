
public class Ejercicio06 {

	public static void main(String[] args) {
		// 6.Algoritmo que decida si un n�mero es positivo, negativo o cero.
		
		String respuesta;
		
		do {
	
			System.out.println("Ingrese n�mero");
		int num= LeerTeclado.readInteger();
		if (num>0) {
			System.out.println("Positivo");
		} else 
			if (num<0) {
				System.out.println("Negativo");
			} else {
				System.out.println("Cero");
			}

			System.out.println("�Quieres seguir? s/n");
			respuesta  = LeerTeclado.readString();
		} while (respuesta.equalsIgnoreCase("s"));
		
		System.out.println("FIN");
		
	}

}
