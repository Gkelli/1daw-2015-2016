
public class Ejercicio32 {

	public static void main(String[] args) {
		// 32.Idem contando las veces que se repite N en la serie.

		int n, num, cont=0;
	
		System.out.println ("Introduce el n� a buscar");
		n=LeerTeclado.readInteger();
		System.out.println ("Introduce un n� de la serie. 0 :fin");
		num=LeerTeclado.readInteger();

		while (num!=0){	
			if (num==n)
				cont++;
			System.out.println ("Introduce otro numero");
			num=LeerTeclado.readInteger();

		}
		
		System.out.println("El n� "+n+ " estaba en la serie " + cont + " veces");
		
	}
}

