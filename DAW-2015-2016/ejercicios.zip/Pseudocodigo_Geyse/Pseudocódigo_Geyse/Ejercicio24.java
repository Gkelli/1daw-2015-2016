public class Ejercicio24 {

	public static void main(String[] args) {
		// 24.Algoritmo que calcule todos los divisores de un n� N.
	
		int n;
		do {
			System.out.println("Introduce numero positivo");
			n= LeerTeclado.readInteger();
		} while (n <= 0);
			System.out.println("Los divisores de " +n+ " son");
			for (int d = 1; d <= n; d++) {
				if (n%d== 0) {
					System.out.println(d);
				}
			}
	}

}
