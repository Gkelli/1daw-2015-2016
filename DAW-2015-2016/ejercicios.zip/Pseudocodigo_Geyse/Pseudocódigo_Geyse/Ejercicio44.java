
public class Ejercicio44 {

	public static void main(String[] args) {
		// 44.Sumar una serie (que acabar� con un 0) de n�meros enteros 
		// decidiendo si dicha serie est� ordenada o no de mayor a menor.

		int num, suma=0, aux;
		boolean ordenado=true;
		
		
			System.out.println("Introduce numeros 0 fin");
			num= LeerTeclado.readInteger();
			aux=num;
			
				while (num!=0) {
						if (num<aux) {
						ordenado=false;
					}
				suma=suma+num;
				aux=num;
				System.out.println("Introduce otro n�mero");
				num= LeerTeclado.readInteger();
				}
				
				if (ordenado) {
					System.out.println("Esta ordenado de menor a mayor");
				} else {
					System.out.println("No esta ordenado de menor a mayor");
				}
	}

}
