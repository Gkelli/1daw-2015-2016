public class Ejercicio33 {

	public static void main(String[] args) {
		// 33. Dado un n�mero, decir si es primo 

		int num;
		boolean primo=true;
			
			do {
				System.out.println("Introduce un n�mero");
				num= LeerTeclado.readInteger();
			} while (num<0);
			
				for (int i = 2; i < num/2; i++) {
					if (num%i==0) {
						primo=false;
					}					
				}
				
			if (primo==true) {
				System.out.println("es primo");
			} else {
				System.out.println("no es primo");
			}
	}

}
