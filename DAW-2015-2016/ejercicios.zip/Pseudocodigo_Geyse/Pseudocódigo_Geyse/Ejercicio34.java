
public class Ejercicio34 {

	public static void main(String[] args) {
		// 34.Visualizar los N primeros n�meros primos.

		int n, m=2,cont=0;
		boolean  primo=true;
		
		do {
			System.out.println("Introduce un n�mero");
			n= LeerTeclado.readInteger();
		} while (n<0);
		
			while (cont<n){
			primo=true;
				for (int i = 2; i < m/2; i++) {
					if (m%i == 0) 
						primo=false;
						
					}	
				
		if (primo == true) {
			System.out.println( m+ " es primo");			
		}
		cont=cont+1;
		m=m+1;
		}
	}

}
