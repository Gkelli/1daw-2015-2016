public class Ejercicio43 {

	public static void main(String[] args) {

		// 43. Introducir dos n�meros por teclado y mediante un men� calcular su
		// suma, resta, multiplicaci�n o divisi�n.
		
		int a,b,opcion;
		System.out.println("Introduce dos n�meros");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();
		
		do {
			System.out.println();
			System.out.println("Elige la operaci�n");
			System.out.println("1: Suma");
			System.out.println("2: Resta");
			System.out.println("3: Producto");
			System.out.println("4: Divisi�n");
			System.out.println("5: Fin");
			
			System.out.println("\nIntroduce opci�n (1-5)");
			opcion=LeerTeclado.readInteger();
			
			switch (opcion) {
			case 1:
				System.out.println();
				System.out.println("El resultado de la suma es "+(a+b));
				break;
				
			case 2:
				System.out.println();
				System.out.println("El resultado de la resta es "+(a-b));
				break;
				
			case 3:
				System.out.println();
				System.out.println("El resultado del producto es "+(a*b));
				break;
				
			case 4:
				System.out.println();
				if (b!=0)
					System.out.println("El resultado de la division es "+((double)a/b));
				else System.out.println("Lo sentimos, no se puede dividir entre 0");
				break;
				
			case 5:
				System.out.println("Fin de programa ");
				break;

			default:
				System.out.println("Error en opci�n (1-5)");
				break;
			}
			
		}
		
		while (opcion!=5);

	
		}

}
