
public class Ejercicio45 {

	public static void main(String[] args) {
		// 45.Algoritmo que lea una fecha en formato d�a, mes, a�o y obtiene el n�mero de orden del d�a 
		//    en el total del a�o (Ejemplo: si se lee 01 03 2005, se obtiene 61� de 2005)
		// 		a) Considerando todos los meses de 30 d�as
		// 		b) Considerando en cada mes los d�as que tiene

		int dia, mes, anno,  total=0, diasMes=0;

		do{
			System.out.println ("introduce a�o");
			anno=LeerTeclado.readInteger(); 
			} while ( anno<0 || anno>9999 );
 
		do{
			System.out.println ("introduce mes(1-12)");
			mes=LeerTeclado.readInteger();
		}
		while (mes<1 || mes>12);

		switch (mes){
		case 1: case 3: case 5: case 7: case 8: case 10: case 12: 
			diasMes=31;
			break; 
		case 4: case 6: case 9: case 11:
			diasMes=30;
			break;
		case 2: {
			if ((anno%4==0) && ((anno%100!=0) || (anno%400==0))){
				System.out.println("A�o bisiesto");
				diasMes=29;
				}
			else 
				diasMes=28;
			break;
		}
		}
		do{
			System.out.println ("introduce dia (entre 1-"+diasMes+")");
			dia=LeerTeclado.readInteger();
		}
		while (dia<1 || dia>diasMes); 

		total=dia; 
	
		switch (mes-1){
			case 11:total+=30;
			case 10:total+=31;
			case 9: total+=30;
			case 8: total+=31;
			case 7: total+=31;
			case 6: total+=30;
			case 5: total+=31;
			case 4: total+=30;
			case 3: total+=31;
			case 2: {if ((anno%4==0) && ((anno%100!=0) || (anno%400==0))){
					total+=29;System.out.println("El a�o es bisiesto");
					}					
					else total+=28;}
			case 1: total+=31;

		}
		System.out.println ("Han pasado "+total+" dias desde el 1/1/"+ anno+ " hasta la fecha introducida "+dia+"/"+mes+"/"+anno);
	}

}
