
public class Ejercicio15 {

	public static void main(String[] args) {
		// 15.	Imprimir los m�ltiplos de 3 hasta N
		
		int N;
		System.out.println("Introduce un numero");
		N= LeerTeclado.readInteger();
			for (int i = 3; i <= N ; i+=3) {
				System.out.println(i);
			}
		}

}
