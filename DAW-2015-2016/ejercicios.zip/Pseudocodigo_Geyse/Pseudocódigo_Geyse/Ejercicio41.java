
public class Ejercicio41 {

	public static void main(String[] args) {
		// 41. Se introduce una serie de 50 letras y se cuenta cu�ntas veces se repite la primera de ellas

		int cont=1; 
		String letraBuscada, nuevaLetra;
		
		System.out.println("Escribe la letra que quieras ver repetirse");
		letraBuscada=LeerTeclado.readString();
		
		
		for (int i = 2; i < 50; i++) {
			System.out.println("Escribir otra letra");
			nuevaLetra=LeerTeclado.readString();
			if(nuevaLetra.equalsIgnoreCase(letraBuscada))
				cont++;
			
		}
		System.out.println("La primera letra es " +letraBuscada);
		System.out.println("El n� de veces que se repite es " +cont);

	}

}
