
public class Ejercicio04a {

	public static void main(String[] args) {
		// Algoritmo que dados tres n� a, b y c;
		// A.calcule el valor de Y en la ecuaci�n de 2� grado: y=ax2+bx+c 
		// (pidiendo primero a, b y c y luego dos  valores de X).
		
		double a,b,c,x,y;
		System.out.println("Introducir a,b,c");
		a= LeerTeclado.readInteger();
		b= LeerTeclado.readInteger();
		c= LeerTeclado.readInteger();
		System.out.println("Introducir el primer valor para X");
		x= LeerTeclado.readInteger();
		y= a* Math.pow(x, 2) +b*x+c;
		System.out.println("y="+y);
		System.out.println("Introducir el segundo valor para X");
		x= LeerTeclado.readInteger();
		y= a* Math.pow(x, 2) +b*x+c;
		System.out.println("y="+y);
		

		
			
		
	}

}
