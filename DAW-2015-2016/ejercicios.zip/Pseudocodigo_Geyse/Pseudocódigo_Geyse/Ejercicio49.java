
public class Ejercicio49 {

	public static void main(String[] args) {
		// 49. Dados 15 n�meros decir cuales son pares y cuales impares
		
		int num;
		System.out.println("Introduce un n�mero");
		num= LeerTeclado.readInteger();
		while (num!=0) {
			if (num%2==0) {
				System.out.println("N�mero par");
			} else {
				System.out.println("N�mero impar");
			}
			System.out.println("Introduce n�mero");
			num= LeerTeclado.readInteger();
		}
	}

}
