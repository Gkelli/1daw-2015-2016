
public class Ejercicio05 {

	public static void main(String[] args) {
		// 5.Algoritmo que decida si un n�mero introducido por teclado es par o impar.
		
		System.out.println("Ingrese numero");
		int num = LeerTeclado.readInteger();
		
		if (num==0) {
			System.out.println("cero");
		} else 
			if(num%2==0) 
				System.out.println("Par");
				else{
					System.out.println("impar");					
		}
	
	}

}
