
public class Ejercicio04b {

	public static void main(String[] args) {
		// Algoritmo que dados tres n� a, b y c;
		// B.resuelva la ecuaci�n de 2� grado: ax2+bx+c=0 

		
		double a,b,c, rad,x1, x2;
		System.out.println("Introducir A,B,C");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();
		c=LeerTeclado.readInteger();
		rad= Math.pow(b, 2)-4*a*c;
			if (a==0){
				x1= -c/b;
						System.out.println("Las raices son, 0 y" +x1);}
			else {
				if (rad<0){
					System.out.println("No se puede calcular");}
				else{
					x1= (-b+ Math.sqrt(rad))/(2*a);
					x2= (-b- Math.sqrt(rad))/(2*a);
					System.out.println("Los valores de X son "+x1+x2);
					}
			}
							
	}

}
