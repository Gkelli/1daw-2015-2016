
public class Ejercicio26 {

	public static void main(String[] args) {
		// 26. Visualizar los factoriales de los n�meros del 1 al 10.
		
		int j, factorial, i=1;

		for (j = 1; j < 11; j++) {
			factorial=1;
				for (i = 1; i < j; i++) {
					factorial= factorial*i;
				}
				System.out.println("Factorial de " +j+ " = " +factorial);
		}
	}

}
