public class Ejercicio12 {

	public static void main(String[] args) {
		// 12.Calcular el producto de los n�meros del 1 al 100
		
		int i;
		double producto=1;
		for ( i = 1; i <= 100; i++) {
			producto*=i;
			
		}
		System.out.println(producto);
	}

}
