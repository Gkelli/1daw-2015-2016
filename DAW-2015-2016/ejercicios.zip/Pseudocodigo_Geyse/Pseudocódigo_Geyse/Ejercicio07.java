
public class Ejercicio07 {

	public static void main(String[] args) {
		// 7.Algoritmo que lea dos n�meros y decida si uno es divisor de otro.
		
		
		System.out.println("Introduzca dos n�meros");
		double a, b;
		a = LeerTeclado.readDouble();
		b = LeerTeclado.readDouble();

		if ((a > b) && (a % b == 0)) {
			System.out.println(b+ " es divisor de " +a);
		} else {
			if ((b > a) && (b % a == 0)) {
				System.out.println(a+ " es divisor de " +b);
			} else if (a == b) {
				System.out.println("Son iguales");
			} else {
				System.out.println("No es divisor");

			}
		}
		
		
	}

}
