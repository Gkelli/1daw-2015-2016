
public class Empresa {
	private int numDptos=4;
	private Departamento[] listaDptos;
	
	public Empresa(){
		listaDptos=new Departamento[numDptos];
	}
	
	public void altaDpto(){
		int codDpto;
		do{
			System.out.println("Introduce c�digo de departamento a dar de alta");
			codDpto=LeerTeclado.readInteger();
		}
		while (!(codDpto>=0 && codDpto<4));
		
		Departamento dptoAux;
		dptoAux=buscarDptoCod(codDpto);
		if (dptoAux!=null)
			System.out.println("El departamento ya existe"+dptoAux.toString());
		else {
			//como no existe el dpto procedemos al alta
		    //pedimos los datos por teclado y creamos el dpto
			//luego llamamos a empresa.insertar()
			
			System.out.println("Introduce el nombre y el n� de empleados del dpto a dar de alta de c�digo "+codDpto);
			String nombre=LeerTeclado.readString();
			int numEmp=LeerTeclado.readInteger();
			
			dptoAux=new Departamento(codDpto,nombre,numEmp);
			insertarDpto(dptoAux);
			
			//podriamos haber llamado a insertar2(codDpto)
			//que se ocupar�a de pedir los datos, crear el dpto e insertarlo
			// empresa.insertar2(codDpto)
		}
	}
	
	public Departamento buscarDptoCod(int codDpto){
		return listaDptos[codDpto];
	}
	
	public Departamento buscarDptoNombre (String nb){
		Departamento dptoAux=null; 
		boolean enc=false;
		for (int i=0; i<listaDptos.length && enc==false; i++){
			if (listaDptos[i]!=null && listaDptos[i].getNombre().equalsIgnoreCase(nb))
				{
				dptoAux=listaDptos[i];
			//	break;
				enc=true;				
				}			
		}
		return dptoAux;
	}
	
	public void insertarDpto(Departamento dpto){	
		int i=dpto.getCodDpto();
		listaDptos[i]=dpto;
		//tambi�n:
		//listaDptos[dpto.getCodDpto()]=dpto;
	}
	
	public void insertarDpto2 (int cod){
		System.out.println("Introduce el nombre y el n� de empleados del dpto a dar de alta de c�digo "+cod);
		String nombre=LeerTeclado.readString();
		int numEmp=LeerTeclado.readInteger();
		
		Departamento dpto=new Departamento(cod,nombre,numEmp);
		
		listaDptos[cod]=dpto;
	}
}
