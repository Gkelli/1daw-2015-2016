
public class Departamento {
	private int codDpto;
	private String nombre;
	private int numEmp;
	private Empleado[] listaEmp;
	
	public Departamento(int codDpto, String nombre, int numEmp) {
		this.codDpto = codDpto;
		this.nombre = nombre;
		this.numEmp = numEmp;
		this.listaEmp=new Empleado[numEmp];
	}

	public int getCodDpto() {
		return codDpto;
	}

	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNumEmp() {
		return numEmp;
	}

	public void setNumEmp(int numEmp) {
		this.numEmp = numEmp;
	}

	public Empleado[] getListaEmp() {
		return listaEmp;
	}

	
	
	
	
	

}
