
public class Principal {

	public static void main(String[] args) {
		Empresa empresa=new Empresa();
		
		int opcion;
		do{
			System.out.println("1. Alta de departamento");
			
			
			opcion=LeerTeclado.readInteger();
			switch(opcion){
			//Esta opci�n ser�a si el m�todo altaDpto lo lanza la clase empresa
			case 1: empresa.altaDpto();break;
			}
		}
		while (opcion!=9);

	}

}
