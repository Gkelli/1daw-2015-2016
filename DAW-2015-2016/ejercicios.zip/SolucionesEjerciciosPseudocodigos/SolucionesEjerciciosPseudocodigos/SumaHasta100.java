
public class SumaHasta100 {

	
	public static void main(String[] args) {

		int suma=0;
		for (int i=1; i<=100; i++)
			suma+=i;
		System.out.println("la suma es: "+suma);
	}

}
