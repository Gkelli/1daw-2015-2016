
public class NumerosHastaN {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.print("Introduce un n� ");
		int n=LeerTeclado.readInteger();
		for (int i=1; i<=n; i++)
			 System.out.println(i);

	}

}
