
public class SumaMultiplosDos {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int suma=0;
		for (int i=8;i<=400;i=i+2)
			suma+=i;
		System.out.println("La suma de los pares desde 8 hasta 400 es "+suma);
	}

}
