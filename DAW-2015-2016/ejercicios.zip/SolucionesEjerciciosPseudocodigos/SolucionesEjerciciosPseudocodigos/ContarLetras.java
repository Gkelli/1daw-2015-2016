
public class ContarLetras {

	
	public static void main(String[] args) {
		String letraBuscada,nuevaLetra;
	//	char letra,aux; da problemas si se usa char
		System.out.println("introduce una letra");
		letraBuscada=LeerTeclado.readString();
		
		int cont=1;
		for (int i=2;i<=20;i++)
		{
			System.out.println("introduce una letra");
			nuevaLetra=LeerTeclado.readString();
			if (nuevaLetra.equalsIgnoreCase(letraBuscada)) //nuevaLetra==letraBuscada
				cont++;
		}
		System.out.println("la primera letra es "+letraBuscada);
		System.out.println ("el n� de veces que se repite es "+cont);
		
			
			

	}

}
