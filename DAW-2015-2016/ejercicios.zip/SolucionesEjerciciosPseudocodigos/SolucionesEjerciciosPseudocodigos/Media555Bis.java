
public class Media555Bis {

	public static void main(String[] args) {
		int n, suma, max, min, cont,ultimo=0, penultimo=0;
		int antiguoMax=0, antiguoMin=0, contMax=0, contMin=0;
		double media;
		suma=0;cont=0;
		max=Integer.MIN_VALUE;
		min=Integer.MAX_VALUE;
		System.out.println ("Introduce un n�, despu�s de tres 5 seguidos se termina");
		n=LeerTeclado.readInteger();
		
		while (ultimo!=5||penultimo!=5||n!=5) // tambi�n while !(ultimo==5 && penultimo==5 && n==5)
		{
			
			suma+=n;
			cont++;
			if (n>max){				
				antiguoMax=max;
				max=n;
				contMax=1;
			}
				else if (n==max) contMax++;
			
			
				
			if (n<min){				
				antiguoMin=min;
				min=n;
				contMin=1;
			}
				else if (n==min) contMin++;
			
			penultimo=ultimo;
			ultimo=n;
						
			System.out.println ("Introduce un n�,despu�s de tres 5 seguidos se termina");
			n=LeerTeclado.readInteger();
			
		}
		
		
		if (cont>3)
			{System.out.println ("la suma total es "+(suma-10)); //restamos los dos ultimos 5	
			System.out.println("se han introducido "+(cont-2)+" numeros"); //restamos del contador 2 por los dos ultimos 5
			media=((double)suma/cont);//hago el casting de suma a double para que la division sea real y no entera.
			System.out.println("la media es "+media);
			if (max!=5|| (max==5 && contMax>2))	//si el maximo no es 5 se imprime, tambi�n se imprime si es 5 pero ha aparecido m�s de dos veces 
				System.out.println("Maximo= "+max);
			else System.out.println("Maximo="+antiguoMax); //en caso contrario se coge el antiguo maximo
			
			if (min!=5 || (min==5 && contMin>2))
				System.out.println("Minimo= "+min);
			else
				System.out.println("Minimo"+antiguoMin);
			}
		
		else
			System.out.println ("Se han introducido solo los tres 5, la suma, la media, el  maximo y minimo son 0");

	}

}
