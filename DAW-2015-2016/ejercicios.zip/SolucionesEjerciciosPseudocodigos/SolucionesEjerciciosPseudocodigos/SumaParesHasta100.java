
public class SumaParesHasta100 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int suma=0;
		for (int i=2; i<=6; i=i+2)
			suma+=i;
		System.out.println("la suma es: "+suma);
	}

}
