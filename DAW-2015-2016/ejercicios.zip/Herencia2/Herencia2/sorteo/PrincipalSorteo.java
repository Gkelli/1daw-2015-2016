package Herencia2.sorteo;

public class PrincipalSorteo {
	
	public static void main(String[] args) {
		
		// Crear un main para instanciar distintos tipos de objetos de clase Dado, Moneda y Carta
		
		
		Dado dado = new Dado();
		Moneda moneda = new Moneda();
		Carta carta = new Carta();
		
		//datos del sorteo
		
		System.out.println("---Datos del Sorteo---");
		System.out.println("DADO. " + dado.ver_datos());		
		System.out.println("MONEDA. "+ moneda.ver_datos());		
		System.out.println("CARTA. "+ carta.ver_datos());		
		
		// vamos a lanzar los diferentes tipos de Sorteo
		
		System.out.println("\n---Lanzar dado---");
		dado.lanzar();
		System.out.println("\n---Lanzar moneda---");
		moneda.lanzar();
		System.out.println("\n---Lanzar carta---");
		carta.lanzar();
	}

}
