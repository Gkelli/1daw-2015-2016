package Herencia2.sorteo;

public abstract class Sorteo {
	
//		Una clase abstracta Sorteo, con un atributo posibilidades que se definir� protected entero 
	
	protected int posibilidad;
	
	public Sorteo(){
		this.posibilidad = 0;
	}
	
	public Sorteo(int posibilidad){
		this.posibilidad = posibilidad;
	}

	public int getPosibilidad() {
		return posibilidad;
	}

	public void setPosibilidad(int posibilidad) {
		this.posibilidad = posibilidad;
	}
	
//  un m�todo abstracto lanzar() 
	
	public abstract void lanzar();
	
//	el m�todo no abstracto probabilidad () que genera un double obtenido al dividir 1 entre el n� de posibilidades
	
	public double probabilidad(){
		return (double) ((1/getPosibilidad()));
	}	
	
//	el m�todo verDatos() que obtenga las posibilidades y la probabilidad del sorteo.
	
	public String ver_datos(){
		return "El sorteo tiene " + getPosibilidad() + " de posibilidad y " + probabilidad() + " de probabilidades";
	}

}
