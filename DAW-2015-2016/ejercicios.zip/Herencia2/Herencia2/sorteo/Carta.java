package Herencia2.sorteo;

public class Carta extends Sorteo{
	
	//	Una clase hija Carta, con dos atributos palo y n�mero 
	private int []numero = {1,2,3,4,5,6,7,8,9,10,11,12,13};
	private String []palo = {"Corazones","Diamantes","Tr�boles","Picas"};
	
	public Carta(){
		super(13);
		
	}

	public String ver_datos() {
		return super.ver_datos()  ;
	}

	
	//  m�todo lanzar() generando aleatoriamente un palo y un n�mero y visualice la carta de forma �As de Picas�. 

	
	public void lanzar() {
		int numero_aux =(int)(Math.random()*12)+1;	
		int palo_aux = (int)(Math.random()*4);	
		
		System.out.println("La carta es: " + numero[numero_aux] + " de " + palo[palo_aux]);
	}
	
}
