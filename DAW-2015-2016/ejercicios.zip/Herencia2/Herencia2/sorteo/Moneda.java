package Herencia2.sorteo;

public class Moneda extends Sorteo{
	
	//	Una clase hija Moneda, que redefinir� el m�todo lanzar() generando aleatoriamente cara o cruz.
	
	public Moneda(){
		super(2);
	}

	public String ver_datos() {
		return super.ver_datos() ;
	}

	public void lanzar() {
		int lance = (int)(Math.random()*2);
		if (lance==0) {
			System.out.println("CARA");
		} else {
			System.out.println("CRUZ");
		}
		
	}

	
}
