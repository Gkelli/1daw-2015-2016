package Herencia2.sorteo;

public class Dado extends Sorteo{
	
	//	Una clase hija Dado, que redefinir� el m�todo lanzar() generando un n� aleatorio entre 1 y 6.
	
	public Dado(){
		super(6);
	}
	
	public String ver_datos() {
		return super.ver_datos() ;
	}

	public void lanzar() {
		int lance = (int)(Math.random()*6)+1;
		System.out.println(lance);
	}
	
	
	
}
