package Herencia2.figuras;

public abstract class Figura {
	
	//clase abstracta que tiene un atributo color, 
	
	protected String color;
	
	public Figura(){}
	
	public Figura(String color){
		this.color = color;
	}
	
	// los m�todos no abstractos setColor, getColor y toString 

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Soy una figura de color " + color+ " . ";
	}
	
	// los m�todos abstractos per�metro y �rea.
	
	public abstract double perimetro();
	
	public abstract double area();

}
