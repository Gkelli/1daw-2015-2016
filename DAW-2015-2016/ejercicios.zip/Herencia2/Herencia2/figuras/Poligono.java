package Herencia2.figuras;

public abstract class Poligono extends Figura{
	
//	clase hija de Figura con un atributos numLados y los m�todos no abstractos setNumLados y getNumLados. 
	
	protected int n_lados;
	
	public Poligono(){}
	
	public Poligono(String color, int n_lados){
		super(color);
		this.n_lados = n_lados;
	}

	public int getN_lados() {
		return n_lados;
	}

	public void setN_lados(int n_lados) {
		this.n_lados = n_lados;
	}

	@Override
	public String toString() {
		return super.toString() + "Adem�s soy un poligono y un";
	}
	
	
//	No implementa los m�todos abstractos per�metro y �rea. Evaluar si debe ser o no abstracta.
	
	

}
