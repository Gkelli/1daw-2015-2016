package Herencia2.empleados;

public class EmpleadoFijos extends Empleado{
	
	// empleados fijos de los que se almacenar� su salario al mes  
	
	private double salario_mes;
	
	public EmpleadoFijos(){}
	
	public EmpleadoFijos(String nombre, String dni, int telefono, double salario_mes){
		super(nombre, dni, telefono);
		this.salario_mes = salario_mes;
	}

	public double getSalario_mes() {
		return salario_mes;
	}

	public void setSalario_mes(double salario_mes) {
		this.salario_mes = salario_mes;
	}
	
	@Override
	public String toString() {
		return super.toString() + " EmpleadoFijos [salario_mes=" + salario_mes + "]";
	}

	//un m�todo para consultar el salario al mes de un empleado 
	
	public double calcular_salario() {
		return getSalario_mes();		
	}
}
