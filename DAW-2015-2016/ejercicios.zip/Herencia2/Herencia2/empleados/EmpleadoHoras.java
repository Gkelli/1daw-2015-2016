package Herencia2.empleados;

public class EmpleadoHoras extends Empleado {

	//empleados por horas de los que se almacenar� el numero de horas que trabajan y el salario que ganan por hora.
	
	private int n_horas;
	private double salario_hora;
	
	public EmpleadoHoras(){}
	
	public EmpleadoHoras(String nombre, String dni, int telefono, int n_horas, double salario_hora){
		super(nombre, dni, telefono);
		this.n_horas = n_horas;
		this.salario_hora = salario_hora;
	}
	
	public int getN_horas() {
		return n_horas;
	}

	public void setN_horas(int n_horas) {
		this.n_horas = n_horas;
	}

	public double getSalario_hora() {
		return salario_hora;
	}

	public void setSalario_hora(double salario_hora) {
		this.salario_hora = salario_hora;
	}
	
	@Override
	public String toString() {
		return super.toString() + " EmpleadoHoras [n_horas=" + n_horas + ", salario_hora="
				+ salario_hora + "]";
	}
	
	//un m�todo para consultar el salario al mes de un empleado 
	
	public double calcular_salario() {		
		return getSalario_hora() * getN_horas();
	}
}
