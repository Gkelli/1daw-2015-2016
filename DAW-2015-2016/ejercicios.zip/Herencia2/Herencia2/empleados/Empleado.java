package Herencia2.empleados;

public abstract class Empleado {
	
	// De cada  empleado se dispondr� de: el nombre, el dni y su tel�fono. 
	
	protected String nombre;
	protected String dni;
	protected int telefono;
	
	public Empleado(){}

	public Empleado(String nombre, String dni, int telefono) {
		this.nombre = nombre;
		this.dni = dni;
		this.telefono = telefono;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", dni=" + dni + ", telefono="
				+ telefono + "]";
	}
	
	public abstract double calcular_salario();
	
	
	
	
}
