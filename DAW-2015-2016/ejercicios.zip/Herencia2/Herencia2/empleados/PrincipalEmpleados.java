package Herencia2.empleados;

public class PrincipalEmpleados {

	public static void main(String[] args) {

//		a.	Cree un array de Empleados (se creara 5 empleados para probar las clases)
			
		Empleado[] lista_empleados = new Empleado[5];
		
//		b.	Cree varios empleados tanto fijos como por horas
	
		EmpleadoFijos emp1 = new EmpleadoFijos("Empleado 1", "DNI1", 63636366, 1000);
		EmpleadoFijos emp2 = new EmpleadoFijos("Empleado 2", "DNI2", 63632222, 1500);
		EmpleadoHoras emp3 = new EmpleadoHoras("Empleado 3", "DNI3", 963258741, 5, 12);
		EmpleadoHoras emp4 = new EmpleadoHoras("Empleado 4", "DNI4", 963257944, 13, 9);
		EmpleadoHoras emp5 = new EmpleadoHoras("Empleado 5", "DNI5", 963255555, 43, 8);
		
//		c.	Almacene los empleados creados en el array
		
		lista_empleados[0]= emp1 ;
		lista_empleados[1]= emp2 ;
		lista_empleados[2]= emp3 ;
		lista_empleados[3]= emp4 ;
		lista_empleados[4]= emp5 ;		
		
//		d.	Recorra el array mostrando por pantalla  el sueldo de cada uno de los empleados creados.  
		
		System.out.println("---Lista de Empleados con sus respectivos salarios:---");
		for (int i = 0; i < lista_empleados.length; i++) {
			System.out.println(lista_empleados[i].getNombre() + " tiene el salario: " +  lista_empleados[i].calcular_salario());
		}


	}

}
