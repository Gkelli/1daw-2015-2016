
public interface IRecordStack {
	
	public void insertarDisco(Record disco);
	public Record sacarDisco ();
	public void imprimirPila();

}
