


/**
 * Clase que implementa una lista doble enlazada usando dos  nodos centinelas que apuntan al primer y �ltimo nodo. 
 * Un centinela es un nodo especial, que no tiene un valor asociado (item), 
 * y que sirven para facilitar la programaci�n. 
 * El centinela header con su referencia next apunta al primer elemento de la lista. Su referencia prev es null
 * El centinela tailer con su referencia prev apunta al �ltimo elemento de la lista.  Su referencia next es null
 */
public class DList<E> implements IDList<E>{
	/**Nodo centinela cuyo propiedad next apunta al primer nodo de la lista*/
	public DNode<E> header;
	/**Nodo centinela cuyo propiedad prev apunta al último nodo de la lista*/
	public DNode<E> tailer;
	public  int size;
	
	/** Crea una lista vac�a. Para ello inicializa los dos nodos centinelas	 */
	public DList() {
		header=new DNode<E>();
		tailer=new DNode<E>();
		//Se apuntan el uno al otro
		header.next=tailer;
		tailer.prev=header;
		size=0;
	}
	
	/** Devuelve true si la lista está vacía, false en otro caso.	 * @return
	 */
	public boolean isEmpty() {
		return (size==0);
	}
	
	/**
	 * devuelva el nodo que contiene el elemento es. Complejidad O(n)
	 * @param v
	 */
	public DNode<E> search(E e) {
		if (e==null) {
			System.out.println("No se puede buscar null");
			return null;
		}
		DNode<E> aux=header;
		while (aux!=tailer && aux.element!=e) {
			aux=aux.next;
		}
		if (aux==tailer){
		System.out.println("no existe...");
		return null;
		}else{
		return aux;
		}
	}

	/**
	 * ESte método inserta el nodo newNodo al principio de la lista.
	 * Complejidad O(1), porque el método ejecuta un número constante de instrucciones.
	 * @param newNodo
	 */
	public  void addFirst(DNode<E> newNodo) {
		if (newNodo==null) {
			System.out.println("El nodo es nulo, no podemos insertarlo!!!");
			return; //salimos del método
		}
		
		DNode<E> v=header.next;
		//El nuevo nodo deberá apuntar al primer nodo de la lista
		newNodo.next=v;
		v.prev=newNodo;
		//Ahora hacemos que el primer nodo sea newNodo
		header.next=newNodo;
		newNodo.prev=header;
		
		//Incrementamos el tamaño de la lista
		size++;
		
	}
	
	/**
	 * ESte método inserta el nodo newNodo al final de la lista.
	 * Complejidad O(1), porque el método ejecuta un número constante de instrucciones.
	 * @param newNodo
	 */
	public  void addLast(DNode<E> newNodo) {
		if (newNodo==null) {
			System.out.println("El nodo es nulo, no podemos insertarlo!!!");
			return; //salimos del método
		}
		
		DNode<E> v=tailer.prev;
		v.next=newNodo;
		newNodo.prev=v;
		newNodo.next=tailer;
		tailer.prev=newNodo;
		
		//Incrementamos el tamaño de la lista
		size++;
		
	}
	
	
	/**
	 * Inserta después del nodo v. Complejidad O(1)
	 * @param v
	 * @param newNodo
	 */
	public void addAfter(E e, E n) {
	DNode<E> v = search(e);
	DNode<E> newNodo = new DNode<E>(n);
	if (v!=null){
	DNode<E> u = v.next;
	newNodo.prev=v;
	newNodo.next=u;
	v.next=newNodo;
	u.prev=newNodo;
	size++;
	}
	}
	
	/**
	 * Inserta antes del nodo v. Complejidad O(1)
	 * @param v
	 * @param newNodo
	 */
	public void addBefore(E e, E n) {
		DNode<E> v = search(e);
		DNode<E> newNodo = new DNode<E>(n);
		if(v!=null){ 
			DNode<E> u=v.prev;
			newNodo.prev=u;
			newNodo.next=v;
			u.next=newNodo;
			v.prev=newNodo;
			size++;
		}
	}
	
	/**
	 * Borra el primer elemento de la lista. Complejidad O(1).
	 */
	public void removeFirst() {
		if (isEmpty()) {
			System.out.println("La lista ya está vacia!!!");
			return; //salimos del método
		}
		
		DNode<E> v = header.next;
		DNode<E> u = v.next;
		//primerNodo debe pasar a ser el siguiente nodo. 
		header.next = u;
		u.prev=header;
		size--;
	}

	/**
	 * Borra el último nodo de la lista. Complejidad O(1).
	 */
	public void removeLast() {
		if (isEmpty()) {
			System.out.println("La lista ya está vacia!!!");
			return; //salimos del método
		}
		
		DNode<E> v=tailer.prev;
		DNode<E> u=v.prev;
		tailer.prev=u;
		u.next=tailer;
		size--;
	}

	/**
	 * remove el nodo v. O(1)
	 * @param v
	 */
	public void remove(E e) {
		DNode<E> v= search(e);
		if (v!=null){
		DNode<E> uA=v.prev;
		DNode<E> uD=v.next;
		uD.prev=uA;
		uA.next=uD;
		size--;
		}
	}

	/**
	 * remove todos los nodos que contienen el elemento e. O(n)
	 * @param v
	 */
	public void removeAll(E e) {
		DNode<E> aux=header.next;
		while (aux!=tailer) {
		if (aux.element==e){
			DNode<E> ant=aux.prev;
			DNode<E> des=aux.next;
			des.prev=ant;
			ant.next=des;
			size--;
		}
			aux=aux.next;
		}

	}

	/**Recorre los elementos de la lista y los muestra. Complejidad O(n)*/
	public void show() {
		DNode<E> u=header.next;
		while (u!=tailer) {
			System.out.print(u.element + ",");
			u=u.next;
		}
		System.out.println();
	}

	/**
	 * El método main nos permite crear una lista
	 * @param args
	 */
	public static void main(String args[]) {
		DList<Integer> lista=new DList<Integer>();
		//Vamos a guardar 10 elementos
		for (int i=0; i<=9; i++) {
			//Creamos un nodo con el valor i, y que su next sea null 
			DNode<Integer> newNodo=new DNode<Integer>(i); //También podría insertar un numero aleatorio (rnd.getInt());
			lista.addFirst(newNodo);
		}
		for (int i=0; i<=9; i++) {
			//Creamos un nodo con el valor i, y que su next sea null 
			DNode<Integer> newNodo=new DNode<Integer>(i); //También podría insertar un numero aleatorio (rnd.getInt());
			lista.addFirst(newNodo);
		}

		lista.show();
		lista.addBefore(3, 11);
		lista.remove(8);
		lista.show();
		lista.removeAll(0);
		lista.show();

		}



}
