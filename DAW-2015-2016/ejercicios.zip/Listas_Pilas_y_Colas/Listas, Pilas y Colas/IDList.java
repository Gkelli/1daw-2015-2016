

public interface IDList<E> {

	public boolean isEmpty() ;
	
	public  void addFirst(DNode<E> newNodo) ;
	
	public  void addLast(DNode<E> newNodo) ;
	
	public void addAfter(E e, E n) ;
	
	public void addBefore(E e, E n) ;

	public void removeFirst() ;

	public void removeLast() ;

	public void remove(E e) ;

}
