
public class Stack<E> implements IStack<E>{

	public SNode<E> head;
	public int size;
	
	public Stack() {
		head = null;
		size=0;
	}
	
	public void push(E obj) {
		SNode<E> nodo = new SNode<E>(obj);
		nodo.next = head;
		head = nodo;
		size++;
	}

	public E pop() {
		if (head == null) {
			return null;
		} else {
			E borrado = head.element;
			head = head.next;
			size--;
			return borrado;
		}
	}

	public E top() { // top
		return head.element;
	}

	public boolean isEmpty() {
		return head == null;
	}

	public void show() {
		SNode<E> actual = head;
		while (actual != null) {
			System.out.println(actual.element);
			actual = actual.next;
		}
		System.out.println("====================");
	}
	
	public void removeIteAll() {
		while (!isEmpty()) pop();
	}
	
	public void removeRecAll() {
		if (isEmpty()) System.out.println("The stack is empty");
		else {
			pop();
			removeRecAll();
		}
	}

	public String toString() {
		String salida="";
		if (isEmpty()){
			System.out.println("La pila est� vacia");
			return salida;
		}
		else {
			SNode<E> actual = head;
			
			while (actual != null) {

				salida+=actual.element.toString() + "\n";
				actual = actual.next;
			}
			return salida;

		}
	}
	public static void main(String[] args) {
		Stack<String> pila = new Stack<String>();
		pila.push("Hola");
		pila.push("Buenos d�as");
		pila.show();
		System.out.println("size: "+pila.size);
		System.out.println("top: "+pila.top());
		pila.push("Adi�s");
		pila.removeRecAll();
		System.out.println("�Pila vac�a: ?"+pila.isEmpty());
	}
}
