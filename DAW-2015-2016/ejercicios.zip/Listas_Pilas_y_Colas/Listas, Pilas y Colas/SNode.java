/**
 * <E> quiere decir que puede guardar cualquier objeto de tipo/clase E.
 * 
 * @param <E>
 */
public class SNode<E> {
	 E element;
	 SNode<E> next;
	
	public SNode(){
		element=null;
		next=null;
	}	
	public SNode(E obj, SNode<E> n){
		element=obj;
		next=n;
	}
	public SNode(E obj){
		element=obj;
		next=null;
	}	
	public E getElement(){
		return element;
	}	
	public SNode<E> getNext(){
		return next;
	}	
	public void setElement( E element){
		this.element=element;
	}	
	public void setNext (SNode <E> node){
		this.next=node;
	}	
	public void verSNode(){
		System.out.println(element.toString());
	}
	
	
}
