package ejercicioInterfazOrdenable;

public interface Ordenable 
{
		boolean esMenor(Ordenable o);
		boolean esMayor (Ordenable o);
}
