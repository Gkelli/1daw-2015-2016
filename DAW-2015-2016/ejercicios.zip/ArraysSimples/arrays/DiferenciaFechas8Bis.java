package arrays;

public class DiferenciaFechas8Bis {

	public static void main(String[] args) {
		
		int anno1, anno2, mes1, mes2, dia1, dia2, diasFebrero, diasMax;
		
		
		//versi�n completa: se introduce tambi�n el a�o, se eval�a si es bisiesto y se calculan los d�as entre las dos fechas
		System.out.println("Introduce el primer a�o");
		anno1=LeerTeclado.readInteger();	
		
		diasFebrero=bisiesto(anno1); //pone en diasFebrero 28 o 29 d�as seg�n el a�o1 sea o no bisiesto
		
		//inicializamos los arrays
		String[] meses= {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
		int[] dias={31,diasFebrero,31,30,31,30,31,31,30,31,30,31};
		//pongo en el array en la posici�n 1 (febrero) el valor que tenga la variable diasFebrero que acabo de obtener
		//Tambi�n podr�a haber hecho:
		//int[] dias={31,bisiesto(anno1),31,30,31,30,31,31,30,31,30,31};
		
		do{
			System.out.println("Introduce el primer mes (entre 1 y 12)");
			 mes1=LeerTeclado.readInteger();
		} while (!(mes1>=1 && mes1<=12)); //valido que el mes est� entre 1 y 12
		
		do{
			System.out.println("Introduce el primer d�a (entre 1 y "+dias[mes1-1]+")");
			dia1=LeerTeclado.readInteger();
		}		
		while (!(dia1>=1 && dia1<=dias[mes1-1])); 
		//valido que el d�a est� entre 1 y el n�mero de d�as del mes
		//hay que tener en cuenta, que el mes 1 (enero) en el array est� en la posici�n 0, etc., 
		//por eso la posici�n es mes-1
		
		
		//datos del segundo a�o
		//valido que que el anno2 sea mayor o igual que el anno1; si no es as� se vuelve a pedir anno2
		
		do{
			System.out.println("Introduce el segundo a�o. No puede ser menor que "+anno1);
			anno2=LeerTeclado.readInteger();
		}
		while (anno2<anno1); 
		
		//pedimos el 2� mes: si el a�o  no es el mismo, se valida que mes2>=1 y mes2<=12
		//si el a�o es el mismo, validamos que el mes2>=mes1 y mes2<=12
		//podemos usar una variable mesAux que se iniciliza en 1 o en mes2 seg�n sean los a�os
		
	
		int mesAux, diaAux;
		if (anno1==anno2)
			mesAux=mes1;
		else mesAux=1;
		do{
			System.out.println("Introduce el segundo mes (entre "+mesAux+" y 12)");
			mes2=LeerTeclado.readInteger();
		}
		while (!(mes2>=mesAux && mes2<=12));
		
		//uso una variable diasMax para guardar los d�as m�ximos que tiene el mes2, seg�n si anno2 es bisiesto
		if (mes2==2) //si es febrero,  eval�a si el segundo a�o es bisiesto para poner en diasMax 28 o 29 
			diasMax=bisiesto(anno2);
		else
			diasMax=dias[mes2-1];
		
		//pedimos el 2� dia: si el a�o o mes no es el mismo, se valida que dia2>=1 y dia2<=diasMax
		//si el a�o y el mes es el mismo, validamos que el dia2>=dia1 y dia2<=diasMax 
		//Usamos una variable diaAux que se inicializa en dia1 o en 1 respectivamente 
		if (anno1==anno2 && mes1==mes2)
			diaAux=dia1; 
		else {
			diaAux=1;
		}
		
		do{
			System.out.println("Introduce el primer d�a (entre "+(diaAux)+" y "+diasMax+")");
			dia2=LeerTeclado.readInteger();
		}		
		while (!(dia2>=diaAux && dia2<=diasMax)); 
		
		//calculamos los d�as transcurridos entre ambas fechas, sumando 1 a dia1 y visualizando las fechas
		while((mes1<mes2) || dia1 <= dia2 || anno1<anno2){
						
			if(dia1>dias[mes1-1]){ 
				//si al sumar 1 al d�a, me paso del n�mero de d�as del mes correspondiente, 
				//sumo 1 al mes y pongo el d�a en 1
				mes1++;
				dia1=1;
			}
			
			if(mes1>12){ //si al sumar 1 al mes, me paso de 12, pongo el mes en 1 y sumo 1 al a�o
				mes1=1;
				anno1++;
				dias[1]=bisiesto(anno1); 
				//vuelvo a calcular los dias de febrero por si al avanzar el a�o encuentra un bisiesto, 
			}
			System.out.println("Dia " + dia1 + " " + meses[mes1-1]+" de " +anno1);
			dia1++;
		}
	}
	
	//m�todo que devuelve 28 o 29 d�as seg�n si el a�o es o no bisiesto
	public static int  bisiesto (int anno){
		int dias;
		if ((anno%4==0) && ((anno%100!=0) || (anno%400==0)))
			dias=29; //si el anno es bisiesto devuelve 29
		else 
			dias=28;
		
		return dias;
	}
	

	}


