package arrays;

public class Notas3 {

	public static void main(String[] args) {

		int[] notas=new int[10];
		int n,i;
				
		System.out.println("introduce un n�mero entre 0 y 10");
		n=LeerTeclado.readInteger();
		
		
		while (n>=0 && n<11){
			notas[n]++;
			System.out.println("introduce un n�mero entre 0 y 10");
			n=LeerTeclado.readInteger();
			
		}
		
		for(i=0;i<notas.length; i++){
			if (notas[i]!=00)
				System.out.println("La nota "+i+" se repite "+notas[i]+" veces");
		}

	}

}
