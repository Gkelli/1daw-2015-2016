package Herencia3;

public class Llamada {	
	
	/** Considero que habra m�s tipos de llamadas (que no sean ni local ni provincipal), con su tarifa correspondiente.
	 * Si quisiera que fuera solo dos, crearia esa como una clase abstracta*/
	
	//Todas las llamadas tienen como datos el n�mero origen de la llamada, el n�mero de destino y su duraci�n en segundos.
	
	protected String n_origen;
	protected String n_destino;
	protected long duracion;
	protected double coste_segundo;
	
	public Llamada(){}
	
	public Llamada(double coste_segundo, String n_origen, String n_destino, long duracion) {
		this.n_origen = n_origen;
		this.n_destino = n_destino;
		this.duracion = duracion;
		this.coste_segundo = coste_segundo;
	}

	public String getN_origen() {
		return n_origen;
	}

	public void setN_origen(String n_origen) {
		this.n_origen = n_origen;
	}

	public String getN_destino() {
		return n_destino;
	}

	public void setN_destino(String n_destino) {
		this.n_destino = n_destino;
	}

	public long getDuracion() {
		return duracion;
	}

	public void setDuracion(long duracion) {
		this.duracion = duracion;
	}

	public double getCoste_segundo() {
		return coste_segundo;
	}

	public void setCoste_segundo(double coste_segundo) {
		this.coste_segundo = coste_segundo;
	}

	public String toString() {
		return "[n�mero de origen=" + n_origen + ", n�mero de destino=" + n_destino+ ", duracion=" + duracion;
	}
	
	public double precio_llamada(){
        return this.coste_segundo * getDuracion();
	}

}
