package Herencia3;

import java.util.ArrayList;

public class Centralita {
	
//	En la clase centralita se van registrando llamadas. El objeto de registrar una llamada en la centralita es poder contabilizar el número de llamadas, 
//	así como el coste total de todas las llamadas realizadas en la misma. 
//	La centralita podrá mostrar por pantalla cada llamada registrada.
	
	
	/**He considerado usar la clase ArrayList para crear una lista de llamadas, ya que de antemano no conoceremos el numero exacto de 
	 * llamadas que recibirá la Centralita. Considerando que con una lista de ArrayList no necesito inicializarlo con un tamaño fijo.*/
	private ArrayList<Llamada> lista_llamadas;
	private long cantidad_llamadas;
	
	public Centralita(){
		this.cantidad_llamadas = 0;
		lista_llamadas = new ArrayList<Llamada>();
	}
	
	public ArrayList<Llamada> getLista_llamadas() {
        return lista_llamadas;
    }
 
    public void setLista_llamadas(ArrayList<Llamada> lista_llamadas) {
        this.lista_llamadas = lista_llamadas;
    }
		  
    public void registrar_llamada(Llamada llamada){
        lista_llamadas.add(llamada);
    }
     
    public long total_llamadas(){
        return + lista_llamadas.size();
    }
	
	public void llamadas_centralita(){
		for (int i = 0; i < lista_llamadas.size(); i++) {
			System.out.println("Coste de la llamada " + (i+1) + " : " + redondear_precio(lista_llamadas.get(i).precio_llamada(), 2) + " euros");
            System.out.println(lista_llamadas.get(i).toString());
		}
	}
		
	//metodo para redondear el coste de las llamadas, que le pasas como atributo una cantidad, y la cantidad de decimales que quieres devolver
	public double redondear_precio(double num, int dec) {
		double factor = (long) Math.pow(10, dec);
		num *=  factor;
		double tmp = Math.round(num);
		return (double) tmp / factor;
	}
	
	public void factura_total_llamadas() {
		double factura = 0;
		for (int i = 0; i < lista_llamadas.size(); i++) {
			factura += lista_llamadas.get(i).precio_llamada();
		}
		System.out.println("\nFACTURA CENTRALITA . El importe total de la factura : "	+ redondear_precio(factura, 2) + " euros");
	}

	@Override
	public String toString() {
		return "Centralita [lista de llamadas=" + lista_llamadas
				+ ", cantidad_llamadas=" + cantidad_llamadas + "]";
	}
		
}
