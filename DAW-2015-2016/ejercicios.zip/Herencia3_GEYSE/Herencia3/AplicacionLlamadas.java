package Herencia3;

public class AplicacionLlamadas {
	
	// clase que en su m�todo main cree una centralita, registre varias llamadas de distinto tipo y
	// le pida a la centralita un informe con el n�mero total de llamadas y la facturaci�n total realizada.
	
	public static void main(String[] args) {
		
		Centralita centralita = new Centralita();
		//creo llamadas para probar la centralita
		LlamadaLocal local1 = new LlamadaLocal("963258741", "987456321", 32);
		LlamadaLocal local2 = new LlamadaLocal("632587194", "921354899", 125);
		LlamadaLocal local3 = new LlamadaLocal("985632147", "639852147", 15);
		LlamadaLocal local4 = new LlamadaLocal("987456333", "698547123", 450);
		LlamadaLocal local5 = new LlamadaLocal("666988932", "999966636", 258);
		LlamadaProvincial prov1 = new LlamadaProvincial("951236874", "632598741", 123, 1);
		LlamadaProvincial prov2 = new LlamadaProvincial("365214665", "789654123", 36, 1);
		LlamadaProvincial prov3 = new LlamadaProvincial("741258963", "999874563", 5, 2);
		LlamadaProvincial prov4 = new LlamadaProvincial("996688552", "778996554", 95, 2);
		LlamadaProvincial prov5 = new LlamadaProvincial("663322541", "777999555", 266, 3);
		LlamadaProvincial prov6 = new LlamadaProvincial("963963963", "654654654", 1254, 3);
		LlamadaProvincial prov7= new LlamadaProvincial("632632632", "748748748", 669, 3);
		
		// registramos las llamadas recibidas en la centralita
		
		centralita.registrar_llamada(local1);centralita.registrar_llamada(local2);centralita.registrar_llamada(local3);
		centralita.registrar_llamada(local4);centralita.registrar_llamada(local5);
		centralita.registrar_llamada(prov1);centralita.registrar_llamada(prov2);centralita.registrar_llamada(prov3);
		centralita.registrar_llamada(prov4);centralita.registrar_llamada(prov5);centralita.registrar_llamada(prov6);centralita.registrar_llamada(prov7);
		
		//se realiza un informe con el total de llamadas registradas en la centralita
	    System.out.println("--INFORME DE LLAMADAS REGISTRADAS en la centralita---\n");
	    System.out.println("Se han registrado " + centralita.total_llamadas() + " en la centralita\n");
	     
	    //todas las llamadas registadas en la centralita
	    centralita.llamadas_centralita();
	    
	    //factura de la centralita
	    centralita.factura_total_llamadas();
		

	}

}
