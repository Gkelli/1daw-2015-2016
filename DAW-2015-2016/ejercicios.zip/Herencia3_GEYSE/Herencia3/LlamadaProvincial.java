package Herencia3;

public class LlamadaProvincial extends Llamada{
	
	//-	Llamadas provinciales que dependiendo de la franja horaria en la que se realicen cuestan:
	//20 c�ntimos en franja1, 25 c�ntimos en franja 2, y 30 c�ntimos en franja 3, cada segundo.
	
	private int franja_horaria;
	
	public LlamadaProvincial(String n_origen, String n_destino, long duracion, int franja_horaria) {    
        super(0, n_origen, n_destino, duracion);        
        this.franja_horaria = franja_horaria;
		// (falta)se debe validar que las franjas horarias est�n entre 1 y 3
		if (franja_horaria == 1) {
			coste_segundo = 0.20;
		} else if (franja_horaria == 2)
			coste_segundo = 0.25;
		else if (franja_horaria == 3)
			coste_segundo = 0.30;
		else
			System.out.println("Error de franja");
    
	}
     
    public int getFranja_horaria() {
		return franja_horaria;
	}

	public void setFranja_horaria(int franja_horaria) {
		this.franja_horaria = franja_horaria;
	}

	public String toString() {
        return "Tipo de llamada : 'PROVINCIAL' " + super.toString() + ", coste por segundo " + coste_segundo + "]" ;
    }
}
