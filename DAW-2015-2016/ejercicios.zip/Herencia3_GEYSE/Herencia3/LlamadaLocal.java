package Herencia3;

public class LlamadaLocal extends Llamada{
	
	//-	Llamadas locales que cuestan 15 c�ntimos el segundo.
	

	public LlamadaLocal(String n_origen, String n_destino, long duracion) {
		super(0.15, n_origen, n_destino, duracion);
	}

	public String toString() {
		return "Tipo de llamada : 'LOCAL' " + super.toString() + ", coste por segundo " + coste_segundo + "]" ;
	}	
	
}
