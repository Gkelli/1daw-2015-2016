package EJEMPLOS.ejemploComparator;
import java.util.Comparator;

//Se ordena por c�digo. En �rden natural.
//Se debe crear la clase, implementando la interfaz Comparator y su m�todo compare().

public class OrdenCodigo implements Comparator<Ejemplo>{
	public int compare(Ejemplo arg0, Ejemplo arg1) {
		//Ordenar por int//
		return arg0.getAtributo2()-arg1.getAtributo2();
	}

}
