package EJEMPLOS.ejemploComparator;

//El interfaz Comparator no se implementa en la clase Objeto(Ejemplo).
//Se deben crear tantas clases como criterios de ordenaci�n queramos.

public class Ejemplo{
	private String atributo1;
	private int atributo2;
	
	public Ejemplo(){
		
	}
	public Ejemplo(String atributo1, int atributo2) {
		this.atributo1 = atributo1;
		this.atributo2 = atributo2;
	}
	
	public String getAtributo1() {
		return atributo1;
	}
	public void setAtributo1(String atributo1) {
		this.atributo1 = atributo1;
	}
	public int getAtributo2() {
		return atributo2;
	}
	public void setAtributo2(int atributo2) {
		this.atributo2 = atributo2;
	}
	
	@Override
	public String toString() {
		return "EjemploComparator [atributo1=" + atributo1 + ", atributo2="
				+ atributo2 + "]";
	}
	

	

	
	
	

}
