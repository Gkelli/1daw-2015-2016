package EJEMPLOS.ejemploComparator;
import java.util.Arrays;
import java.util.Collections;
import java.util.Vector;


public class Principal {

	public static void main(String[] args) {
		//ARRAYS DE OBJETOS//
		Ejemplo[] arrayEj=new Ejemplo[5];
		
		Ejemplo ej1=new Ejemplo("Juan", 6);
		Ejemplo ej2=new Ejemplo("Alvaro", 2);
		Ejemplo ej3=new Ejemplo("Pepe", 9);
		Ejemplo ej4=new Ejemplo("Zaida", 4);
		Ejemplo ej5=new Ejemplo("Jose", 10);

		arrayEj[0]=ej1;
		arrayEj[1]=ej2;
		arrayEj[2]=ej3;
		arrayEj[3]=ej4;
		arrayEj[4]=ej5;
		
		for(int i=0; i<arrayEj.length; i++)
			System.out.println(arrayEj[i].toString());
		System.out.println("------------------------------------");
		
		//El m�todo sort llamar� al m�todo compare() definido en la clase del objeto pasado como par�metro (OrdenCodigo).
		//Para los tipos primitivos, hace lo mismo, por ello no hace falta implementar la interfaz.
		//Los atributos son: (ObjetoParaOrdenar, ObjetoCriterioOrdenacion)
		//										new Objeto
		Arrays.sort(arrayEj, new OrdenCodigo());
		
		for(int i=0; i<arrayEj.length; i++)
			System.out.println(arrayEj[i].toString());
		System.out.println("------------------------------------");
		
		
		OrdenString ordenString=new OrdenString();
		Arrays.sort(arrayEj, ordenString);
		
		for(int i=0; i<arrayEj.length; i++)
			System.out.println(arrayEj[i].toString());
		System.out.println("------------------------------------");
		
		//VECTORES//
		Vector<Ejemplo> vectorEj=new Vector<Ejemplo>();
		vectorEj.add(ej1);
		vectorEj.add(ej2);
		vectorEj.add(ej3);
		vectorEj.add(ej4);
		vectorEj.add(ej5);
		System.out.println(vectorEj.toString());
		//Para hacer la llamada al m�todo sort() de Vectores, ArrayList y List
		//se utiliza Collections.sort().
		Collections.sort(vectorEj, new OrdenCodigo());
		System.out.println(vectorEj.toString());
		
		//ARRAYLIST Tambi�n funciona//
	}

}
