package EJEMPLOS.ejemploComparator;
import java.util.Comparator;

//Se ordena por String. En �rden natural.
//Se debe crear la clase, implementando la interfaz Comparator y su m�todo compare().

public class OrdenString implements Comparator<Ejemplo>{
	public int compare(Ejemplo arg0, Ejemplo arg1) {
			return arg0.getAtributo1().compareTo(arg1.getAtributo1());
		}
	

}
