package EJEMPLOS.ejemploComparable;

//El interfaz Comparable es m�s sencillo pero s�lo permite comparar por un �nico atributo, 
//el que est� definido en la clase Objeto(Ejemplo).

public class Ejemplo implements Comparable<Ejemplo>{
	private String atributo1;
	private int atributo2;
	
	public Ejemplo(){
		
	}
	public Ejemplo(String atributo1, int atributo2) {
		this.atributo1 = atributo1;
		this.atributo2 = atributo2;
	}
	
	public String getAtributo1() {
		return atributo1;
	}
	public void setAtributo1(String atributo1) {
		this.atributo1 = atributo1;
	}
	public int getAtributo2() {
		return atributo2;
	}
	public void setAtributo2(int atributo2) {
		this.atributo2 = atributo2;
	}
	
	
	////Implementaci�n m�todo compareTo()////
	
	public int compareTo(Ejemplo arg0) {
		//Compara los Strings//
		return this.atributo1.compareTo(arg0.atributo1);
	}
	/*
	public int compareTo(Ejemplo arg0) {
		//Compara los int//
	return this.atributo2-arg0.atributo2);
	}
	*/
	
	@Override
	public String toString() {
		return "Ejemplo [atributo1=" + atributo1 + ", atributo2=" + atributo2
				+ "]";
	}
	
	
	

}
