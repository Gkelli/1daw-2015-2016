package EJEMPLOS.ejemploComparable;
import java.util.Arrays;
import java.util.Collections;
import java.util.Vector;
public class Principal {
	
	public static void main(String[] args){
		//ARRAYS DE OBJETOS//
		Ejemplo[] arrayEJ=new Ejemplo[5];
		Ejemplo ej1=new Ejemplo("Juan", 6);
		Ejemplo ej2=new Ejemplo("Alvaro", 2);
		Ejemplo ej3=new Ejemplo("Pepe", 9);
		Ejemplo ej4=new Ejemplo("Zaida", 4);
		Ejemplo ej5=new Ejemplo("Jose", 10);
		
		arrayEJ[0]=ej1;
		arrayEJ[1]=ej2;
		arrayEJ[2]=ej3;
		arrayEJ[3]=ej4;
		arrayEJ[4]=ej5;
		
		//El m�todo sort llamar� al m�todo compareTo() definido en la clase Objeto(Ejemplo).
		//Para los tipos primitivos, hace lo mismo, por ello no hace falta implementar la interfaz.
		Arrays.sort(arrayEJ);
		
		for(int i=0; i<arrayEJ.length; i++)
			System.out.println(arrayEJ[i].toString());
		
		
		//VECTORES//
		Vector<Ejemplo> vectorEj=new Vector<Ejemplo>();
		vectorEj.add(ej1);
		vectorEj.add(ej2);
		vectorEj.add(ej3);
		vectorEj.add(ej4);
		vectorEj.add(ej5);
		System.out.println(vectorEj.toString());
		//Para hacer la llamada al m�todo sort() de Vectores, ArrayList y List
		//se utiliza Collections.sort().
		Collections.sort(vectorEj);
		System.out.println(vectorEj.toString());
		
		//ARRAYLIST Tambi�n funciona//
	}

}
