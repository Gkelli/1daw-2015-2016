package objetosOrdenables;

public interface Ordenable {
	
	public boolean esMayor(Ordenable o);
	public boolean esMenor (Ordenable o);

}
