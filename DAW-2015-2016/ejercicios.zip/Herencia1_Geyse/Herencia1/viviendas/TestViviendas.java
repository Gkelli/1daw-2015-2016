package Herencia1.viviendas;

public class TestViviendas {

	public static void main(String[] args) {
		
//		c.	Crear 1 vivienda, 2 chalets y 1 palacio.
		
		Vivienda vivienda = new Vivienda(150, "Calle de la alegria", 123);
		
		Chalet chalet1 = new Chalet( "Calle de la paz", 23, true);
		Chalet chalet2 = new Chalet( "Calle de la cordura", 99, false);
		
		Palacio palacio = new Palacio(900, "Calle de la riqueza", 10, 22);
		
//		d.	Crear un array de 4 posiciones al que  se le asignar�n los objetos anteriores.
		
		Vivienda[] lista = new Vivienda[4];	
		lista[0]=vivienda;
		lista[1]=chalet1;
		lista[2]=chalet2;
		lista[3]=palacio;
		
//		e.	Recorrer el array y mostrar cada uno de los objetos por pantalla
		
		System.out.println("La lista de vivienda es: ");
		for (int i = 0; i < lista.length; i++) {
			System.out.println(lista[i]);
		}
		
//		f.	Recorrer el array y contar cu�ntos chalets hay imprimiendo el resultado.
		
		System.out.println("\n�Cu�ntos chalets hay?");
		int contador=0;
		for (int i = 0; i < lista.length; i++) {
			if (lista[i] instanceof Chalet) {
				contador++;
			}
		}
		System.out.println(contador);

	}

}
