package Herencia1.viviendas;

public class Vivienda {
//	1)	Crea la clase Vivienda con los siguientes atributos: metros cuadrados, calle, n�mero. 
	
	protected double m_cuadrados;
	protected String calle;
	protected int numero;
	
	public Vivienda(){}
	
	public Vivienda(double m_cuadrados, String calle, int numero) {
		this.m_cuadrados = m_cuadrados;
		this.calle = calle;
		this.numero = numero;
	}

	public double getM_cuadrados() {
		return m_cuadrados;
	}

	public void setM_cuadrados(double m_cuadrados) {
		this.m_cuadrados = m_cuadrados;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		return "Vivienda [metros cuadrados=" + m_cuadrados + ", calle=" + calle
				+ ", numero=" + numero + "]";
	}
	
}
