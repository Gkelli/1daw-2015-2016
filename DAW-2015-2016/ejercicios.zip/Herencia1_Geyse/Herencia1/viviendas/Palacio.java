package Herencia1.viviendas;

public class Palacio extends Vivienda{
	
//	3)	Crea la clase Palacio: Es una vivienda con n�mero de habitaciones 
	
	private int n_habitaciones;

	public Palacio() {
	}

	public Palacio(double m_cuadrados, String calle, int numero,
			int n_habitaciones) {
		super(m_cuadrados, calle, numero);
		this.n_habitaciones = n_habitaciones;
	}

	public int getN_habitaciones() {
		return n_habitaciones;
	}

	public void setN_habitaciones(int n_habitaciones) {
		this.n_habitaciones = n_habitaciones;
	}

	@Override
	public String toString() {
		return super.toString() + "  es un palacio [numero de habitaciones=" + n_habitaciones + "]";
	}
	
}
