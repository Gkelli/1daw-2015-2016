package Herencia1.viviendas;

public class Chalet extends Vivienda{
	
//	2)	Crea la clase Chalet: Es una vivienda que siempre tiene 200m2 y puede tener o no  jard�n. 
	
	private boolean jardin=false;

	public Chalet(String calle, int numero, boolean jardin) {
		super(200, calle, numero);
		this.jardin = jardin;		
	}

	public boolean isJardin() {
		return jardin;
	}

	public void setJardin(boolean jardin) {
		this.jardin = jardin;
	}

	@Override
	public String toString() {
		return super.toString() + " es un chalet [�tiene jardin?=" + jardin + "]";
	}

}
