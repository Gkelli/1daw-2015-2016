package Herencia1.animales;

public class Mamifero extends Animales {

	//2)	Mam�fero, clase que hereda de Animales y tiene como atributos numeroCrias, mesesEmbarazo.
	
	protected int n_crias;
	protected int meses_embarazo;
	
	public Mamifero(){}
	
	public Mamifero(String nombre_comun, String nombre_especifico, double peso,	double tamanno, int n_crias, int meses_embarazo) {
		super(nombre_comun, nombre_especifico, peso, tamanno);
		this.n_crias = n_crias;
		this.meses_embarazo = meses_embarazo;
	}

	public int getN_crias() {
		return n_crias;
	}

	public void setN_crias(int n_crias) {
		this.n_crias = n_crias;
	}

	public int getMeses_embarazo() {
		return meses_embarazo;
	}

	public void setMeses_embarazo(int meses_embarazo) {
		this.meses_embarazo = meses_embarazo;
	}

	@Override
	public String toString() {
		return super.toString() + " Es un mamifero [n�mero de crias=" + n_crias + ", meses de embarazo="
				+ meses_embarazo + "]";
	}
	
	
	
	
		
		
}
