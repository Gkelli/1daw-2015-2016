package Herencia1.animales;

public class Ave extends Animales {
	
	//3)	Ave, clase que hereda de Animales y tiene como atributos numeroHuevos y si puede o no volar.
	
	private int n_huevos;
	private boolean vuela=false;
	
	public Ave(){}

	public Ave(String nombre_comun, String nombre_especifico, double peso,	double tamanno,int n_huevos, boolean vuela) {
		super(nombre_comun, nombre_especifico, peso, tamanno);
		this.n_huevos = n_huevos;
		this.vuela = vuela;
	}

	public int getN_huevos() {
		return n_huevos;
	}

	public void setN_huevos(int n_huevos) {
		this.n_huevos = n_huevos;
	}

	public boolean isVuela() {
		return vuela;
	}

	public void setVuela(boolean vuela) {
		this.vuela = vuela;
	}

	@Override
	public String toString() {
		return super.toString() + " Es una Ave [n�mero de huevos=" + n_huevos + ", �vuela? =" + vuela + "]";
	}
	
	
	
	
	
	
	
	
	
	

}
