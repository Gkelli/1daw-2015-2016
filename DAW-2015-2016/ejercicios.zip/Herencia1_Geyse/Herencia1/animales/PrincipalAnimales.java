package Herencia1.animales;

public class PrincipalAnimales {

	public static void main(String[] args) {
//		1)	Instancia un objeto rana de la clase Animal, un objeto ballena de la clase Mamifero y un objeto perro de la clase MamiferoTerrestre, 
		//un objeto avestruz y otro paloma de clase Ave.
		
		Animales rana = new Animales("Ranita", "Rana", 1, 0.5);		
		Mamifero ballena = new Mamifero("Ballenita", "Ballena", 2000, 3, 2, 3);		
		MamiferoTerrestre perro = new MamiferoTerrestre("Perrito", "Perro", 6, 1, 0, 0, 4);		
		Ave avestruz = new Ave("Avestruz", "Avestruz", 15, 1.5, 5, false);		
		Ave paloma = new Ave("Palomita", "Paloma", 0.3, 0.2, 6, true);		
		
//		2)	Visualiza los datos de los objetos.
		
		System.out.println("Visualizando los datos de los animales una vez creados.");
		System.out.println(rana.toString());
		System.out.println(ballena.toString());
		System.out.println(perro.toString());
		System.out.println(avestruz.toString());
		System.out.println(paloma.toString());		
		
//		3)	Cambia el peso de la rana, d�ndole un nuevo valor.
		
		rana.setPeso(2);
		
//		4)	Cambia el peso de la ballena, d�ndole un nuevo valor.
		
		ballena.setPeso(3000);
		
//		5)	Cambia el atributo numeroHuevos de la paloma, d�ndole un nuevo valor.
		
		paloma.setN_huevos(8);
		
//		6)	Cambia el tama�o del perro, increment�ndolo en un 10%.
		
		perro.setTama�o(perro.getTamanno()*1.1);
		
		
//		7)	Cambia los meses de embarazo de la ballena.
		
		ballena.setMeses_embarazo(9);
		
		
//		8)	�Se puede cambiar los meses de embarazo de la rana? Razona la respuesta.
		
		// No se puede cambiar los meses de embarazo de la rana. Ya que rana es un objeto de la clase base Animales.
		//En esta clase general, no existe el atributo meses de embarazo, por lo que no es posible cambiar algo que no existe.
		
		
//		9)	Visualiza de nuevo los objetos.

		System.out.println("\nVisualizando los datos de los animales una vez modificado los datos");
		System.out.println(rana.toString());
		System.out.println(ballena.toString());
		System.out.println(perro.toString());
		System.out.println(avestruz.toString());
		System.out.println(paloma.toString());	

	}

}
