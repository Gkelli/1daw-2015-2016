package Herencia1.animales;

public class MamiferoTerrestre extends Mamifero{
	
	//4)	Mam�ferosTerrestre, clase que  hereda de Mam�fero y tiene como atributo numeroPatas.
	
	private int n_patas;
	
	public MamiferoTerrestre(){}

	public MamiferoTerrestre(String nombre_comun, String nombre_especifico, double peso, double tamanno, int n_crias, int meses_embarazo, int n_patas) {
		super(nombre_comun, nombre_especifico, peso, tamanno, n_crias, meses_embarazo);
		this.n_patas = n_patas;
	}

	public int getN_patas() {
		return n_patas;
	}

	public void setN_patas(int n_patas) {
		this.n_patas = n_patas;
	}

	@Override
	public String toString() {
		return super.toString() + " Adem�s es un mamifero terrestre [n�mero de patas=" + n_patas + "]";
	}
	
	
	
	

}
