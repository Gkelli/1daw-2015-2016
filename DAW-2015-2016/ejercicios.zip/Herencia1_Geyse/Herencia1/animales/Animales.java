package Herencia1.animales;

public class Animales {
	
	//1)	Animal, que contiene los siguientes atributos: Nombre com�n, nombre espec�fico, peso y tama�o.
	
	protected String nombre_comun;
	protected String nombre_especifico;
	protected double peso;
	protected double tamanno;
	
	public Animales() {}
	
	public Animales(String nombre_comun, String nombre_especifico, double peso,double tamanno) {
		this.nombre_comun = nombre_comun;
		this.nombre_especifico = nombre_especifico;
		this.peso = peso;
		this.tamanno = tamanno;
	}

	public String getNombre_comun() {
		return nombre_comun;
	}

	public void setNombre_comun(String nombre_comun) {
		this.nombre_comun = nombre_comun;
	}

	public String getNombre_especifico() {
		return nombre_especifico;
	}

	public void setNombre_especifico(String nombre_especifico) {
		this.nombre_especifico = nombre_especifico;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getTamanno() {
		return tamanno;
	}

	public void setTama�o(double tamanno) {
		this.tamanno = tamanno;
	}

	@Override
	public String toString() {
		return "Animal [Nombre Comun=" + nombre_comun + ", Nombre Especifico="
				+ nombre_especifico + ", Peso=" + peso + ", Tama�o=" + tamanno
				+ "]";
	}
	
	
	
	

}
