package Herencia1.Vehiculos;

import java.util.Arrays;

public class Empresa {
	
//	1)	La Empresa tendr� un nombre, un tama�o de flota (n� m�ximo de veh�culos que puede almacenar) 
//	y una flota que ser� un array de los veh�culos de los que dispone. Adem�s interesa saber el n�mero exacto de veh�culos que tiene en cada momento.
	
	private String nombre;
	private int tamanno_flota;
	private Vehiculo flota[];
	private int vehiculos_actuales;
	
	public Empresa(){}
	
	public Empresa(String nombre,int tamanno_flota) {
		this.nombre = nombre;
		this.tamanno_flota = tamanno_flota;
		this.vehiculos_actuales=0;
		this.flota = new Vehiculo[tamanno_flota];
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getTamanno_flota() {
		return tamanno_flota;
	}

	public void setTamanno_flota(int tamanno_flota) {
		this.tamanno_flota = tamanno_flota;
	}

	public Vehiculo[] getFlota() {
		return flota;
	}

	public void setFlota(Vehiculo[] flota) {
		this.flota = flota;
	}
	
	public int getVehiculos_actuales(){
		return vehiculos_actuales;	
	}
	
	
	@Override
	public String toString() {
		return "Empresa [nombre=" + nombre + ", tama�o de la flota=" + tamanno_flota + ", vehiculos de la flota=" + Arrays.toString(flota)
				+ ", numero de vehiculos actualmente en la flota=" + vehiculos_actuales + "]";
	}
//	3)	Definir un m�todo para buscar un vehiculo en la flota. Si lo encuentra, que lo visualice y si no que indique que no existe.
	public Vehiculo buscar_vehiculo(Vehiculo v){
		
		Vehiculo v_aux=null;
		
		for(int i=0; i < vehiculos_actuales; i++ ){
			if((flota[i]!=null) && (v.getMatricula()==flota[i].getMatricula()))
				v_aux= v;
		}
		return v_aux;		
	}
	
//	4)	Definir m�todos para comprar y vender veh�culos.
//	5)	Para comprar veh�culos, se comprobar� que el n�mero de veh�culos actuales no excede del tama�o m�ximo de flota. 
//	Se insertar� el veh�culo en la primera posici�n libre del array.
	
	public void comprar_vehiculo(Vehiculo v) {

		if (vehiculos_actuales == tamanno_flota)
			System.out.println("La flota est� completa");
		else {
			Vehiculo v_aux = buscar_vehiculo(v);
			if (v_aux != null)
				System.out.println("No puedes comprar un vehiculo que ya posees : " + v.getMatricula());
			else {
				flota[vehiculos_actuales] = v;
				vehiculos_actuales++;
				System.out.println("Has comprado el vehiculo con la matr�cula " + v.getMatricula());
			}
		}

	}
	//	6)	Para vender veh�culos, se localizar� en el array a trav�s de la matr�cula y se borrar� poniendo esa posici�n a null.
	
	public void vender_vehiculo(Vehiculo v) {

		boolean encontrado = false;
		int posicion = 0;

		Vehiculo v_aux = buscar_vehiculo(v);

		if (v_aux == null)
			System.out.println("No puedes vender un vehiculo que no posees : " + v.getMatricula());
		else {
			for (int i = 0; i < vehiculos_actuales && !encontrado; i++)
				if (v_aux.getMatricula() == flota[i].getMatricula()) {
					posicion = i;
					for (i = posicion; i < vehiculos_actuales; i++) // arreglarlo
						flota[i] = flota[i + 1];
					vehiculos_actuales--;
					System.out.println("Has vendido el vehiculo con la matr�cula " + v.getMatricula());
				}
		}
	}
	
	//metodo para ver un determinado vehiculo
	
	public void ver_vehiculo(Vehiculo v){
		
		Vehiculo v_aux=buscar_vehiculo(v);
		
		if(v_aux==null)
			System.out.println("El vehiculo no est� en la flota");
		else 
			System.out.println(v_aux.listar_datos_vehiculo());
		
	}
	
	//metodo para recorrer y mostrar toda la flota
	
	public void ver_flota(){
		
		if(vehiculos_actuales==0)
			System.out.println("Actualmente no dispones de ning�n vehiculo en la flota");
		else
			System.out.println("La flota actual de la empresa es:");
			for(int i=0; i < flota.length; i++){
				if(flota[i]!=null)
					System.out.println( flota[i].listar_datos_vehiculo() ); 
				}
		
	}
	
	
}
