package Herencia1.Vehiculos;

public class Vehiculo {
	
	protected String marca;
	protected String matricula;
	protected int n_rueda;
	protected double autonomia;
	
	public Vehiculo(){}

	public Vehiculo(String marca, String matricula, int n_rueda, double autonomia) {
		this.marca = marca;
		this.matricula = matricula;
		this.n_rueda = n_rueda;
		this.autonomia = autonomia;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public int getN_rueda() {
		return n_rueda;
	}

	public void setN_rueda(int n_rueda) {
		this.n_rueda = n_rueda;
	}

	public double getAutonomia() {
		return autonomia;
	}

	public void setAutonomia(double autonomia) {
		this.autonomia = autonomia;
	}

	public String listar_datos_vehiculo() {
		return "Vehiculo [marca=" + marca + ", matricula=" + matricula
				+ ", numero de rueda=" + n_rueda + ", autonomia=" + autonomia + "]";
	}
	

}
