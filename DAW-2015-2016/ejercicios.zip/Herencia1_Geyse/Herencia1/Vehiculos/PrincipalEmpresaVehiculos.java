package Herencia1.Vehiculos;

public class PrincipalEmpresaVehiculos {

	public static void main(String[] args) {
		
//		1)	Crear 1 veh�culo.
		
		Vehiculo vehiculo = new Vehiculo("Yamaha", "312312FSA", 2, 4.2);
		
//		2)	Crear 1 coches.
		
		Coche coche = new Coche("Opel", "4234DSA", 6.6, "negro", 5, false);
		
//		3)	Crear 2 camiones.
		
		Camion camion1 = new Camion("Mercedes", "8654YTR", 8, 22.1, 3000, 2000, "Juan");
		Camion camion2 = new Camion("MAN", "65464TRG", 10, 20.9, 2000, 100, "Manuela");
		
//		4)	Visualizar los datos de los objetos creados.
		
		System.out.println("---Se ha creado los siguientes vehiculos:---");
		System.out.println(vehiculo.listar_datos_vehiculo());
		System.out.println(coche.listar_datos_coche());
		System.out.println(camion1.listar_datos_camion());
		System.out.println(camion2.listar_datos_camion());
		
//		5)	Pintar el coche de rojo.
		
		System.out.println("\n---Se ha pintado el coche de rojo---");
		coche.pintar_coche("rojo");
		
//		6)	Cargar 30Kg al cami�n 1.
		
		System.out.println("\n---Se ha cargado el cami�n 1 con 30 kg---");	
		camion1.cargar(30);
		
//		7)	Descargar 20 Kg del cami�n 2.
		
		System.out.println("\n---Se ha descargado del cami�n 2 20 kg---");
		camion2.descargar(20);
		
//		8)	Descargar 200Kg del cami�n 1 y cargarlo en el cami�n 2.
		
		System.out.println("\n---Se va a descargar del camion 1 200 kg y cargarlo al cami�n 2---");
		camion1.descargar(200);
		camion2.cargar(200);
		
//		9)	Cambiar de conductor al cami�n 2.
		
		System.out.println("\n---Se va a cambiar el conductor del cami�n2---");
		camion2.cambiar_conductor("Pepe");
		
//		10)	Visualizar los datos de los objetos modificados.
		
		System.out.println("\n---Se va a mostrar los cambios realizados en los vehiculos:---");
		System.out.println(vehiculo.listar_datos_vehiculo());
		System.out.println(coche.listar_datos_coche());
		System.out.println(camion1.listar_datos_camion());
		System.out.println(camion2.listar_datos_camion());

//		Crear una empresa.
		
		Empresa empresa = new Empresa("Empresa, S.L.", 12);
		
//		Visualizar la flota (debe indicar que no hay veh�culos)
		System.out.println("\n---Se ha creado la empresa---");
		empresa.ver_flota();
		
//		Hacer que la empresa compre el vehiculo 1, el coche 1 y el camion 1
		System.out.println();
		empresa.comprar_vehiculo(vehiculo);
		empresa.comprar_vehiculo(coche);
		empresa.comprar_vehiculo(camion1);
		
//		Visualizar la flota.
		System.out.println("\n---Ver la flota actual:---");
		empresa.ver_flota();
		
//		Vender el camion 1 y el camion 2 (debe indicar que el camion 2 no existe)
		System.out.println("\n---Se va a vender el cami�n 1 y el cami�n 2:---");
		empresa.vender_vehiculo(camion1);
		empresa.vender_vehiculo(camion2);
		
		
//		Comprar ahora el camion 2.
		System.out.println("\n---Ahora se comprar� el cami�n 2:---");
		empresa.comprar_vehiculo(camion2);
		
//		Listar todos los veh�culos de la empresa.
		
		System.out.println("\n---Se visualizar� todos los vehiculos de la empresa:---");
		empresa.ver_flota();

	}

}
