package Herencia1.Vehiculos;

public class Coche extends Vehiculo{
	
//	1)	Para los coches almacena los siguientes atributos: marca, matricula, n�mero de ruedas (siempre 4),
//	autonom�a, color, n�mero de pasajeros y si es o no descapotable.
	
	private String color;
	private int n_pasajeros;
	private boolean descapotable = false;
	
	public Coche(){}
	
	public Coche(String marca, String matricula, double autonomia, String color, int n_pasajeros, boolean descapotable) {
		super(marca, matricula, 4, autonomia);
		this.color = color;
		this.n_pasajeros = n_pasajeros;
		this.descapotable = descapotable;
	}

	public String getColor() {
		return color;
	}

	public int getN_pasajeros() {
		return n_pasajeros;
	}

	public void setN_pasajeros(int n_pasajeros) {
		this.n_pasajeros = n_pasajeros;
	}

	public boolean isDescapotable() {
		return descapotable;
	}

	public void setDescapotable(boolean descapotable) {
		this.descapotable = descapotable;
	}

//	5)	Para manipular la informaci�n de los coches se utilizan dos m�todos:
//		a.	pintar: cambia de color un coche.
//		b.	listar: lista todos los atributos de un coche.

	public void pintar_coche(String color){
		this.color = color;
	}
	
	public String listar_datos_coche(){
		return super.listar_datos_vehiculo() + " es un coche [color=" + color + ", n_pasajeros=" + n_pasajeros
				+ ", � es descapotable?=" + descapotable + "]";
	}
	
	
}
