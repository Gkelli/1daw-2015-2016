package Herencia1.Vehiculos;

public class Camion extends Vehiculo{
	
//	2)	Para los camiones los atributos son: marca, matr�cula, n�mero de ruedas (no tiene porqu� ser 4), autonom�a, l�mite de carga (entero), carga (entero),
//	conductor (String). Si la carga excede del l�mite, se tomar� como carga dicho l�mite.
	
	private int limite_carga;
	private int carga;
	private String conductor;
	
	public Camion(){}
	
	public Camion(String marca, String matricula, int n_rueda, double autonomia, int limite_carga,int carga, String conductor) {
		super(marca, matricula, n_rueda, autonomia);
		this.limite_carga = limite_carga;
		this.carga = carga;
		this.conductor = conductor;
	}

	public int getLimite_carga() {
		return limite_carga;
	}

	public void setLimite_carga(int limite_carga) {
		this.limite_carga = limite_carga;
	}

	public int getCarga() {
		return carga;
	}

	public void setCarga(int carga) {
		this.carga = carga;
	}

	public String getConductor() {
		return conductor;
	}

	
//	6)	Para manipular la informaci�n de los camioneros se necesitan estos m�todos:
//		a.	cambiarConductor: Modificar el nombre del conductor del cami�n
	
	public void cambiar_conductor(String conductor) {
		this.conductor = conductor;
	}
//		b.	cargar: Incrementa la carga en cierta cantidad. La carga final no puede sobrepasar el l�mite, en cuyo caso se aplica lo mismo que en el construtor.
	
	
	
	public void cargar(int cantidad){
         
		if (limite_carga >= cantidad + carga) {
			setCarga(carga + cantidad);
		} else {	
			System.out.println("La cantidad introducida supera el limite de la carga del cami�n por lo que se ha cargado hasta el l�mite");
			setCarga(limite_carga);
			
		}
    }
	
//		c.	descargar: Dismimuye la carga en cierta cantidad. Si la cantidad es mayor que la carga, la carga se considerar� 0.
	
	public void descargar(int cantidad) {

		if (cantidad > this.carga) {
			setCarga(0);
			System.out.println("Se ha descargado toda la carga del cami�n.");
		} else {
			setCarga(carga - cantidad);
		}
	}

//		d.	listar: Lista todos los datos de un cami�n.


	public String listar_datos_camion() {
		return super.listar_datos_vehiculo() + " es un cami�n [limite_carga=" + limite_carga + ", carga=" + carga
				+ ", conductor=" + conductor + "]";
	}	
	

}
