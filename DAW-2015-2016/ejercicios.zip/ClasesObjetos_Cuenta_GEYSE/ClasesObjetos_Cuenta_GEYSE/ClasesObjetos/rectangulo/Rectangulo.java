package rectangulo;

public class Rectangulo {
	
	private Punto sup_izquierda;
	private Punto inf_derecha;

	public Rectangulo(){
		Punto p1=new Punto(0,0);
		Punto p2=new Punto(1,1);
		sup_izquierda=p1;
		inf_derecha=p2;
	}
	public Rectangulo(Punto p1,Punto p2){
		sup_izquierda=p1;
		inf_derecha=p2;
	}
	public Rectangulo(Punto punto, double ancho, double altura){
		sup_izquierda=punto;
		inf_derecha=new Punto(punto.getX(),punto.getY());;
		inf_derecha.desplazar(ancho,-altura);		
	}
	
	public double alto(){
		
		double x0=sup_izquierda.getX();
		double y0=inf_derecha.getY();
		Punto p1=new Punto(x0,y0);
		double altura=sup_izquierda.distancia(p1);
		return altura;
	}
	public double ancho(){
		Punto p2=new Punto(sup_izquierda.getX(),inf_derecha.getY());
		return inf_derecha.distancia(p2);
	}
	public double perimetro(){
		return ancho()*2+alto()*2;
	}
	public double area(){
		return ancho()*alto();
	}
	public void desplazar(double dx, double dy){
		sup_izquierda.desplazar(dx, dy);
		inf_derecha.desplazar(dx, dy);
	}
	public void imprimir(){
		sup_izquierda.imprimir_punto();
		inf_derecha.imprimir_punto();
	}

}
