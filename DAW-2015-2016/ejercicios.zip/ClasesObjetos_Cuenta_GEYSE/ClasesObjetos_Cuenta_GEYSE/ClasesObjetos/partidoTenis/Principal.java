package partidoTenis;

import articulo.LeerTeclado;

public class Principal {
	
	public static void main(String[] args) {
		String nombre_1,nombre_2;
		double punt_1,punt_2;
		
		System.out.println("Introduce el nombre y puntuacion del jugador 1");
		nombre_1=LeerTeclado.readString();
		punt_1=LeerTeclado.readDouble();
		
		System.out.println("\nIntroduce el nombre y puntuacion del jugador 2");
		nombre_2=LeerTeclado.readString();
		punt_2=LeerTeclado.readDouble();
		
		Jugador j1=new Jugador(nombre_1,punt_1);
		Jugador j2=new Jugador(nombre_2,punt_2);
		Partido partido=new Partido(j1,j2);
		
		partido.jugar();
		
	}

}
