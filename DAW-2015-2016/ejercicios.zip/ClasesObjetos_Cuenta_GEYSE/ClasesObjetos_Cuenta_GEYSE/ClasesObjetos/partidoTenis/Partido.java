package partidoTenis;

public class Partido {
	
	private Jugador jug1;
	private Jugador jug2;
	
	Partido (Jugador jug1, Jugador jug2){
		this.jug1=jug1;
		this.jug2=jug2;
	}
	
	public Jugador getJug1() {
		return jug1;
	}
	public Jugador getJug2() {
		return jug2;
	}
	
	public Jugador ganador(){
		
		double pto1;
		double pto2;
		do {
			pto1=Math.random()*jug1.getPuntuacion();
			pto2=Math.random()*jug2.getPuntuacion();
		}
		while (pto1==pto2);
		
		System.out.println("Los puntos del jugador 1 en el partido son: "+pto1);
		System.out.println("Los puntos del jugador 2 en el partido son: "+pto2);
		
		if (jug1.getPuntuacion()>jug2.getPuntuacion())
			return jug1;
		else 
			return jug2;
	}
	
	 public void jugar(){
		 Jugador ganador=ganador();
		 ganador.increm_puntuacion();
		 System.out.println("El ganador es: "+ganador.getNombre());
		 System.out.println("Su nueva puntuacion en la ATP es " + ganador.getPuntuacion());
	
	 }

}
