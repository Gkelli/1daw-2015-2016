package biblioteca;

public class Libro {
	
	private String isbn;
	private String titulo;
	private boolean prestado;
	private Autor autor;
	
	public Libro(String isbn, String titulo, Autor autor) {
		this.isbn = isbn;
		this.titulo = titulo;
		this.prestado = false;
		this.autor = autor;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public boolean isPrestado() {
		return prestado;
	}
	public void prestar() {
		if (prestado)
			System.out.println("El libro "+getTitulo()+" ya est� prestado, actualmente no se puede prestar");
		
		else {
			System.out.println("Se va a prestar el libro "+getTitulo());
			this.prestado =true;
		}		
	}
	
	public void devolver(){
		if (!prestado)
			System.out.println("El libro "+getTitulo()+" no est� prestado, no se puede devolver ");
		
		else {
			System.out.println("Se va a devolver el libro "+getTitulo());
			this.prestado =false;
		}	
	}	
	
	public Autor getAutor() {
		return autor;
	}
	public void setAutor(Autor autor) {
		this.autor = autor;
	}

	public String toString() {
		return "Libro [isbn=" + isbn + ", titulo=" + titulo + ", prestado="
				+ prestado + ", autor=" + autor.toString() + "]";
	}
	
}
