package biblioteca;

import articulo.LeerTeclado;

public class Principal {
	
public static void main(String[] args) {
		
		String nombre, nacionalidad, isbn, titulo;
		int annoNacim;
		Autor autor;
		
		System.out.println("Introduce los datos del primer autor: nombre, nacionalidad y a�o de nacimiento");
		nombre=LeerTeclado.readString();
		nacionalidad=LeerTeclado.readString();
		annoNacim=LeerTeclado.readInteger();
		
		Autor autor1=new Autor(nombre, nacionalidad, annoNacim);
		
		System.out.println("\nIntroduce los datos del segundo autor: nombre, nacionalidad y a�o de nacimiento");
		nombre=LeerTeclado.readString();
		nacionalidad=LeerTeclado.readString();
		annoNacim=LeerTeclado.readInteger();
		
		Autor autor2=new Autor(nombre, nacionalidad, annoNacim);
		
		System.out.println("\nIntroduce los datos del primer libro: isbn, titulo, nombre del autor");
		isbn=LeerTeclado.readString();
		titulo=LeerTeclado.readString();
		do {
			System.out.println("Los autores disponibles son: "+ autor1.getNombre() + " y "+autor2.getNombre());
			nombre=LeerTeclado.readString();
		}
		while (!nombre.equals(autor1.getNombre())&& !nombre.equals(autor2.getNombre()));
		
		if (nombre.equals(autor1.getNombre()))
			autor=autor1;
		else 
			autor=autor2;
		
		Libro libro1=new Libro (isbn, titulo, autor);
		
		System.out.println("\nIntroduce los datos del segundo libro: isbn, titulo, nombre del autor");
		isbn=LeerTeclado.readString();
		titulo=LeerTeclado.readString();
		do {
			System.out.println("Los autores disponibles son: "+ autor1.getNombre() + " y "+autor2.getNombre());
			nombre=LeerTeclado.readString();
		}
		while (!nombre.equals(autor1.getNombre())&& !nombre.equals(autor2.getNombre()));
		
		if (nombre.equals(autor1.getNombre()))
			autor=autor1;
		else 
			autor=autor2;
		
		Libro libro2=new Libro (isbn, titulo, autor);
		System.out.println("\n----------DATOS DE LOS AUTORES-------");
		System.out.println("Datos del primer libro"+libro1.toString());
		System.out.println("Datos del segundo libro"+libro2.toString());
		
		System.out.println("\n----------PRESTAR LIBRO-------");
		libro1.prestar();
		System.out.println("Datos del primer libro"+libro1.toString());
		libro1.prestar();
		System.out.println("\n----------DEVOLVER LIBRO-------");
		libro1.devolver();
		System.out.println("Datos del primer libro"+libro1.toString());
		libro1.devolver();
		
	
	

	}

}
