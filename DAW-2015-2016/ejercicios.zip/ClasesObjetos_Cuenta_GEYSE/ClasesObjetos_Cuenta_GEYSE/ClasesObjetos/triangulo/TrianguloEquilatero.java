package triangulo;

public class TrianguloEquilatero {
	
	private double lado;
	
	public TrianguloEquilatero() {		
	}
	
	public TrianguloEquilatero (int lado){
		this.lado=lado;
	}

	public double getLado () {
		return lado;
	}
	
	public void setLado (double lado){
		this.lado=lado;
	}
	
	public double getAltura (){
		double altura;		
		altura=(Math.sqrt((Math.pow(lado, 2))-Math.pow(lado/2, 2)));
		return altura;
	}
	
	public double area() {
		double area;
		area=(lado*getAltura())/2;
		return area;
	}
	
	public double perimetro(){
		return lado*3;
	}

	public String toString() {
		return "Datos Triangulo: [lado=" + lado + ", altura()="
				+ getAltura() + ", area=" + area() + ", perimetro="
				+ perimetro() + "]";
	}
	

}
