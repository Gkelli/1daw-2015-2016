package triangulo;

import articulo.LeerTeclado;

public class Principal {
	
	public static void main(String[] args) {
		int lado;
		System.out.println("introduce lado del primer tri�ngulo");
		lado=LeerTeclado.readInteger();
		
		TrianguloEquilatero t1=new TrianguloEquilatero(lado);
				
		System.out.println("\nLos datos del triangulo 1 son:");
		System.out.println("Lado = "+t1.getLado());
		System.out.println("Base = "+t1.getLado()/2);
		System.out.println("Altura = "+t1.getAltura());
		System.out.println("Area = "+t1.area());
		System.out.println("Perimetro = "+t1.perimetro());
		
		System.out.println("\nDatos del triangulo 1 "+t1.toString());
		
		System.out.println("\nIntroduce lado del segundo tri�ngulo");
		lado=LeerTeclado.readInteger();
		
		TrianguloEquilatero t2=new TrianguloEquilatero(lado);
		System.out.println("\nDatos del triangulo 2 "+t2.toString());
		
		System.out.println("\nCambiamos el lado del tri�ngulo 2, sumandole 1 ");
		t2.setLado(t2.getLado()+1); 
		System.out.println("\nDatos del triangulo 2 "+t2.toString());
		
		
	}

}
