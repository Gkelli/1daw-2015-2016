package recta;

import articulo.LeerTeclado;

public class Principal {
	
	public static void main(String[] args) {
		
		int x1,y1,x2,y2, inc1, inc2;
		System.out.println("Introduce las coordenadas del punto 1:");
		x1=LeerTeclado.readInteger();
		y1=LeerTeclado.readInteger();
		System.out.println("Introduce las coordenadas del punto 2:");
		x2=LeerTeclado.readInteger();
		y2=LeerTeclado.readInteger();
		
		
		Posicion p1=new Posicion (x1,y1);
		Posicion p2=new Posicion (x2,y2);
	
		System.out.println("\nLas coordenadas del punto 1 es: ");
		p1.getXY();
		System.out.println("Las coordenadas del punto 2 es: ");
		p2.getXY();
		
		System.out.println("\nLas coordenadas opuestas del punto 1 es: ");
		p1.opuesto().getXY();
		System.out.println("Las coordenadas opuestas del punto 2 es: ");
		p2.opuesto().getXY();
		
		System.out.println("\nIntroduce dos valores para incrementar y decrementar un punto");
		inc1=LeerTeclado.readInteger();
		inc2=LeerTeclado.readInteger();
		
		System.out.println("\nCoordenadas del punto 1 con el incremento");
		p1.incXY(inc1, inc2).getXY();
		
		System.out.println("Coordenadas del punto 1 con el decremento");
		p1.decXY(inc1, inc2).getXY();
		
		System.out.println("\nLa recta es:");
		p1.recta(p2);
	
		
		
		

	}

}
