
public class CuentaCorriente {
	
	public static void main(String[] args) {


		System.out.println("Introduce Nombre, Nif y Direcci�n del titular de la cuenta:");
		Cliente t1= new Cliente(LeerTeclado.readString(),LeerTeclado.readString(),LeerTeclado.readString());
		System.out.println(t1.toString());
		
		System.out.println("\nIntroduce los datos de la cuenta:");
		Cuenta c1= new Cuenta (t1);
		System.out.println(c1.toString());
		
		
		System.out.println("\nIntroduce cantidad a ingresar:");
		c1.ingresarCantidad(LeerTeclado.readDouble());
		System.out.println(c1.toString());
		
		System.out.println("\nIntroduce cantidad a retirar:");
		c1.retirarCantidad(LeerTeclado.readDouble());
		System.out.println(c1.toString());
	}


}
