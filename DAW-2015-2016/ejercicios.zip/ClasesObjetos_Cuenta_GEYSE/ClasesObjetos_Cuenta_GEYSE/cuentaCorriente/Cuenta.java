
public class Cuenta {
	
	private int entidad;
	private int oficina;
	private int control;
	private int numCuenta;
	private Cliente titular;
	private double saldo;
	
	public Cuenta(Cliente titular){
		this.titular = titular;		
		entidad=validarNum("entidad", 4);		
		oficina=validarNum("oficina", 4);		
		control=validarNum("control" , 2);		
		numCuenta=validarNum("n�mero de cuenta" , 10);		
		
		do {
			System.out.println("Introduce un saldo positivo");
			saldo=LeerTeclado.readDouble();}
		while (saldo<0)	;		
		
		}
	
	private static int longitudNum(int n){
		if (n<10)
			return 1;
		else 
			return 1+longitudNum(n/10);	
	}
	
	private static int validarNum( String a, int n){
		int m;
		
		do{	
			System.out.println("Introduce "+a+", debe tener "+n+" cifras");
			m=LeerTeclado.readInteger();}
		while (longitudNum(m)!=n);
		return m;
	}
	
	public int getEntidad() {
		return entidad;
	}

	public void setEntidad(int entidad) {
		this.entidad = entidad;
	}

	public int getOficina() {
		return oficina;
	}

	public void setOficina(int oficina) {
		this.oficina = oficina;
	}

	public int getControl() {
		return control;
	}

	public void setControl(int control) {
		this.control = control;
	}

	public int getNumCuenta() {
		return numCuenta;
	}

	public void setNumCuenta(int numCuenta) {
		this.numCuenta = numCuenta;
	}

	public Cliente getTitular() {
		return titular;
	}

	public void setTitular(Cliente titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public void ingresarCantidad(double cantidad){
		this.saldo = saldo + cantidad;
	}
	
	public void retirarCantidad(double cantidad){
		if (saldo<0)
			System.out.println("No se puede realizar la operaci�n, su saldo es negativo");
		else {
			if (saldo-cantidad<0 && saldo-cantidad<cantidad*0.1)
				System.out.println("Saldo insuficiente, no puedes realizar la operaci�n");
			else
				saldo-=cantidad;
		}		
	}	
	
	public String toString() {
		return "Datos de la cuenta: Entidad= " + entidad + ", Oficina= " + oficina
				+ ", Control= " + control + ", N�mero cuenta= " + numCuenta
				+ ";" + " Datos del titular= " + titular + ", Saldo= " + saldo + "]";
	}
		

}
