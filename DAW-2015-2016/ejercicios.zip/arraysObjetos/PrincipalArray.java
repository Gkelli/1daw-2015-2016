
public class PrincipalArray {

	public static void main(String[] args) {


		Array array = new Array();
		array.introducir_array();
		System.out.println("Array:");
		array.ver_array();
		System.out.println("Array invertido:");
		array.ver_array_invertido();

	}

}
