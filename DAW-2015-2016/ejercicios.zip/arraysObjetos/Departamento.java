import java.util.Arrays;

public class Departamento {
	
	private int codigo_departamento;
	private String nombre_departamento;
	private int n_empleados;
	private Empleado lista_empleados[];
	
	public Departamento(){}
	
	public Departamento(int codigo_departamento, String nombre_departamento, int n_empleados){
		this.codigo_departamento = codigo_departamento;
		this.nombre_departamento = nombre_departamento;
		this.n_empleados = n_empleados;
		lista_empleados = new Empleado[this.n_empleados];
		
	}

	public int getCodigo_departamento() {
		return codigo_departamento;
	}

	public void setCodigo_departamento(int codigo_departamento) {
		this.codigo_departamento = codigo_departamento;
	}

	public String getNombre_departamento() {
		return nombre_departamento;
	}

	public void setNombre_departamento(String nombre_departamento) {
		this.nombre_departamento = nombre_departamento;
	}

	public int getN_empleados() {
		return n_empleados;
	}

	public void setN_empleados(int n_empleados) {
		this.n_empleados = n_empleados;
	}

	public Empleado[] getLista_empleados() {
		return lista_empleados;
	}

	public void setArray_empleados(Empleado[] lista_empleados) {
		this.lista_empleados = lista_empleados;
	}

	@Override
	public String toString() {
		return "Departamento [codigo=" + getCodigo_departamento() + ", nombre="
				+ getNombre_departamento() + ", numero de empleados=" + getN_empleados() + ", empleados="
				+ Arrays.toString(lista_empleados) + "]";
	}
	
	public Empleado buscar_empleado_codigo(int codigo){
		return lista_empleados[codigo];	
	}
	
	public Empleado buscar_empleado_nombre(String nombre){
		Empleado empleado_aux = null;
		boolean encontrado=false;
		
		for (int i = 0; i < lista_empleados.length && !encontrado; i++) {
			if (lista_empleados[i]!=null && lista_empleados[i].getNombre_empleado().equalsIgnoreCase(nombre)) {				
				empleado_aux=lista_empleados[i];
				encontrado = true;	
				break;
			}
		}
		return empleado_aux;
	}
	
	public void insertar_empleado(int codigo){
		
		System.out.println("Introduzca el nombre y el sueldo del empleado a introducir");
		String nombre = LeerTeclado.readString();
		double sueldo= LeerTeclado.readDouble();
		Empleado empleado_aux = new Empleado(codigo, nombre, sueldo);
		
		lista_empleados[codigo]=empleado_aux;
		
	}
	
	public void insertar_empleado(Empleado empleado){
		lista_empleados[empleado.getCodigo_empleado()]=empleado;	
	}
	
	public boolean departamento_lleno(){
		boolean vacio =true;
		for (int i = 0; i < lista_empleados.length; i++) {
			if (lista_empleados[i]!=null) {
				vacio=false;
			}
		}
		if (!vacio) 
			System.out.println("El departamento est� lleno. No se puede introdocir m�s empleados");
		return true; // ver donde meterlo
		
	}
	
	public void crear_empleado(){
		
		int codigo = 0;
		Empleado empleado_aux;
		
		do {
			
			System.out.println("Introduce el codigo del empleado a dar de alta. 0 a " + (n_empleados-1));
			codigo=LeerTeclado.readInteger();
			if (codigo<0 || codigo>=n_empleados) {
				System.out.println("ERROR");
			}
		} while (codigo <0 || codigo>=n_empleados);
		
		empleado_aux=buscar_empleado_codigo(codigo);
		
		if (empleado_aux!=null) {
			System.out.println("ERROR. El empleado ya existe");
		} else {
			insertar_empleado(codigo);
		}		
	}
	
	public void borrar_empleado(int codigo){
		lista_empleados[codigo]=null;
	}	
	
	public Empleado empleado_mayor_sueldo(){
		
		Empleado empleado_aux=null;		
		double maximo=Integer.MIN_VALUE;
		
		for (int i = 0; i <  lista_empleados.length; i++ ){
			if ( lista_empleados[ i] !=null)
				if ( lista_empleados[i].getSueldo() > maximo){
					maximo= lista_empleados[i].getSueldo();
					empleado_aux= lista_empleados[i];
				}
		}
		return empleado_aux;
	}

}
