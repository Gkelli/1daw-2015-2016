
public class Ventas {

	public static void main(String[] args) {

		System.out.println("Introduce el n�mero de empleados");
		Matriz matriz = new Matriz(LeerTeclado.readInteger(), 6);

		int opcion;
		boolean repetir = false;
		
		do{
			
		System.out.println("----Elige una opci�n----");
		System.out.println("1- Iniciar matriz");
		System.out.println("2- Visualizar matriz");
		System.out.println("3- M�ximo de ventas y el total semanal de un vendedor");
		System.out.println("4- Minimo de ventas y el vendedor que lo obtuvo");
		System.out.println("5- Visualizar los totales vendidos en cada dia de la semana");
		System.out.println("6- Visualizar las ventas totales");
		System.out.println("Otro - FIN");
		
		opcion=LeerTeclado.readInteger();
		switch (opcion) {
		case 1:
			matriz.introducir_datos();
			break;
		case 2:
			matriz.visualizar();
			break;
		case 3:
			System.out.println("Introduce el c�digo de vendedor, para visualizar su m�ximo de ventas y su total semanal");
			int fila=LeerTeclado.readInteger();
			matriz.maximo_fila(fila);
			matriz.total_fila(fila);
			break;
		case 4:
			System.out.println("Introduce un dia para visualizar su minimo de ventas y el vendedor que lo obtuvo");
			matriz.minimo_columna(LeerTeclado.readInteger());
			break;
		case 5:
			for (int i = 0; i < 6; i++) {
			matriz.total_columna(i);	
			}
			break;
		case 6:
			matriz.total_matriz();
			break;
		default:
			System.out.println("Opci�n no existe");
			break;
		}
			
		repetir=false;
		System.out.println();
		System.out.println("�Desea repetir? s(si)");
		String respuesta = LeerTeclado.readString();
		if(respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("si"))
			repetir=true;
			else 
				System.out.println("Fin del programa");
			
		} while(repetir);		
	}

}
