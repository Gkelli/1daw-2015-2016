
public class Carta {
	

	private static int[] cartas = {1,2,3,4,5,6,7,8,9,10,11,12,13};
	private static String[] palos = {"Corazones", "Picas", "Rombos", "Tr�boles"};
	
	public Carta(){		
	}
	
	public static int[] getCartas() {
		return cartas;
	}

	public static void setCartas(int[] cartas) {
		Carta.cartas = cartas;
	}

	public static String[] getPalos() {
		return palos;
	}

	public static void setPalos(String[] palos) {
		Carta.palos = palos;
	}

	public static double jugada_jugador () {
		System.out.println("Comienza la ronda. Es su turno.");
		boolean fin_ronda = false;
		double total_mano = 0;
		while (!fin_ronda) {
			double carta = dar_carta();
			total_mano = total_mano + carta;
			System.out.println("Su mano: " + String.valueOf(total_mano));
			if (total_mano >= 17) {
				System.out.println("El valor de su mano es mayor a 17, finaliza la ronda.");
				fin_ronda = true;
			} else {
				System.out.println("�Desea otra carta? S(Si)/N(No)");
				String respuesta_jugador = LeerTeclado.readString();
				System.out.println(respuesta_jugador);
				while (!(respuesta_jugador.equalsIgnoreCase("s")) && !(respuesta_jugador.equalsIgnoreCase("n"))) {
					System.out.println("Opci�n no v�lida, por favor introduzca S para si o N para no");
					respuesta_jugador = LeerTeclado.readString();
				}
				if (respuesta_jugador.equalsIgnoreCase("n")) {
					fin_ronda = true;
				}
			}
		}
		return total_mano;
	}
	
	public static double jugada_maquina () {
		System.out.println("Es el turno del oponente. La m�quina esta jugando ahora.");
		double valor_total = 10 + (double)(Math.random() * ((21 - 10) + 1)); //La m�quina puede exceder el m�ximo
		valor_total = Math.round(valor_total - 0.5) + 0.5;
		System.out.println("La mano de la m�quina es " + String.valueOf(valor_total));
		return valor_total;
	}
	
	public static double dar_carta () {
		double carta = 0;
		carta = cartas[(int) (Math.random() * 13)];
		String nombre_carta = null;
		if (carta == 11) {
			nombre_carta = "J";
			carta = 0.5;
		} else if (carta == 12) {
			nombre_carta = "Q";
			carta = 0.5;
		} else if (carta == 13) {
			nombre_carta = "K";
			carta = 0.5;
		} else if (carta == 1) {
			nombre_carta = "As";
		} else {
			nombre_carta = String.valueOf((int) carta);
		}
		String palo_mano = palos[(int)(Math.random() * 4)];
		System.out.println("Su carta es: " + nombre_carta + " de " + palo_mano);
		return carta;
	}

}
