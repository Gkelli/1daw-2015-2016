
public class Empresa {
	
	private int n_empleados=(int) 4;
	private Departamento[] lista_departamento;
	
	public Empresa(){
		lista_departamento = new Departamento[n_empleados];
	}
	
	public Departamento buscar_departamento_codigo(int codigo){
		return lista_departamento[codigo];
	}
	
	public Departamento buscar_departamento_nombre(String nombre){
		Departamento departamento_aux = null;
		boolean encontrado = false;
		for (int i = 0; i < lista_departamento.length && encontrado; i++) {
			if (lista_departamento[i]!=null && lista_departamento[i].getNombre_departamento().equalsIgnoreCase(nombre)) {
				departamento_aux=lista_departamento[i];
				encontrado= true;
				break;
			}
		}
		return departamento_aux;
	}
	
	public void validar_codigo_departamento(int codigo_departamento){
		
		do {
			if (codigo_departamento < 0 || codigo_departamento >= n_empleados) {
				System.out.println("ERROR. El c�digo introducido no es valido");
				 break;
			}
		} while (codigo_departamento < 0 || codigo_departamento >= n_empleados);		
	}
	// error cuando se excedeo, intentar validar que no ocurra eso, y que cuando est� llena la lista salga 
	
	public boolean empresa_llena(){
		boolean vacio =true;
		for (int i = 0; i < lista_departamento.length; i++) {
			if (lista_departamento[i]!=null) {
				vacio=false;
			}
		}
		//if (!vacio) 
			//System.out.println("La empresa est� llena. No se puede introdocir m�s departamentos");
			
		return vacio; // ver donde meterlo
		
	}
	
	public void insertar_departamento(int codigo){
		System.out.println("Introduzca el nombre del departamento y el numero de empleados que tendr� ");
		String nombre = LeerTeclado.readString();
		int num_empleados =LeerTeclado.readInteger();
		Departamento departamento_aux = new Departamento(codigo, nombre, num_empleados);
		
		lista_departamento[codigo]=departamento_aux;
		
	}
	
	public void insertar_departamento(Departamento departamento){
		lista_departamento[departamento.getCodigo_departamento()]=departamento;
	}
	
	public void alta_departamento(){
		
		int codigo;
		System.out.println("Introduzca el codigo del departamento a dar de alta. 0-3");
		codigo=LeerTeclado.readInteger();
		validar_codigo_departamento(codigo);
		
		//while (empresa_llena()) {
			Departamento departamento_aux = buscar_departamento_codigo(codigo);

			if (departamento_aux != null) {
				System.out.println("ERROR. El Departamento con el codigo " + codigo + " ya existe");
			} else {
				insertar_departamento(codigo);
			}
		//}
			
	}
	
	
	public void asignar_empleado_departamento(){
		int codigo_departamento;
		
		System.out.println("Introduzca el codigo del departamento a dar de alta el empleado");
		codigo_departamento=LeerTeclado.readInteger();
		validar_codigo_departamento(codigo_departamento);
		
		Departamento departamento_aux = buscar_departamento_codigo(codigo_departamento);
		if (departamento_aux==null) {
			System.out.println("ERROR. El departamento n�"+codigo_departamento+" no existe.");
		} else {
			if (codigo_departamento>=n_empleados || codigo_departamento<n_empleados) {
				departamento_aux.crear_empleado();
			}	
		}		
	}
	
	public void visualizar_departamento(){

		int codigo_departamento;
		
		System.out.println("Introduce el c�digo del departamento a visualizar");
		codigo_departamento=LeerTeclado.readInteger();
		validar_codigo_departamento(codigo_departamento);

		Departamento departamento_aux = buscar_departamento_codigo(codigo_departamento);
		if (departamento_aux==null) {
			System.out.println("ERROR. El departamento n� " + codigo_departamento + " no existe");
		} else {
			for (int i = 0; i < lista_departamento.length; i++) {
				if (lista_departamento[i]!=null) {
					System.out.println("Informaci�n Departamento : " + lista_departamento[i].toString());
				}
			}
		}		
	}
	
	public void buscar_nombre_empleado(){
		int codigo_departamento;
		
		System.out.println("Introduce el c�digo del departamento");
		codigo_departamento=LeerTeclado.readInteger();
		validar_codigo_departamento(codigo_departamento);
		
		Departamento departamento_aux = buscar_departamento_codigo(codigo_departamento);
		if (departamento_aux == null) {
			System.out.println("ERROR. El departamento con el codigo " + codigo_departamento + " no es v�lido");
		} else {
			Empleado empleado_aux;
			System.out.println("Introduce el nombre del empleado a buscar");
			String nombre = LeerTeclado.readString();
			empleado_aux = departamento_aux.buscar_empleado_nombre(nombre);

			if (empleado_aux != null) {
				System.out.println(empleado_aux.toString());
			} else {System.out.println("ERROR. El empleado " + nombre + " no se ha encontrado en el departamento");
				
			}
		}
	}
	
	public void buscar_codigo_empleado(){
		int codigo_departamento;
		
		System.out.println("Introduce el c�digo del departamento");
		codigo_departamento=LeerTeclado.readInteger();
		validar_codigo_departamento(codigo_departamento);
		
		Departamento departamento_aux = buscar_departamento_codigo(codigo_departamento);
		if (departamento_aux == null) {
			System.out.println("ERROR. El departamento con el codigo " + codigo_departamento + " no es v�lido");
		} else {
			Empleado empleado_aux;
			System.out.println("Introduce el codigo del empleado a buscar");
			int codigo_empleado = LeerTeclado.readInteger();
			empleado_aux = departamento_aux.buscar_empleado_codigo(codigo_empleado);

			if (empleado_aux == null) {
				System.out.println("ERROR. El empleado " + codigo_empleado + " no se ha encontrado en el departamento");
			} else {
				System.out.println(empleado_aux.toString());
			}
		}
	}
	
	public void incrementar_sueldo(){
		int codigo_departamento;
		
		System.out.println("Introduce el c�digo del departamento");
		codigo_departamento=LeerTeclado.readInteger();
		validar_codigo_departamento(codigo_departamento);
		
		Departamento departamento_aux = buscar_departamento_codigo(codigo_departamento);
		if (departamento_aux == null) {
			System.out.println("ERROR. El departamento con el codigo " + codigo_departamento + " no es v�lido");
		} else {
			Empleado empleado_aux;
			System.out.println("Introduce el codigo del empleado a incrementar el sueldo");
			int codigo_empleado = LeerTeclado.readInteger();
			empleado_aux = departamento_aux.buscar_empleado_codigo(codigo_empleado);

			if (empleado_aux == null) {
				System.out.println("ERROR. El empleado " + codigo_empleado + " no existe");
			} else {
				empleado_aux.setSueldo(empleado_aux.getSueldo() + (empleado_aux.getSueldo()*0.1));
				System.out.println("El nuevo sueldo del empleado " + empleado_aux + " es " + empleado_aux.getSueldo());
			}
		}
		
	}
	
	public void borrar_empleado() {
		int codigo_departamento;

		System.out.println("Introduce el c�digo del departamento");
		codigo_departamento = LeerTeclado.readInteger();
		validar_codigo_departamento(codigo_departamento);
		Departamento departamento_aux;
		departamento_aux = buscar_departamento_codigo(codigo_departamento);

		if (departamento_aux == null)
			System.out.println("ERROR. El departamento " + codigo_departamento + " no existe");
		else {

			System.out.println("Introduce c�digo de empleado a borrar");
			int codigo_empleado = LeerTeclado.readInteger();

			Empleado empAux;
			empAux = departamento_aux.buscar_empleado_codigo(codigo_empleado);

			if (empAux == null)
				System.out.println("ERROR. El empleado " + codigo_empleado + " no se ha encontrado");
			else
				departamento_aux.borrar_empleado(codigo_empleado);
			System.out.println("Se ha borrado el empleado " + codigo_empleado);

		}
	}
	
	public void mayor_sueldo_departamento(){
		
		int codigo_departamento;
		System.out.println("Introduce el c�digo del departamento");
		codigo_departamento = LeerTeclado.readInteger();
		validar_codigo_departamento(codigo_departamento);
		Departamento departamento_aux = buscar_departamento_codigo(codigo_departamento);
		
		if (departamento_aux==null) {
			System.out.println("ERROR. No Existe el departamento "  + codigo_departamento);
		} else {
			System.out.println("El empleado con mayor sueldo es " + departamento_aux.empleado_mayor_sueldo().toString());
		}
	}
	
	public void mayor_sueldo_empresa(){
		double maximo = Integer.MIN_VALUE;
		Departamento departamento_aux;
		Empleado empleado_aux, empleado_max = null;
		
		for (int i = 0; i < lista_departamento.length; i++) {
			if (lista_departamento[i]!=null) {
				departamento_aux=lista_departamento[i];
				empleado_aux=departamento_aux.empleado_mayor_sueldo();
				if (maximo<empleado_aux.getSueldo()) {
					maximo=empleado_aux.getSueldo();
					empleado_max=empleado_aux;
				}
			}
		}
		System.out.println("El empleado que tiene el maximo sueldo es " + empleado_max.toString());
	}
}
