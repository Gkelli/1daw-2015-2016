
public class Array {

	private int array[] ;
	
	public Array(){
		this.array = new int [10];
	}

	public int[] getArray() {
		return array;
	}

	public void setArray(int[] array) {
		this.array = array;
	}
	
	public void introducir_array(){
		System.out.println("Introducir 10 numeros en el array:");
		for (int i = 0; i < this.array.length; i++) {
			int n = LeerTeclado.readInteger();
			array[i]=n;
		}
	}
	
	public void ver_array(){
		for (int i = 0; i < this.array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}
	
	public void ver_array_invertido(){
		for (int i = this.array.length-1; i >=0; i--) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}
	

}
