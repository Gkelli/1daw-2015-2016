
public class PrincipalEmpresa {

	public static void main(String[] args) {

		Empresa empresa = new Empresa();
		int opcion;
		String respuesta;
		boolean repetir=false;
		
		do {
			
			System.out.println("----Men� de empresa----");
			System.out.println("1- Alta departamento");
			System.out.println("2- Asignar empleado a departamento");
			System.out.println("3- Visualizar departamento");
			System.out.println("4- Buscar empleado de un departamento por codigo");
			System.out.println("5- Buscar empleado de un departamento por nombre");
			System.out.println("6- Incrementar sueldo de un empleado");
			System.out.println("7- Borrar un empleado");
			System.out.println("8- Visualizar empleado con mayor sueldo de cada departamento");
			System.out.println("9- Visualizar empleado con mayor sueldo de la empresa");
			
			opcion=LeerTeclado.readInteger();
			
			switch (opcion) {
			case 1:
				empresa.alta_departamento();
				break;

			case 2:
				empresa.asignar_empleado_departamento();
				break;

			case 3:
				empresa.visualizar_departamento();
				break;

			case 4:
				empresa.buscar_codigo_empleado();
				break;

			case 5:
				empresa.buscar_nombre_empleado();
				break;

			case 6:
				empresa.incrementar_sueldo();
				break;

			case 7:
				empresa.borrar_empleado();
				break;

			case 8:
				empresa.mayor_sueldo_departamento();
				break;

			case 9:
				empresa.mayor_sueldo_empresa();
				break;

			default:
				System.out.println("ERROR. Opci�n no v�lida");
				break;
			}
			
			System.out.println("\n�Desea Repetir? s/si");
			respuesta=LeerTeclado.readString();
			if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("si")) {
				repetir=true;
			}
			
		} while (repetir);
		
		
		

	}

}
