
public class Empleado {
	
	private int codigo_empleado;
	private String nombre_empleado;
	private double sueldo;
	
	public Empleado(int codigo_empleado, String nombre_empleado, double sueldo) {
		super();
		this.codigo_empleado = codigo_empleado;
		this.nombre_empleado = nombre_empleado;
		this.sueldo = sueldo;
	}
	public int getCodigo_empleado() {
		return codigo_empleado;
	}
	public void setCodigo_empleado(int codigo_empleado) {
		this.codigo_empleado = codigo_empleado;
	}
	public String getNombre_empleado() {
		return nombre_empleado;
	}
	public void setNombre_empleado(String nombre_empleado) {
		this.nombre_empleado = nombre_empleado;
	}
	public double getSueldo() {
		return sueldo;
	}
	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	@Override
	public String toString() {
		return "Empleado [codigo del empleado=" + getCodigo_empleado() + ", Nombre empleado="
				+ getNombre_empleado() + ", sueldo=" + getSueldo() + "]";
	}
	
	

}
