
public class Matriz {

	private int n_filas;
	private int n_columnas;
	private int matriz[][];
	
	public Matriz(){}
	
	public Matriz(int n_filas, int n_columnas){
		this.n_filas=n_filas;
		this.n_columnas=n_columnas;
		matriz = new int[this.n_filas][this.n_columnas];
	}

	public int getN_filas() {
		return n_filas;
	}

	public void setN_filas(int n_filas) {
		this.n_filas = n_filas;
	}

	public int getN_columnas() {
		return n_columnas;
	}

	public void setN_columnas(int n_columnas) {
		this.n_columnas = n_columnas;
	}
	
	public void introducir_datos(){
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j]=(int)(Math.random()*50) + 1;
			}
		}		
	}
	
	public void visualizar(){
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	public void total_matriz(){
		int total = 0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				total+=matriz[i][j];
			}
		}
		System.out.println("Las ventas totales es  " + total);
	}
	
	public void total_fila(int fila){
		int total_fila=0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (fila==i) {
					total_fila+=matriz[i][j];
				}				
			}
		}
		System.out.println("El total semanal del vendedor " +fila +" es " + total_fila);
	}
	
	public void total_columna(int columna){
		int total_columna=0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (columna==j) {
					total_columna+=matriz[i][j];
				}				
			}
		}
		System.out.println("El total vendido en el dia " + columna + " es " + total_columna);
	}
	
	public void maximo_fila(int fila){
		int max_fila=Integer.MIN_VALUE;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (matriz[fila][j]>max_fila) {
					max_fila=matriz[fila][j];
				}
			}
		}
		System.out.println("El m�ximo de ventas del vendedor  " + fila + " es " + max_fila);
	}
	
	public void minimo_columna(int columna){
		int min_fila=Integer.MAX_VALUE, posicion=0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (matriz[i][columna]<min_fila) {
					min_fila=matriz[i][columna];
					posicion=i;
				}
			}
		}
		System.out.println("El minimo de ventas del dia " + columna + " es " + min_fila + " y el vendedor que lo hizo es el vendedor " + posicion);
	}
	
	public void maximo_matriz(){
		int max = Integer.MIN_VALUE, fila = 0, columna=0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (matriz[i][j]>max) {
					max=matriz[i][j];
					fila=i;
					columna=j;
				}
			}
		}
		System.out.println("El m�ximo de la matriz es " + max + " y est� en la fila " + fila + " y columna " + columna);
	}
	
	
	
	
	
}
