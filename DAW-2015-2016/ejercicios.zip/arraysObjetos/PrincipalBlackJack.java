
public class PrincipalBlackJack {

	public static void main(String[] args) {

	//	Carta carta = new Carta();	
		
		double jugador_mano = Carta.jugada_jugador();
		double maquina_mano = Carta.jugada_maquina();
		
		if (jugador_mano == 17) {
			System.out.println("Has ganado ");
		} else if (maquina_mano == 17) {
			System.out.println("Lo sentimos, has perdido");
		} else if (maquina_mano == 17 && jugador_mano == 17) {
			System.out.println("Empate.");
		} else if (maquina_mano > 17 && jugador_mano > 17) {
			if (maquina_mano < jugador_mano) {
				System.out.println("Lo sentimos, ha sido derrotado. Ha ganado la m�quina.");
			} else {
				System.out.println("Has ganado ");
			}
		} else if (maquina_mano < 17 && jugador_mano > 17) {
			System.out.println("Has perdido");
		} else if (maquina_mano > 17 && jugador_mano < 17) {
			System.out.println("Has ganado ");
		} else {
			if (jugador_mano > maquina_mano) {
				System.out.println("Has ganado");
			} else {
				System.out.println("Ha ganado la m�quina");
			}
		}
	}

}
