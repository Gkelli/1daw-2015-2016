
public class PrincipalAlumnos {

	public static void main(String[] args) {

		Alumnos array_alumnos[] = new Alumnos[30];
		String nombre;
		double nota;
		int aprobados=0, suspensos=0;
		double media=0, suma=0;
		
		System.out.println("-----Crear los 30 alumnos-------");
		
		for (int i = 0; i < array_alumnos.length; i++) {
			System.out.println("Introduce el nombre del alumno " + (i+1));
			nombre= LeerTeclado.readString();
			do{
				System.out.println("La nota (0 a 10) del alumno "+ (i+1));
				nota=LeerTeclado.readDouble();
			}while(nota<0 || nota>10);
		
			Alumnos alumnos = new Alumnos(nombre,nota);
			array_alumnos[i]=alumnos;
		}
		
		for (int i = 0; i < array_alumnos.length; i++) {		
			
			if(array_alumnos[i].aprobado()){
				System.out.println(array_alumnos[i]+" est� aprobado");
				aprobados++;				
			} else {
				System.out.println(array_alumnos[i]+" est� suspenso");
				suspensos++;
			}			
			suma+=array_alumnos[i].getNota();				
		}
		System.out.println("\nHay " + aprobados + " alumnos aprobados y " + suspensos + " alumnos suspensos");
		media=suma/array_alumnos.length;
		System.out.println("\nLa media de notas de los alumnos es " + media);
		
		System.out.println("\n----------Lista ordenada de alumnos por nombre---------");
		
		for (int i = array_alumnos.length; i >0; i--) {
			for (int j = 0; j < i-1; j++) {
				if(array_alumnos[j].getNombre().compareToIgnoreCase(array_alumnos[j+1].getNombre())>0){
				Alumnos aux=array_alumnos[j];
				array_alumnos[j]=array_alumnos[j+1];
				array_alumnos[j+1]=aux;
			}
			
			}
		}
		for (int i = 0; i < array_alumnos.length; i++) {
			System.out.println(array_alumnos[i] + " ");
		}
		
		System.out.println("\n----------Buscar la nota de un alumno---------");
		
		do {
			System.out.println("Introduce el nombre del alumno a buscar");
			nombre = LeerTeclado.readString();

			if (nombre.isEmpty())
				System.out.println("el nombre no puede estar en blanco");

		} while (nombre.isEmpty());
		
		boolean encontrado=false;
		for (int i = 0; i < array_alumnos.length && !encontrado; i++) {
			if (array_alumnos[i].getNombre().equalsIgnoreCase(nombre)) {
				System.out.println("El alumno " +array_alumnos[i].getNombre()+ " tiene nota : " + array_alumnos[i].getNota());
				encontrado=true;
			} 
			
		}
		if(!encontrado){
			System.out.println("No se ha encontrado el alumno" + nombre);
		}
		
		
		System.out.println("\n--------Buscar alumnos con una nota igual o superior----");
		do{
			System.out.println("Introduce un nota (0 a 10) a buscar ");
			nota=LeerTeclado.readDouble();
		}while(nota<0 || nota>10);
		
		System.out.println("\nLos alumnos con nota mayor o igual que " + nota + " son:");
		for (int i = 0; i < array_alumnos.length ; i++) {
			if (array_alumnos[i].getNota()>= nota) {
				System.out.println(array_alumnos[i] + " ");
				encontrado=true;
			} 
			
		}
		

	}

}
