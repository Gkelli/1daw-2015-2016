package EjerciciosRecursividad;

import EjerciciosMetodos.Ejercicio01;

public class Recursivo12 {

	public static void main(String[] args) {
		/* 12.	Escribir un programa que pase un n� de decimal a binario usando recursividad:
		�	N=4  =>  Generar� 100  */
		
		int num=Ejercicio01.introducirNumero();
		System.out.println("El n� decimal en binario es ");
		binario(num);
		
		
	}
	public static void binario (int n){
		if (n < 2) {
			System.out.print(n);	
		}
		else {
			binario(n/2);
			System.out.print(n % 2);
			
		}
	}
	
}
