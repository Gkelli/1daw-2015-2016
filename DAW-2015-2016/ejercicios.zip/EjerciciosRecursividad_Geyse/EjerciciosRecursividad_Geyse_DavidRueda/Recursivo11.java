package EjerciciosRecursividad;

import EjerciciosMetodos.Ejercicio01;

public class Recursivo11 {

	public static void main(String[] args) {
		/*  11.	Escribir un programa que dado un n�mero N calcule los N primeros n�meros de la serie de Fibonacci usando recursividad:
				�	a1=0
				�	a2=1
				�	an= an-1 + an-2 
				
				*    x6 = x6-1 + x6-2 = x5 + x4 = 5 + 3 = 8
				*/

			int num=Ejercicio01.introducirNumero();
			System.out.println("Los "+num+" primeros n�meros de la serie de Fibonacci son");
			for (int j=0; j<=num;j++)
				System.out.println("a"+ j + "=" + fibonacci(j));
			
			
	}
	
	public static double fibonacci(int n) {
		double a;
		if ((n == 0) || (n == 1))
			a = 1;
		else
			a = fibonacci(n - 1) + fibonacci(n - 2);
		return a;

	}
	/*public static int fibonacci(int n){
		if (n == 1)
			return 0;
		else if (n == 2)
			return 1;
		else
			return fibonacci(n - 1) + fibonacci(n - 2);*/

}
