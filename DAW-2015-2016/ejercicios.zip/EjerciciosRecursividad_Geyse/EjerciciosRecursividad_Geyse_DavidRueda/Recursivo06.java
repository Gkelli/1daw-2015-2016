package EjerciciosRecursividad;

import EjerciciosMetodos.Ejercicio01;

public class Recursivo06 {

	public static void main(String[] args) {
		/* Escribir un programa que calcule el m�ximo com�n divisor (MCD) de dos enteros positivos. Si M >= N una funci�n recursiva para MCD es:
		MCD = M si N =0
		MCD = MCD (N, M mod N) si N <> 0
		El programa pedir� dos valores para M y N y llamar� al m�todo; si M < N el programa se intercambiar�n los valores antes de la llamada.
		 */

		
		int n=Ejercicio01.introducirNumero();
		int m=Ejercicio01.introducirNumero();
		System.out.println("El McD de " + n + " y " + m + " es : " + obtenerMcd(n, m));
	}
	public static int obtenerMcd(int a, int b) {
	       if(b==0)
	           return a;
	       else
	           return obtenerMcd(b, a % b);
	   } 

}
