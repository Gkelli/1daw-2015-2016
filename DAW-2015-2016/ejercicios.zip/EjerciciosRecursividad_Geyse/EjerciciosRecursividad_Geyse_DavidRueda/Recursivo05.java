package EjerciciosRecursividad;

import EjerciciosMetodos.Ejercicio01;

public class Recursivo05 {

	public static void main(String[] args) {
		// 5. Escribir un programa que devuelva la suma de los enteros positivos pares desde N hasta 2. 
		
		int n=Ejercicio01.introducirNumero();
		System.out.println("La suma de los pares desde " + n +" hasta 2 es: " + nPares(n));
		
		
		
	}
	public static int nPares (int n){
		int suma=0;
		if (n == 2) {
			suma = 2;
		} else if (n % 2 == 0) {
			suma = n + nPares(n - 2);
		} else {
			suma = nPares(n - 1);
		}

		return suma;		

	}
}
