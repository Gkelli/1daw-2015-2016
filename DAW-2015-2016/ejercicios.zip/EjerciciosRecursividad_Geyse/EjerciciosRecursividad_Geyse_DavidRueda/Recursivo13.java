package EjerciciosRecursividad;

public class Recursivo13 {

	public static void main(String[] args) {
		// 13.	Escribir un programa que dado un n� obtenga sus cifras en orden inverso usando recursividad 
		// (1� las unidades, luego las decenas, etc)
		System.out.println("introduce numero");
		int num=LeerTeclado.readInteger();
			System.out.println("El inverso es" ); 
			inversocifras(num);
			
	}

	public static void inversocifras(int n) {
		if (n < 10)
			System.out.println(n);
		else {
			System.out.print(n % 10);
			inversocifras(n / 10);
		}
	}
	
}
