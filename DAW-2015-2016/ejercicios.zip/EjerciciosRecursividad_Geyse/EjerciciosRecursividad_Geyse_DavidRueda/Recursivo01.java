package EjerciciosRecursividad;

import EjerciciosMetodos.Ejercicio01;

public class Recursivo01 {

	public static void main(String[] args) {
		
		// Escribir una funci�n recursiva que devuelva la suma de los primeros N positivos, siendo N un n�mero positivo

		int n=Ejercicio01.introducirNumero();
		
		System.out.println(sumaN(n));
		
	}
	
	public static int sumaN (int n){
		if ((n == 0) || (n == 1))
			return n;
		else	
		return n + sumaN(n-1);
		
	}

}
