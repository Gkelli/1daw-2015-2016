package EjerciciosRecursividad;

import EjerciciosMetodos.Ejercicio01;

public class Recursivo10 {

	public static void main(String[] args) {
		/* 10.	Escribir un m�todo recursivo que reciba como par�metros una base a y un exponente b y calcule la potencia por productos sucesivos:
		�	ab  se calcular� multiplicando el n� a tantas veces como indique b.
		�	Hay que tener en cuenta que:
				a0=1
				a-b=1/ab */
		
		int a, b;
		
		a=Ejercicio01.introducirNumero();
		b=Ejercicio01.introducirNumero();
		
		System.out.println("La potencia por productos sucesivos es " + potencia(a, b));

	}

	public static double potencia (int a, int b) {
		double producto=0;
		if(b==0) 
			producto=1;
		/*if	(b==1)
			producto=a;*/
		else	
			producto=a*potencia(a,b-1);
		return producto;
		
		
		
	}
	
	
}
