package EjerciciosRecursividad;

import EjerciciosMetodos.Ejercicio01;

public class Recursivo09 {

	public static void main(String[] args) {
		// 9. Escribir un m�todo que calcule el factorial de un n� usando recursividad.
		
		int num=Ejercicio01.introducirNumero();
		System.out.println("El factorial de un n�mero es " +numFactorial(num));

		
	}

		public static double numFactorial(int numero){
			double result;
			if(numero==0) //condici�n de fin de la recursividad
				result=1; 
			else
				result=numero*numFactorial(numero-1);
			return result;
		}
}
