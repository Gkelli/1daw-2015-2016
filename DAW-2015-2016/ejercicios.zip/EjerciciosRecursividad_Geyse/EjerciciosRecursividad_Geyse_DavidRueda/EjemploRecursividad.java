package EjerciciosRecursividad;

public class EjemploRecursividad {

	public static void main (String[] arg){
		System.out.println("Introduce un n�mero positivo o cero");
		/*a�ade la validaci�n para que el n�mero no sea negativo.
		Pero s� puede ser 0*/
		int n=LeerTeclado.readInteger();
		System.out.println("el factorial es "+fact(n));
		System.out.println("el factorial es "+fact2(n));
		
	}
	
	public static double fact(int numero){
		double result;
		if(numero==0) //condici�n de fin de la recursividad
			result=1; 
		else
			result=numero*fact(numero-1);
		return result;
	}
	
	public static double fact2(int numero){
		if (numero==0)
			return 1;
		else
			return numero*fact2(numero-1);
	}
}
